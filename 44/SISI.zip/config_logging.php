<?php
/**
 * Activity Logging Helper Functions
 */

/**
 * Log activity to database
 * 
 * @param mysqli $conn Database connection
 * @param array $data Log data (user_id, device_id, action, domain, url, reason, category, etc.)
 */
function log_activity(mysqli $conn, array $data): void {
  try {
    // Check if table exists
    $result = $conn->query("SHOW TABLES LIKE 'activity_logs'");
    if (!$result || $result->num_rows === 0) {
      // Table doesn't exist yet - silently skip logging
      return;
    }
    
    $user_id = isset($data['user_id']) ? (int)$data['user_id'] : null;
    $device_id = isset($data['device_id']) ? (int)$data['device_id'] : null;
    $action = $data['action'] ?? 'unknown';
    $domain = $data['domain'] ?? null;
    $url = $data['url'] ?? null;
    $reason = $data['reason'] ?? null;
    $category = $data['category'] ?? null;
    $ip_address = $_SERVER['REMOTE_ADDR'] ?? null;
    $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? null;
    
    // Truncate long values
    if ($domain && strlen($domain) > 255) {
      $domain = substr($domain, 0, 255);
    }
    if ($url && strlen($url) > 1000) {
      $url = substr($url, 0, 1000);
    }
    if ($user_agent && strlen($user_agent) > 500) {
      $user_agent = substr($user_agent, 0, 500);
    }
    
    $stmt = $conn->prepare("
      INSERT INTO activity_logs 
      (user_id, device_id, action, domain, url, reason, category, ip_address, user_agent)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");
    
    $stmt->bind_param(
      "iisssssss",
      $user_id,
      $device_id,
      $action,
      $domain,
      $url,
      $reason,
      $category,
      $ip_address,
      $user_agent
    );
    
    $stmt->execute();
  } catch (Exception $e) {
    // Silently fail - don't break the main functionality
    error_log("Activity logging error: " . $e->getMessage());
  }
}

/**
 * Check if logging is enabled (table exists)
 */
function is_logging_enabled(mysqli $conn): bool {
  try {
    $result = $conn->query("SHOW TABLES LIKE 'activity_logs'");
    return $result && $result->num_rows > 0;
  } catch (Exception $e) {
    return false;
  }
}

