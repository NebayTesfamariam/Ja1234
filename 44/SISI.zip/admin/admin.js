const API = (path) => "../api/" + path;

let token = localStorage.getItem("token") || "";

const $ = (id) => document.getElementById(id);

function setMsg(el, text, type) {
  if (!el) return;
  el.textContent = text || "";
  if (type) {
    el.className = `msg ${type}`;
  }
}

async function apiFetch(path, opts = {}) {
  token = localStorage.getItem("token") || "";
  
  const headers = opts.headers || {};
  headers["Content-Type"] = "application/json";
  if (token) {
    headers["Authorization"] = `Bearer ${token}`;
  }
  
  const res = await fetch(API(path), { ...opts, headers });
  const data = await res.json().catch(() => ({}));
  
  if (!res.ok) {
    if (res.status === 401) {
      logout();
      throw new Error(data.message || "Sessie verlopen");
    }
    throw new Error(data.message || `HTTP ${res.status}`);
  }
  return data;
}

function showAdmin(show) {
  $("loginCard").classList.toggle("hidden", show);
  $("adminCard").classList.toggle("hidden", !show);
}

async function checkAdmin() {
  try {
    const data = await apiFetch("admin_check.php");
    $("adminLine").textContent = `Ingelogd als ${data.user.email} (Admin)`;
    return true;
  } catch (e) {
    setMsg($("loginMsg"), "Geen admin rechten: " + e.message);
    return false;
  }
}

async function loadStats() {
  try {
    const data = await apiFetch("admin_stats.php");
    const stats = data.stats;
    
    // Also get blocklist stats
    let blocklistStats = { total_blocked: 0 };
    try {
      const blockData = await apiFetch("admin_blocklist_stats.php");
      blocklistStats = blockData.stats;
    } catch (e) {
      // Blocklist might not be set up yet
    }
    
    $("statsSection").innerHTML = `
      <div class="stat-card">
        <div class="stat-label">Totaal Gebruikers</div>
        <div class="stat-value">${stats.total_users}</div>
      </div>
      <div class="stat-card">
        <div class="stat-label">Admins</div>
        <div class="stat-value">${stats.total_admins}</div>
      </div>
      <div class="stat-card">
        <div class="stat-label">Totaal Devices</div>
        <div class="stat-value">${stats.total_devices}</div>
      </div>
      <div class="stat-card">
        <div class="stat-label">Actieve Devices</div>
        <div class="stat-value">${stats.active_devices}</div>
      </div>
      <div class="stat-card" style="border: 2px solid #ff6b6b;">
        <div class="stat-label">🚫 Permanent Geblokkeerd</div>
        <div class="stat-value" style="color: #ff6b6b;">${blocklistStats.total_blocked || 0}</div>
      </div>
      <div class="stat-card">
        <div class="stat-label">Whitelist Entries</div>
        <div class="stat-value">${stats.total_whitelist}</div>
      </div>
    `;
  } catch (e) {
    console.error("Stats error:", e);
  }
}

async function addUser() {
  setMsg($("userMsg"), "");
  const email = $("newUserEmail").value.trim();
  const password = $("newUserPassword").value;
  const is_admin = $("newUserAdmin").checked;
  
  if (!email || !password) {
    setMsg($("userMsg"), "Email en password zijn verplicht");
    return;
  }
  
  try {
    await apiFetch("admin_users.php", {
      method: "POST",
      body: JSON.stringify({ email, password, is_admin })
    });
    $("newUserEmail").value = "";
    $("newUserPassword").value = "";
    $("newUserAdmin").checked = false;
    setMsg($("userMsg"), "Gebruiker toegevoegd ✅");
    await loadUsers();
    await loadStats();
  } catch (e) {
    setMsg($("userMsg"), e.message);
  }
}

let allUsers = [];
let selectedUsers = new Set();
let selectedDevices = new Set();

// Enhanced user loading with checkboxes
async function loadUsers() {
  try {
    const data = await apiFetch("admin_users.php");
    const users = data.users || [];
    allUsers = users; // Store for filtering
    
    const list = $("usersList");
    list.innerHTML = "";
    
    // Populate user select for subscriptions
    const userSelect = $("newSubUser");
    if (userSelect) {
      userSelect.innerHTML = '<option value="">Selecteer gebruiker...</option>';
      users.forEach(u => {
        const opt = document.createElement("option");
        opt.value = u.id;
        opt.textContent = `${u.email} (ID: ${u.id})`;
        userSelect.appendChild(opt);
      });
    }
    
    // Populate user select for devices
    const deviceUserSelect = $("newDeviceUser");
    if (deviceUserSelect) {
      deviceUserSelect.innerHTML = '<option value="">Selecteer gebruiker...</option>';
      users.forEach(u => {
        const opt = document.createElement("option");
        opt.value = u.id;
        opt.textContent = `${u.email} (ID: ${u.id})`;
        deviceUserSelect.appendChild(opt);
      });
    }
    
    // Populate user select for automatic device addition
    const autoDeviceUserSelect = $("autoDeviceUser");
    if (autoDeviceUserSelect) {
      autoDeviceUserSelect.innerHTML = '<option value="">👤 Selecteer gebruiker...</option>';
      users.forEach(u => {
        const opt = document.createElement("option");
        opt.value = u.id;
        opt.textContent = `${u.email} (ID: ${u.id})`;
        autoDeviceUserSelect.appendChild(opt);
      });
      
      // Automatisch de eerste gebruiker selecteren (of de enige als er maar één is)
      if (users.length > 0) {
        autoDeviceUserSelect.value = users[0].id;
      }
    }
    
    // Populate user select for device registration links
    const linkUserSelect = $("linkUserSelect");
    if (linkUserSelect) {
      linkUserSelect.innerHTML = '<option value="">👤 Selecteer gebruiker...</option>';
      users.forEach(u => {
        const opt = document.createElement("option");
        opt.value = u.id;
        opt.textContent = `${u.email} (ID: ${u.id})`;
        linkUserSelect.appendChild(opt);
      });
    }
    
    if (users.length === 0) {
      list.innerHTML = "<div class='item'><p>Geen gebruikers gevonden</p></div>";
      return;
    }
    
    users.forEach(u => {
      const div = document.createElement("div");
      div.className = "item";
      div.innerHTML = `
        <div style="display: flex; align-items: center; gap: 10px;">
          <input type="checkbox" class="user-checkbox" data-user-id="${u.id}" onchange="toggleUserSelection(${u.id})" />
          <div style="flex: 1;">
            <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 8px;">
              <b>${escapeHtml(u.email)}</b>
              ${u.is_admin ? '<span class="admin-badge">ADMIN</span>' : ''}
            </div>
            <div class="small">
              ID: ${u.id} | 
              Devices: ${u.device_count || 0} | 
              Whitelist: ${u.whitelist_count || 0} |
              Aangemaakt: ${new Date(u.created_at).toLocaleDateString('nl-NL')}
            </div>
          </div>
          <div style="display: flex; gap: 8px; flex-wrap: wrap;">
            <button class="secondary" onclick="editUser(${u.id}, '${escapeHtml(u.email)}', ${u.is_admin ? 1 : 0})">✏️ Bewerken</button>
            <button class="secondary" onclick="resetUserPassword(${u.id}, '${escapeHtml(u.email)}')">🔑 Reset Wachtwoord</button>
            <button class="secondary danger" onclick="deleteUser(${u.id})">🗑️ Verwijder</button>
          </div>
        </div>
      `;
      list.appendChild(div);
    });
    
    updateBulkUserButton();
  } catch (e) {
    setMsg($("userMsg"), e.message);
  }
}

function toggleUserSelection(userId) {
  if (selectedUsers.has(userId)) {
    selectedUsers.delete(userId);
  } else {
    selectedUsers.add(userId);
  }
  updateBulkUserButton();
}

function updateBulkUserButton() {
  const btn = $("bulkUserAction");
  if (btn) {
    if (selectedUsers.size > 0) {
      btn.style.display = "inline-block";
      btn.textContent = `Bulk Actie (${selectedUsers.size} geselecteerd)`;
    } else {
      btn.style.display = "none";
    }
  }
  
  // Update checkboxes
  document.querySelectorAll(".user-checkbox").forEach(cb => {
    cb.checked = selectedUsers.has(parseInt(cb.dataset.userId));
  });
}

async function bulkUserAction() {
  if (selectedUsers.size === 0) return;
  
  const action = prompt(`Wat wil je doen met ${selectedUsers.size} gebruiker(s)?\n1 = Admin maken\n2 = Admin rechten verwijderen\n3 = Verwijderen`);
  
  if (!action) return;
  
  try {
    if (action === "1") {
      // Make admin
      for (const userId of selectedUsers) {
        await apiFetch("admin_users.php", {
          method: "PUT",
          body: JSON.stringify({ user_id: userId, is_admin: true })
        });
      }
      toast(`${selectedUsers.size} gebruiker(s) admin gemaakt ✅`);
    } else if (action === "2") {
      // Remove admin
      for (const userId of selectedUsers) {
        await apiFetch("admin_users.php", {
          method: "PUT",
          body: JSON.stringify({ user_id: userId, is_admin: false })
        });
      }
      toast(`${selectedUsers.size} gebruiker(s) admin rechten verwijderd ✅`);
    } else if (action === "3") {
      if (!confirm(`Weet je zeker dat je ${selectedUsers.size} gebruiker(s) wilt verwijderen?`)) return;
      for (const userId of selectedUsers) {
        await apiFetch("admin_users.php", {
          method: "DELETE",
          body: JSON.stringify({ user_id: userId })
        });
      }
      toast(`${selectedUsers.size} gebruiker(s) verwijderd ✅`);
    }
    
    selectedUsers.clear();
    await loadUsers();
    await loadStats();
  } catch (e) {
    alert("Fout: " + e.message);
  }
}

async function exportUsers() {
  try {
    const data = await apiFetch("admin_users.php");
    const users = data.users || [];
    
    const csv = [
      ["Email", "ID", "Admin", "Devices", "Whitelist", "Aangemaakt"].join(","),
      ...users.map(u => [
        u.email,
        u.id,
        u.is_admin ? "Ja" : "Nee",
        u.device_count || 0,
        u.whitelist_count || 0,
        new Date(u.created_at).toLocaleDateString('nl-NL')
      ].join(","))
    ].join("\n");
    
    const blob = new Blob([csv], { type: "text/csv" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `users_export_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
    
    toast("Gebruikers geëxporteerd ✅");
  } catch (e) {
    alert("Export mislukt: " + e.message);
  }
}

function filterUsers() {
  const search = ($("userSearch")?.value || "").toLowerCase();
  const adminFilter = $("userFilterAdmin")?.value || "";
  
  const items = document.querySelectorAll("#usersList .item");
  
  items.forEach(item => {
    const text = item.textContent.toLowerCase();
    const isAdmin = item.querySelector(".admin-badge") !== null;
    
    const matchSearch = !search || text.includes(search);
    const matchAdmin = !adminFilter || 
      (adminFilter === "1" && isAdmin) || 
      (adminFilter === "0" && !isAdmin);
    
    item.style.display = (matchSearch && matchAdmin) ? "" : "none";
  });
}

function filterDevices() {
  const search = ($("deviceSearch")?.value || "").toLowerCase();
  const statusFilter = $("deviceFilterStatus")?.value || "";
  
  const items = document.querySelectorAll("#devicesList .item");
  
  items.forEach(item => {
    const text = item.textContent.toLowerCase();
    const statusMatch = !statusFilter || text.includes(statusFilter);
    const searchMatch = !search || text.includes(search);
    
    item.style.display = (statusMatch && searchMatch) ? "" : "none";
  });
}

async function exportDevices() {
  try {
    const data = await apiFetch("admin_devices.php");
    const devices = data.devices || [];
    
    const csv = [
      ["Naam", "Gebruiker", "IP", "Status", "WireGuard Key", "Aangemaakt"].join(","),
      ...devices.map(d => [
        d.name,
        d.user_email || "",
        d.wg_ip || "",
        d.status || "",
        d.wg_public_key?.substring(0, 20) + "..." || "",
        new Date(d.created_at).toLocaleDateString('nl-NL')
      ].join(","))
    ].join("\n");
    
    const blob = new Blob([csv], { type: "text/csv" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `devices_export_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
    
    toast("Devices geëxporteerd ✅");
  } catch (e) {
    alert("Export mislukt: " + e.message);
  }
}

// Quick Actions
async function quickAction(action) {
  try {
    switch(action) {
      case 'checkExpired':
        await checkExpiredSubscriptions();
        break;
      case 'activateAllDevices':
        if (!confirm("Weet je zeker dat je alle geblokkeerde devices wilt activeren?")) return;
        const devicesData = await apiFetch("admin_devices.php");
        const blockedDevices = (devicesData.devices || []).filter(d => d.status === 'blocked' && !d.permanent_blocked);
        for (const device of blockedDevices) {
          await apiFetch("admin_devices.php", {
            method: "POST",
            body: JSON.stringify({ device_id: device.id, status: 'active' })
          });
        }
        toast(`${blockedDevices.length} device(s) geactiveerd ✅`);
        await loadDevices();
        await loadStats();
        break;
      case 'refreshAll':
        await loadStats();
        await loadUsers();
        await loadDevices();
        await loadSubscriptions();
        await loadPayments();
        await loadWhitelist();
        await loadBlocklist();
        toast("Alles ververst ✅");
        break;
      case 'exportAll':
        await exportUsers();
        await exportDevices();
        break;
    }
  } catch (e) {
    alert("Fout: " + e.message);
  }
}

async function deleteUser(userId) {
  if (!confirm("Weet je zeker dat je deze gebruiker wilt verwijderen?")) return;
  
  try {
    await apiFetch("admin_users.php", {
      method: "DELETE",
      body: JSON.stringify({ user_id: userId })
    });
    await loadUsers();
    await loadStats();
  } catch (e) {
    alert(e.message);
  }
}

async function editUser(userId, currentEmail, isAdmin) {
  const newEmail = prompt("Nieuw e-mailadres:", currentEmail);
  if (!newEmail || newEmail === currentEmail) return;
  
  const newIsAdmin = confirm(`Admin rechten ${isAdmin ? 'verwijderen' : 'toevoegen'}?`);
  
  try {
    await apiFetch("admin_users.php", {
      method: "PUT",
      body: JSON.stringify({ 
        user_id: userId, 
        email: newEmail,
        is_admin: newIsAdmin ? 1 : 0
      })
    });
    await loadUsers();
    await loadStats();
  } catch (e) {
    alert(e.message);
  }
}

async function resetUserPassword(userId, email) {
  const newPassword = prompt(`Nieuw wachtwoord voor ${email}:`, "");
  if (!newPassword || newPassword.length < 6) {
    alert("Wachtwoord moet minimaal 6 karakters lang zijn");
    return;
  }
  
  if (!confirm(`Wachtwoord resetten voor ${email}?`)) return;
  
  try {
    await apiFetch("admin_users.php", {
      method: "PUT",
      body: JSON.stringify({ 
        user_id: userId, 
        password: newPassword
      })
    });
    alert(`Wachtwoord gereset voor ${email}`);
    await loadUsers();
  } catch (e) {
    alert(e.message);
  }
}

function filterUsers() {
  const search = $("userSearch").value.toLowerCase();
  const items = document.querySelectorAll("#usersList .item");
  
  items.forEach(item => {
    const text = item.textContent.toLowerCase();
    item.style.display = text.includes(search) ? "" : "none";
  });
}

async function loadDevices() {
  try {
    const data = await apiFetch("admin_devices.php");
    const devices = data.devices || [];
    
    const list = $("devicesList");
    list.innerHTML = "";
    
    if (devices.length === 0) {
      list.innerHTML = `<div class="item"><span class="badge">Geen devices</span></div>`;
      return;
    }
    
    for (const d of devices) {
      const div = document.createElement("div");
      div.className = "item";
      const isBlocked = d.status === 'blocked';
      const isActive = d.status === 'active';
      
      const isAutoCreated = d.auto_created === true || d.auto_created === 1;
      const isPermanentBlocked = d.permanent_blocked === true || d.permanent_blocked === 1;
      const isAdminCreated = d.admin_created === true || d.admin_created === 1;
      
      div.innerHTML = `
        <div style="flex: 1;">
          <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 8px; flex-wrap: wrap;">
            <b style="font-size: 1.1em;">${escapeHtml(d.name)}</b>
            ${isAdminCreated ? '<span class="badge" style="background: #10b981; color: white; font-weight: bold;">🔒 PERMANENT TOEGANG</span>' : ''}
            ${isPermanentBlocked ? '<span class="badge" style="background: #ef4444; color: white; font-weight: bold;">🔒 PERMANENT GEBLOKKEERD</span>' : ''}
            ${isAutoCreated && !isPermanentBlocked && !isAdminCreated ? '<span class="badge" style="background: #f59e0b; color: white; font-weight: bold;">⚠️ AUTO</span>' : ''}
            ${isBlocked && !isPermanentBlocked ? '<span class="badge" style="background: var(--danger); color: white; font-weight: bold;">🚫 GEBLOKKEERD</span>' : ''}
            ${isActive && !isBlocked ? '<span class="badge success">✓ Actief</span>' : ''}
            ${!isBlocked && !isActive ? `<span class="badge">${d.status}</span>` : ''}
            <span class="badge" style="background: rgba(79, 125, 249, 0.15); color: var(--primary);">👤 ${escapeHtml(d.user_email)}</span>
          </div>
          <div class="small">
            IP: <span class="code">${escapeHtml(d.wg_ip)}</span> | 
            Whitelist: ${d.whitelist_count} entries |
            Aangemaakt: ${new Date(d.created_at).toLocaleDateString('nl-NL')}
            ${isAdminCreated ? ' | <strong style="color: #10b981;">🔒 PERMANENT TOEGANG - werkt altijd, ook zonder abonnement - kan NOOIT worden verwijderd</strong>' : ''}
            ${isBlocked ? ' | <strong style="color: var(--danger);">⚠️ Geen internet toegang</strong>' : ''}
            ${isPermanentBlocked ? ' | <strong style="color: #ef4444;">🔒 PERMANENT GEBLOKKEERD door admin - kan NOOIT worden deblokkeerd</strong>' : ''}
            ${isBlocked && !isPermanentBlocked && !isAdminCreated ? ' | <strong style="color: #f59e0b;">⚠️ Geblokkeerd - abonnement gestopt (wordt automatisch deblokkeerd bij betaling)</strong>' : ''}
            ${isAutoCreated && !isPermanentBlocked && !isBlocked && !isAdminCreated ? ' | <strong style="color: #f59e0b;">⚠️ Automatisch aangemaakt</strong>' : ''}
          </div>
        </div>
        <div style="display: flex; gap: 8px; align-items: center; flex-wrap: wrap;">
          ${isPermanentBlocked ? 
            `<span class="badge" style="background: rgba(239, 68, 68, 0.3); color: var(--danger); padding: 8px 12px; border: 2px solid var(--danger); font-weight: bold;">PERMANENT - NOOIT DEBLOKKEEREN</span>` :
            (isBlocked ? 
              `<button class="secondary" style="background: var(--success); color: white; font-weight: bold;" data-id="${d.id}" data-action="unblock">✅ Deblokkeren</button>` :
              `<button class="secondary danger" style="font-weight: bold;" data-id="${d.id}" data-action="block">🚫 Blokkeren</button>`
            )
          }
          ${!isPermanentBlocked ? 
            `<button class="secondary" style="background: #ef4444; color: white; font-weight: bold;" data-id="${d.id}" data-action="permanent-block" title="Permanent blokkeren - kan NOOIT worden deblokkeerd">🔒 Permanent Blokkeren</button>` :
            ''
          }
          <select class="statusSelect" data-id="${d.id}" ${isPermanentBlocked ? 'disabled style="opacity: 0.5; padding: 8px 12px; border-radius: 8px; border: 1px solid var(--line); background: var(--card-bg); color: var(--text);"' : 'style="padding: 8px 12px; border-radius: 8px; border: 1px solid var(--line); background: var(--card-bg); color: var(--text);"'}>
            <option value="active" ${d.status === 'active' ? 'selected' : ''}>Active</option>
            <option value="inactive" ${d.status === 'inactive' ? 'selected' : ''}>Inactive</option>
            <option value="pending" ${d.status === 'pending' ? 'selected' : ''}>Pending</option>
            <option value="blocked" ${d.status === 'blocked' ? 'selected' : ''} ${isPermanentBlocked ? 'disabled' : ''}>Blocked</option>
          </select>
          ${isAdminCreated ? 
            `<span class="badge" style="background: rgba(16, 185, 129, 0.2); color: #10b981; padding: 8px 12px; border: 1px solid #10b981; font-weight: bold;">🔒 PERMANENT - Kan niet worden verwijderd</span>` :
            `<button class="secondary danger" data-id="${d.id}" data-action="delete">🗑️ Verwijder</button>`
          }
        </div>
      `;
      
      // Block/Unblock button
      const blockBtn = div.querySelector('button[data-action="block"]');
      const unblockBtn = div.querySelector('button[data-action="unblock"]');
      if (blockBtn) {
        blockBtn.onclick = () => toggleBlockDevice(d.id, false);
      }
      if (unblockBtn) {
        unblockBtn.onclick = () => toggleBlockDevice(d.id, true);
      }
      
      // Permanent block button
      const permanentBlockBtn = div.querySelector('button[data-action="permanent-block"]');
      if (permanentBlockBtn) {
        permanentBlockBtn.onclick = () => permanentBlockDevice(d.id, d.name);
      }
      
      // Status select
      const statusSelect = div.querySelector(".statusSelect");
      if (statusSelect && !isPermanentBlocked) {
        statusSelect.onchange = (e) => updateDeviceStatus(d.id, e.target.value);
      }
      
      // Delete button (only if not admin_created)
      const deleteBtn = div.querySelector('button[data-action="delete"]');
      if (deleteBtn) {
        deleteBtn.onclick = () => deleteDevice(d.id);
      }
      
      list.appendChild(div);
    }
  } catch (e) {
    console.error("Devices error:", e);
    const list = $("devicesList");
    if (list) {
      list.innerHTML = `<div class="item"><p style="padding: 20px; text-align: center; color: var(--danger);">❌ Fout bij laden devices: ${escapeHtml(e.message)}</p></div>`;
    }
  }
}

// Generate device registration link
async function generateDeviceLink() {
  const userId = parseInt($("linkUserSelect").value);
  const expiresDays = parseInt($("linkExpiresDays").value) || 7;
  const maxUses = parseInt($("linkMaxUses").value) || 1;
  const resultEl = $("linkResult");
  
  if (!userId || userId <= 0) {
    resultEl.innerHTML = '<div class="msg error">Selecteer eerst een gebruiker</div>';
    return;
  }
  
  try {
    const btn = $("generateLinkBtn");
    const originalText = btn.textContent;
    btn.disabled = true;
    btn.textContent = "⏳ Genereren...";
    
    const data = await apiFetch("generate_device_link.php", {
      method: "POST",
      body: JSON.stringify({
        user_id: userId,
        expires_in_days: expiresDays,
        max_uses: maxUses
      })
    });
    
    resultEl.innerHTML = `
      <div class="msg success" style="background: rgba(16, 185, 129, 0.1); padding: 15px; border-radius: 8px; border: 2px solid rgba(16, 185, 129, 0.3);">
        <strong>✅ Link gegenereerd!</strong><br><br>
        <div style="margin: 10px 0;">
          <strong>Link:</strong><br>
          <div style="background: var(--card-bg); padding: 10px; border-radius: 6px; margin-top: 5px; word-break: break-all; font-family: monospace; font-size: 0.9em;">
            ${escapeHtml(data.url)}
          </div>
        </div>
        <div style="margin: 10px 0;">
          <button onclick="navigator.clipboard.writeText('${data.url.replace(/'/g, "\\'")}')" class="secondary" style="margin-top: 5px;">
            📋 Kopieer Link
          </button>
        </div>
        <div style="margin-top: 10px; font-size: 0.9em; color: var(--muted);">
          <strong>Details:</strong><br>
          Gebruiker: ${escapeHtml(data.user_email || 'Onbekend')}<br>
          Verloopt: ${new Date(data.expires_at).toLocaleString('nl-NL')}<br>
          Max gebruik: ${data.max_uses}x
        </div>
      </div>
    `;
    
    btn.disabled = false;
    btn.textContent = originalText;
  } catch (e) {
    resultEl.innerHTML = `<div class="msg error">❌ Fout: ${escapeHtml(e.message)}</div>`;
    const btn = $("generateLinkBtn");
    btn.disabled = false;
    btn.textContent = "🔗 Link Genereren";
  }
}

async function addDevice() {
  const msgEl = $("deviceMsg");
  setMsg(msgEl, "");
  
  const userId = parseInt($("newDeviceUser").value);
  let name = $("newDeviceName").value.trim();
  
  if (!userId || userId <= 0) {
    msgEl.className = "msg error";
    setMsg(msgEl, "❌ Selecteer eerst een gebruiker");
    return;
  }
  
  // Auto-detect device name if not provided
  if (!name) {
    const userAgent = navigator.userAgent || '';
    if (userAgent.includes('iPhone')) {
      name = 'iPhone';
    } else if (userAgent.includes('iPad')) {
      name = 'iPad';
    } else if (userAgent.includes('Android')) {
      name = 'Android Device';
    } else if (userAgent.includes('Windows')) {
      name = 'Windows PC';
    } else if (userAgent.includes('Mac') || userAgent.includes('macOS')) {
      name = 'Mac';
    } else if (userAgent.includes('Linux')) {
      name = 'Linux PC';
    } else {
      name = 'Device';
    }
    
    // Add number if user already has devices with this name
    // This will be handled server-side, but we can add a suffix here too
    const devicesData = await apiFetch("admin_devices.php");
    const userDevices = (devicesData.devices || []).filter(d => d.user_id === userId && d.name.startsWith(name));
    if (userDevices.length > 0) {
      name = `${name} ${userDevices.length + 1}`;
    }
  }
  
  try {
    const btn = $("addDeviceBtn");
    const originalText = btn.textContent;
    btn.disabled = true;
    btn.textContent = "⏳ Toevoegen...";
    
    const data = await apiFetch("admin_devices.php", {
      method: "PUT",
      body: JSON.stringify({
        user_id: userId,
        name: name,
        // WireGuard key and IP are automatically generated server-side
        admin_created: true
      })
    });
    
    if (data.status === 'exists') {
      // Device already exists
      msgEl.className = "msg info";
      setMsg(msgEl, `ℹ️ ${data.message || 'Device bestaat al voor deze gebruiker'}`);
      Toast.info(data.message || 'Device bestaat al');
    } else {
      // New device created
      // Clear form
      $("newDeviceUser").value = "";
      $("newDeviceName").value = "";
      
      // Show complete information - everything is automatically configured
      const autoInfo = data.auto_configured || {};
      msgEl.className = "msg success";
      setMsg(msgEl, `✅ Device "${data.device_name || name}" AUTOMATISCH toegevoegd en DIRECT klaar voor gebruik!\n\n` +
        `🔧 AUTOMATISCH INGESTELD:\n` +
        `✅ Status: ${data.status || 'active'} (automatisch)\n` +
        `✅ WireGuard Key: ${autoInfo.wireguard_key || 'Automatisch gegenereerd'}\n` +
        `✅ IP Adres: ${data.wg_ip || 'Automatisch toegewezen'}\n` +
        `✅ Permanent Toegang: ${autoInfo.permanent_access ? 'Ja' : 'Ja'} (werkt altijd)\n` +
        `✅ Geen Abonnement Nodig: ${autoInfo.no_subscription_required ? 'Ja' : 'Ja'}\n` +
        `✅ Systeem Klaar: ${autoInfo.system_ready ? 'Ja' : 'Ja'}\n\n` +
        `🚀 Dit device kan DIRECT het systeem gebruiken - geen extra configuratie nodig!\n` +
        `🔒 Dit device kan NOOIT worden verwijderd (permanent toegang).`);
      Toast.success(`✅ Device "${data.device_name || name}" automatisch toegevoegd en direct klaar!`);
    }
    
    btn.disabled = false;
    btn.textContent = originalText;
    await loadDevices();
    await loadStats();
  } catch (e) {
    msgEl.className = "msg error";
    setMsg(msgEl, "❌ " + e.message);
    Toast.error("Fout: " + e.message);
    
    const btn = $("addDeviceBtn");
    btn.disabled = false;
    btn.textContent = "➕ Device Toevoegen";
  }
}

// Automatic device addition - super simple, no name needed
async function autoAddDevice() {
  const userId = parseInt($("autoDeviceUser").value);
  const msgEl = $("deviceMsg");
  
  if (!userId) {
    setMsg(msgEl, "❌ Selecteer eerst een gebruiker");
    Toast.error("Selecteer eerst een gebruiker");
    return;
  }
  
  try {
    const btn = $("autoAddDeviceBtn");
    const originalText = btn.textContent;
    btn.disabled = true;
    btn.textContent = "⏳ Toevoegen...";
    
    // Get user's existing devices to generate a unique name
    const usersData = await apiFetch("admin_users.php");
    const user = (usersData.users || []).find(u => u.id === userId);
    const deviceCount = (user && user.device_count) ? user.device_count : 0;
    
    // Auto-generate device name
    const deviceNames = ['iPhone', 'Android', 'Windows PC', 'MacBook', 'iPad', 'Tablet', 'Laptop'];
    const randomName = deviceNames[Math.floor(Math.random() * deviceNames.length)];
    const deviceName = deviceCount > 0 ? `${randomName} ${deviceCount + 1}` : randomName;
    
    const data = await apiFetch("admin_devices.php", {
      method: "PUT",
      body: JSON.stringify({
        user_id: userId,
        name: deviceName,
        // WireGuard key and IP are automatically generated server-side
        admin_created: true
      })
    });
    
    if (data.status === 'exists') {
      msgEl.className = "msg info";
      setMsg(msgEl, `ℹ️ ${data.message || 'Device bestaat al voor deze gebruiker'}`);
      Toast.info(data.message || 'Device bestaat al');
    } else {
      // Clear form
      $("autoDeviceUser").value = "";
      
      // Show complete information - everything is automatically configured
      const autoInfo = data.auto_configured || {};
      msgEl.className = "msg success";
      setMsg(msgEl, `✅ Device "${data.device_name || deviceName}" AUTOMATISCH toegevoegd en DIRECT klaar voor gebruik!\n\n` +
        `🔧 AUTOMATISCH INGESTELD:\n` +
        `✅ Status: ${data.status || 'active'} (automatisch)\n` +
        `✅ WireGuard Key: ${autoInfo.wireguard_key || 'Automatisch gegenereerd'}\n` +
        `✅ IP Adres: ${data.wg_ip || 'Automatisch toegewezen'}\n` +
        `✅ Permanent Toegang: ${autoInfo.permanent_access ? 'Ja' : 'Ja'} (werkt altijd)\n` +
        `✅ Geen Abonnement Nodig: ${autoInfo.no_subscription_required ? 'Ja' : 'Ja'}\n` +
        `✅ Systeem Klaar: ${autoInfo.system_ready ? 'Ja' : 'Ja'}\n\n` +
        `🚀 Dit device kan DIRECT het systeem gebruiken - geen extra configuratie nodig!\n` +
        `🔒 Dit device kan NOOIT worden verwijderd (permanent toegang).`);
      Toast.success(`✅ Device "${data.device_name || deviceName}" automatisch toegevoegd en direct klaar!`);
    }
    
    btn.disabled = false;
    btn.textContent = originalText;
    await loadDevices();
    await loadStats();
  } catch (e) {
    msgEl.className = "msg error";
    setMsg(msgEl, "❌ " + e.message);
    Toast.error("Fout: " + e.message);
    
    const btn = $("autoAddDeviceBtn");
    btn.disabled = false;
    btn.textContent = "⚡ Automatisch Toevoegen";
  }
}

async function toggleBlockDevice(deviceId, isBlocked) {
  try {
    // Check if device is admin_created before blocking
    const devicesData = await apiFetch("admin_devices.php");
    const device = (devicesData.devices || []).find(d => d.id === deviceId);
    
    if (device && (device.admin_created === true || device.admin_created === 1) && !isBlocked) {
      alert('⚠️ PERMANENTE TOEGANG - NIET TE BLOKKEREN\n\nDit device is aangemaakt door admin en heeft PERMANENTE TOEGANG.\n\n🔒 LIFETIME TOEGANG:\n- Werkt altijd, ook zonder abonnement\n- Kan NOOIT worden geblokkeerd\n- Kan NOOIT worden verwijderd\n- Permanent actief in het systeem\n\nDit device blijft altijd actief.');
      return;
    }
    
    const newStatus = isBlocked ? 'active' : 'blocked';
    await apiFetch("admin_devices.php", {
      method: "POST",
      body: JSON.stringify({ device_id: deviceId, status: newStatus })
    });
    await loadDevices();
    await loadStats();
    toast(isBlocked ? "Device geactiveerd ✅" : "Device geblokkeerd ✅");
  } catch (e) {
    if (e.message && (e.message.includes('permanent') || e.message.includes('admin_created'))) {
      alert('⚠️ ' + e.message + '\n\nDit device heeft permanente toegang en kan NOOIT worden geblokkeerd.');
    } else {
      alert(e.message);
    }
  }
}

async function permanentBlockDevice(deviceId, deviceName) {
  if (!confirm(`⚠️ WAARSCHUWING: Permanent blokkeren\n\nWeet je zeker dat je "${deviceName}" PERMANENT wilt blokkeren?\n\nDit device kan NOOIT meer worden deblokkeerd, zelfs niet door jou als admin!\n\nDit is onomkeerbaar!`)) {
    return;
  }
  
  if (!confirm(`Laatste bevestiging:\n\nJe staat op het punt "${deviceName}" PERMANENT te blokkeren.\n\nDit kan NOOIT worden teruggedraaid!\n\nDoorgaan?`)) {
    return;
  }
  
  try {
    await apiFetch("admin_devices.php", {
      method: "POST",
      body: JSON.stringify({ 
        device_id: deviceId, 
        status: 'blocked',
        permanent_block: true
      })
    });
    alert(`✅ "${deviceName}" is nu PERMANENT geblokkeerd.\n\nDit device kan NOOIT meer worden deblokkeerd.`);
    await loadDevices();
    await loadStats();
  } catch (e) {
    alert('Fout: ' + e.message);
  }
}

async function updateDeviceStatus(deviceId, newStatus) {
  try {
    await apiFetch("admin_devices.php", {
      method: "POST",
      body: JSON.stringify({ device_id: deviceId, status: newStatus })
    });
    await loadDevices();
    await loadStats();
  } catch (e) {
    if (e.message && e.message.includes('permanent')) {
      alert('⚠️ ' + e.message + '\n\nDit device is permanent geblokkeerd en kan NOOIT worden deblokkeerd.');
      // Reload to reset dropdown
      await loadDevices();
    } else {
      alert(e.message);
    }
  }
}

async function updateDeviceStatus(deviceId, status) {
  try {
    await apiFetch("admin_devices.php", {
      method: "POST",
      body: JSON.stringify({ device_id: deviceId, status })
    });
    await loadDevices();
    await loadStats();
  } catch (e) {
    alert(e.message);
  }
}

async function deleteDevice(deviceId) {
  // Check if device is admin_created before showing confirmation
  try {
    const devicesData = await apiFetch("admin_devices.php");
    const device = (devicesData.devices || []).find(d => d.id === deviceId);
    
    if (device && (device.admin_created === true || device.admin_created === 1)) {
      alert('⚠️ PERMANENTE TOEGANG - NIET VERWIJDERBAAR\n\nDit device is aangemaakt door admin en heeft PERMANENTE TOEGANG.\n\n🔒 LIFETIME TOEGANG:\n- Werkt altijd, ook zonder abonnement\n- Kan NOOIT worden verwijderd\n- Kan NOOIT worden geblokkeerd\n- Permanent actief in het systeem\n\nDit device blijft altijd werken.');
      return;
    }
  } catch (e) {
    // Continue with delete attempt if check fails
  }
  
  if (!confirm("Weet je zeker dat je dit device wilt verwijderen?")) return;
  
  try {
    await apiFetch("admin_devices.php", {
      method: "DELETE",
      body: JSON.stringify({ device_id: deviceId })
    });
    await loadDevices();
    await loadStats();
    toast("Device verwijderd ✅");
  } catch (e) {
    if (e.message && e.message.includes('admin_created')) {
      alert('⚠️ PERMANENTE TOEGANG - NIET VERWIJDERBAAR\n\nDit device is aangemaakt door admin en heeft PERMANENTE TOEGANG.\n\n🔒 LIFETIME TOEGANG:\n- Werkt altijd, ook zonder abonnement\n- Kan NOOIT worden verwijderd\n- Kan NOOIT worden geblokkeerd\n- Permanent actief in het systeem\n\nDit device blijft altijd werken.');
    } else {
      alert('Fout: ' + e.message);
    }
  }
}

async function loadWhitelist() {
  try {
    // Get all devices first, then get whitelist for each
    const devicesData = await apiFetch("admin_devices.php");
    const devices = devicesData.devices || [];
    
    const list = $("whitelistList");
    list.innerHTML = "";
    
    if (devices.length === 0) {
      list.innerHTML = `<div class="item"><span class="badge">Geen devices</span></div>`;
      return;
    }
    
    for (const device of devices) {
      try {
        const wlData = await apiFetch(`get_whitelist.php?device_id=${device.id}`);
        const entries = wlData.entries || [];
        
        if (entries.length > 0) {
          for (const entry of entries) {
            const div = document.createElement("div");
            div.className = "item";
            div.innerHTML = `
              <div>
                <div>
                  <b>${escapeHtml(entry.domain)}</b>
                  <span class="badge">${entry.enabled ? 'enabled' : 'disabled'}</span>
                </div>
                <div class="small">
                  Device: ${escapeHtml(device.name)} (${escapeHtml(device.user_email)}) | 
                  ${entry.comment ? 'Comment: ' + escapeHtml(entry.comment) : ''}
                </div>
              </div>
            `;
            list.appendChild(div);
          }
        }
      } catch (e) {
        // Skip devices without whitelist access
      }
    }
    
    if (list.innerHTML === "") {
      list.innerHTML = `<div class="item"><span class="badge">Geen whitelist entries</span></div>`;
    }
  } catch (e) {
    console.error("Whitelist error:", e);
  }
}

async function login() {
  setMsg($("loginMsg"), "");
  const email = $("email").value.trim();
  const password = $("password").value;
  
  if (!email || !password) {
    setMsg($("loginMsg"), "Email en password zijn verplicht");
    return;
  }
  
  try {
    const headers = { "Content-Type": "application/json" };
    const res = await fetch(API("login.php"), {
      method: "POST",
      headers,
      body: JSON.stringify({ email, password })
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.message || `HTTP ${res.status}`);
    
    token = data.token;
    localStorage.setItem("token", token);
    
    const isAdmin = await checkAdmin();
    if (isAdmin) {
      showAdmin(true);
      await loadStats();
      await loadUsers();
      await loadDevices();
      await loadSubscriptions();
      await loadWhitelist();
      await loadBlocklist();
      await loadPermanentBlocklist();
      await loadSubscriptionBlocklist();
    }
  } catch (e) {
    setMsg($("loginMsg"), e.message);
  }
}

function logout() {
  token = "";
  localStorage.removeItem("token");
  stopAutoRefresh();
  showAdmin(false);
}

function escapeHtml(str) {
  return String(str).replace(/[&<>"']/g, (m) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;"
  }[m]));
}

// Tabs
document.querySelectorAll(".tab").forEach(tab => {
  tab.onclick = () => {
    document.querySelectorAll(".tab").forEach(t => t.classList.remove("active"));
    document.querySelectorAll(".tab-content").forEach(c => c.classList.remove("active"));
    tab.classList.add("active");
    
    // Handle tab names with dashes
    const tabName = tab.dataset.tab;
    let tabId;
    if (tabName.includes('-')) {
      tabId = tabName.split('-').map((part, i) => 
        i === 0 ? part.charAt(0).toUpperCase() + part.slice(1) : part.charAt(0).toUpperCase() + part.slice(1)
      ).join('');
    } else {
      tabId = tabName.charAt(0).toUpperCase() + tabName.slice(1);
    }
    
    const tabElement = $(`tab${tabId}`);
    if (tabElement) {
      tabElement.classList.add("active");
      
      // Load data when switching to specific tabs
      if (tabName === 'activity') {
        loadActivityLogs();
      } else if (tabName === 'payments') {
        loadPayments();
      } else if (tabName === 'settings') {
        loadSettings();
      } else if (tabName === 'health') {
        runHealthCheck();
        loadNotificationSettings();
        loadBackupSettings();
      } else if (tabName === 'subscriptions') {
        setDefaultSubscriptionDates();
      }
    }
  };
});

async function loadBlocklist() {
  try {
    const data = await apiFetch("admin_blocklist.php?type=global");
    const entries = data.entries || [];
    
    const list = $("blocklistList");
    if (!list) {
      console.error("blocklistList element not found");
      return;
    }
    
    list.innerHTML = "";
    
    // Update count
    const countEl = $("blockCount");
    if (countEl) {
      countEl.textContent = entries.length;
    }
    
    // Also update H4 if it exists
    const h4El = list.previousElementSibling;
    if (h4El && h4El.tagName === 'H4') {
      h4El.innerHTML = `Global Blocklist (<span id="blockCount">${entries.length}</span> domains)`;
    }
    
    if (entries.length === 0) {
      list.innerHTML = `
        <div class="item">
          <div style="text-align: center; padding: 20px;">
            <span class="badge" style="background: rgba(245, 158, 11, 0.15); color: var(--warning); margin-bottom: 10px; display: inline-block;">Geen blocklist entries</span>
            <p class="hint" style="margin-top: 15px;">
              De blocklist is leeg. Pornografische sites worden automatisch toegevoegd wanneer ze worden gedetecteerd.<br>
              Je kunt ook handmatig domains toevoegen via het formulier hierboven, of<br>
              <a href="../auto_add_porn_sites.php" target="_blank" style="color: var(--success); text-decoration: underline; font-weight: bold; font-size: 1.1em;">🤖 Klik hier om ALLE bekende pornografische sites automatisch toe te voegen</a><br>
              <small style="opacity: 0.8;">Dit voegt honderden bekende pornografische sites toe zonder te wachten tot iemand ze bezoekt</small>
            </p>
          </div>
        </div>
      `;
      return;
    }
    
    for (const entry of entries) {
      const div = document.createElement("div");
      div.className = "item";
      const isAutoAdded = entry.source && (entry.source.includes('auto_block') || entry.source === 'auto_block_keyword' || entry.source === 'auto_block_url_keyword');
      div.innerHTML = `
        <div>
          <div>
            <b>${escapeHtml(entry.domain)}</b>
            <span class="badge">${escapeHtml(entry.category)}</span>
            <span class="badge" style="background: #ff6b6b; color: white; font-weight: bold;">🚫 GEBLOKKEERD</span>
            ${entry.source ? `<span class="badge" style="background: ${isAutoAdded ? 'rgba(16, 185, 129, 0.15)' : 'rgba(79, 125, 249, 0.15)'}; color: ${isAutoAdded ? 'var(--success)' : 'var(--primary)'};">
              ${isAutoAdded ? '🤖 AUTOMATISCH' : '✋ HANDMATIG'}
            </span>` : ''}
          </div>
          <div class="small">
            Toegevoegd: ${new Date(entry.created_at).toLocaleDateString('nl-NL')}
            ${isAutoAdded ? ' | <strong style="color: var(--success);">🤖 Automatisch gedetecteerd en toegevoegd</strong>' : ' | <strong style="color: var(--primary);">✋ Handmatig toegevoegd door admin</strong>'}
          </div>
        </div>
        <div style="display: flex; gap: 8px;">
          <span class="badge" style="background: rgba(239, 68, 68, 0.3); color: var(--danger); padding: 8px 12px; border: 2px solid var(--danger); font-weight: bold;">PERMANENT - NIET VERWIJDERBAAR</span>
        </div>
      `;
      list.appendChild(div);
    }
  } catch (e) {
    setMsg($("blockMsg"), e.message);
  }
}

async function addBlocklist() {
  setMsg($("blockMsg"), "");
  const domain = $("newBlockDomain").value.trim();
  const category = $("newBlockCategory").value;
  
  if (!domain) {
    setMsg($("blockMsg"), "Domein is verplicht");
    return;
  }
  
  try {
    await apiFetch("admin_blocklist.php?type=global", {
      method: "POST",
      body: JSON.stringify({ domain, category, source: "manual" })
    });
    $("newBlockDomain").value = "";
    setMsg($("blockMsg"), "Domain toegevoegd aan blocklist ✅");
    await loadBlocklist();
    await loadStats();
  } catch (e) {
    setMsg($("blockMsg"), e.message);
  }
}

async function deleteBlocklist(id) {
  // ALL domains in Global Blocklist are permanent and cannot be deleted
  alert('⚠️ PERMANENTE BLOKKERING\n\nDomains in de Global Blocklist kunnen NIET worden verwijderd.\n\nZowel automatisch als handmatig toegevoegde domains zijn permanent om ervoor te zorgen dat pornografische content altijd geblokkeerd blijft.');
  return;
  if (!confirm("Weet je zeker dat je dit domain uit de blocklist wilt verwijderen?")) return;
  
  try {
    await apiFetch("admin_blocklist.php?type=global", {
      method: "DELETE",
      body: JSON.stringify({ id })
    });
    await loadBlocklist();
    await loadStats();
  } catch (e) {
    alert(e.message);
  }
}

async function importExampleBlocklist() {
  if (!confirm("Dit importeert een voorbeeld blocklist met bekende pornografische domains. Doorgaan?")) return;
  
  setMsg($("blockMsg"), "Importing...");
  
  // Example blocklist - in production, load from external source
  const exampleDomains = [
    'pornhub.com',
    'xvideos.com',
    'xnxx.com',
    'redtube.com',
    'youporn.com',
    'tube8.com',
    'spankwire.com',
    'keezmovies.com',
    'extremetube.com',
    '4tube.com'
  ];
  
  try {
    const data = await apiFetch("import_blocklist.php", {
      method: "POST",
      body: JSON.stringify({
        domains: exampleDomains,
        category: "pornography",
        source: "example_import"
      })
    });
    setMsg($("blockMsg"), `Import voltooid: ${data.added} toegevoegd, ${data.skipped} overgeslagen ✅`);
    await loadBlocklist();
    await loadStats();
  } catch (e) {
    setMsg($("blockMsg"), e.message);
  }
}

async function exportBlocklist() {
  try {
    const data = await apiFetch("admin_blocklist.php?type=global");
    const entries = data.entries || [];
    
    const text = entries
      .filter(e => e.enabled)
      .map(e => e.domain)
      .join('\n');
    
    const blob = new Blob([text], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'blocklist.txt';
    a.click();
    URL.revokeObjectURL(url);
    
    setMsg($("blockMsg"), "Blocklist geëxporteerd ✅");
  } catch (e) {
    setMsg($("blockMsg"), e.message);
  }
}

// Permanent Blocklist functions
async function loadAutoBlockStats() {
  try {
    const data = await apiFetch("admin_auto_block.php");
    const statsEl = document.getElementById("autoBlockStats");
    const countEl = document.getElementById("autoBlockCount");
    
    if (statsEl && countEl) {
      statsEl.style.display = "block";
      countEl.textContent = data.total_auto_blocked || 0;
    }
  } catch (e) {
    console.error("Auto block stats error:", e);
  }
}

async function loadPermanentBlocklist() {
  try {
    const data = await apiFetch("admin_blocklist_permanent.php");
    const entries = data.entries || [];
    
    const list = $("permanentList");
    list.innerHTML = "";
    $("permCount").textContent = entries.length;
    
    if (entries.length === 0) {
      list.innerHTML = `<div class="item"><span class="badge">Geen permanente blocklist entries</span></div>`;
      return;
    }
    
    for (const entry of entries) {
      const div = document.createElement("div");
      div.className = "item";
      const isAuto = entry.source && entry.source.includes('auto');
      
      div.innerHTML = `
        <div style="flex: 1;">
          <div>
            <b>${escapeHtml(entry.domain)}</b>
            <span class="badge danger">🔒 PERMANENT</span>
            ${isAuto ? '<span class="badge" style="background: var(--success); color: white;">🤖 AUTOMATISCH</span>' : ''}
            <span class="badge">${escapeHtml(entry.category)}</span>
          </div>
          <div class="small">
            Source: ${escapeHtml(entry.source || 'unknown')} | 
            Toegevoegd: ${new Date(entry.created_at).toLocaleDateString('nl-NL')}
            ${isAuto ? ' | <strong style="color: var(--success);">Automatisch gedetecteerd en geblokkeerd</strong>' : ''}
          </div>
        </div>
        <span class="badge" style="background: rgba(239, 68, 68, 0.2); color: var(--danger); padding: 8px 12px; border: 1px solid var(--danger);">
          🔒 PERMANENT - Kan niet worden verwijderd
        </span>
      `;
      list.appendChild(div);
    }
  } catch (e) {
    setMsg($("permMsg"), e.message);
  }
}

// Permanent blocklist is READ-ONLY - no manual management allowed
// Only automatic additions via check_domain.php and check_url.php are allowed
async function addPermanentBlocklist() {
  alert('⚠️ Permanente blocklist kan niet handmatig worden beheerd.\n\nNieuwe pornografische sites worden automatisch gedetecteerd en toegevoegd wanneer iemand ze probeert te bezoeken.\n\nJe hoeft niets te doen - alles werkt automatisch!');
}

async function deletePermanentBlocklist(id) {
  alert('⚠️ Permanente blocklist kan niet worden beheerd.\n\nDomains kunnen niet worden verwijderd - dit is volledig automatisch.\n\nAlleen automatische toevoeging is mogelijk via keyword detectie.');
}

async function importPermanentBlocklist() {
  alert('⚠️ Permanente blocklist kan niet handmatig worden geïmporteerd.\n\nNieuwe pornografische sites worden automatisch gedetecteerd en toegevoegd wanneer iemand ze probeert te bezoeken.\n\nHet systeem werkt volledig automatisch - geen handmatige actie nodig!');
}

// Activity Logs functions
async function loadActivityLogs() {
  try {
    const search = $("activitySearch")?.value || '';
    const action = $("activityAction")?.value || '';
    const dateFrom = $("activityDateFrom")?.value || '';
    const dateTo = $("activityDateTo")?.value || '';
    
    let url = "admin_activity_logs.php?limit=50";
    if (search) url += `&search=${encodeURIComponent(search)}`;
    if (action) url += `&action=${encodeURIComponent(action)}`;
    if (dateFrom) url += `&date_from=${encodeURIComponent(dateFrom)}`;
    if (dateTo) url += `&date_to=${encodeURIComponent(dateTo)}`;
    
    const data = await apiFetch(url);
    const logs = data.logs || [];
    const stats = data.stats || {};
    
    // Update stats
    if ($("totalBlocked")) $("totalBlocked").textContent = stats.total_blocked || 0;
    if ($("todayBlocked")) $("todayBlocked").textContent = stats.today_blocked || 0;
    if ($("topCategory")) $("topCategory").textContent = stats.top_category || 'N/A';
    
    // Update charts if Chart.js is available
    if (typeof Chart !== 'undefined') {
      loadActivityCharts(data);
    }
    
    // Display logs
    const list = $("activityList");
    if (!list) return;
    
    list.innerHTML = "";
    
    if (logs.length === 0) {
      list.innerHTML = `<div class="item"><span class="badge">Geen activity logs gevonden</span></div>`;
      return;
    }
    
    for (const log of logs) {
      const div = document.createElement("div");
      div.className = "item";
      div.innerHTML = `
        <div style="flex: 1;">
          <div>
            <b>${escapeHtml(log.action || 'Unknown')}</b>
            <span class="badge">${escapeHtml(log.category || 'N/A')}</span>
            ${log.reason ? `<span class="badge" style="background: rgba(239, 68, 68, 0.15); color: var(--danger);">${escapeHtml(log.reason)}</span>` : ''}
          </div>
          <div class="small">
            Domain: <span class="code">${escapeHtml(log.domain || 'N/A')}</span> | 
            User: ${escapeHtml(log.user_email || 'N/A')} | 
            Device: ${escapeHtml(log.device_name || 'N/A')} | 
            ${new Date(log.timestamp).toLocaleString('nl-NL')}
          </div>
        </div>
      `;
      list.appendChild(div);
    }
    
    // Pagination
    const pagination = $("activityPagination");
    if (pagination && data.total_pages > 1) {
      let html = '';
      for (let i = 1; i <= data.total_pages; i++) {
        html += `<button onclick="loadActivityLogsPage(${i})" style="margin: 0 5px;">${i}</button>`;
      }
      pagination.innerHTML = html;
    }
    
  } catch (e) {
    console.error("Activity logs error:", e);
    const list = $("activityList");
    if (list) {
      list.innerHTML = `<div class="item"><span class="badge" style="background: var(--danger); color: white;">Error: ${escapeHtml(e.message)}</span></div>`;
    }
  }
}

async function loadActivityCharts(data) {
  // This would load Chart.js graphs if needed
  // For now, just a placeholder
}

async function exportActivityLogs() {
  try {
    const search = $("activitySearch")?.value || '';
    const action = $("activityAction")?.value || '';
    const dateFrom = $("activityDateFrom")?.value || '';
    const dateTo = $("activityDateTo")?.value || '';
    
    let url = "admin_activity_logs.php?export=1&limit=10000";
    if (search) url += `&search=${encodeURIComponent(search)}`;
    if (action) url += `&action=${encodeURIComponent(action)}`;
    if (dateFrom) url += `&date_from=${encodeURIComponent(dateFrom)}`;
    if (dateTo) url += `&date_to=${encodeURIComponent(dateTo)}`;
    
    // Create download link
    const link = document.createElement('a');
    link.href = API(url);
    link.download = `activity_logs_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
    
  } catch (e) {
    alert('Export error: ' + e.message);
  }
}

function loadActivityLogsPage(page) {
  // Load specific page
  loadActivityLogs();
}

// Subscription Blocklist functions
async function loadSubscriptionBlocklist() {
  try {
    const data = await apiFetch("admin_blocklist_subscription.php");
    const entries = data.entries || [];
    
    const list = $("subscriptionList");
    list.innerHTML = "";
    $("subCount").textContent = entries.length;
    
    if (entries.length === 0) {
      list.innerHTML = `<div class="item"><span class="badge">Geen abonnement blocklist entries</span></div>`;
      return;
    }
    
    for (const entry of entries) {
      const div = document.createElement("div");
      div.className = "item";
      div.innerHTML = `
        <div>
          <div>
            <b>${escapeHtml(entry.domain)}</b>
            <span class="badge" style="background: rgba(16, 185, 129, 0.15); border-color: rgba(16, 185, 129, 0.3); color: var(--success);">ABONNEMENT</span>
            <span class="badge">${escapeHtml(entry.category)}</span>
          </div>
          <div class="small">
            Alleen actief bij actief abonnement | Stopt automatisch bij abonnementsstop | Toegevoegd: ${new Date(entry.created_at).toLocaleDateString('nl-NL')}
          </div>
        </div>
        <button class="secondary danger" data-id="${entry.id}">Verwijder</button>
      `;
      div.querySelector("button").onclick = () => deleteSubscriptionBlocklist(entry.id);
      list.appendChild(div);
    }
  } catch (e) {
    setMsg($("subBlockMsg"), e.message);
  }
}

async function addSubscriptionBlocklist() {
  setMsg($("subBlockMsg"), "");
  const domain = $("newSubDomain").value.trim();
  const category = $("newSubCategory").value;
  
  if (!domain) {
    setMsg($("subBlockMsg"), "Domein is verplicht");
    return;
  }
  
  try {
    await apiFetch("admin_blocklist_subscription.php", {
      method: "POST",
      body: JSON.stringify({ domain, category, source: "subscription" })
    });
    $("newSubDomain").value = "";
    setMsg($("subBlockMsg"), "Domain toegevoegd aan abonnement blocklist ✅");
    await loadSubscriptionBlocklist();
    await loadStats();
  } catch (e) {
    setMsg($("subBlockMsg"), e.message);
  }
}

async function deleteSubscriptionBlocklist(id) {
  if (!confirm("Weet je zeker dat je dit domain uit de abonnement blocklist wilt verwijderen?")) return;
  
  try {
    await apiFetch("admin_blocklist_subscription.php", {
      method: "DELETE",
      body: JSON.stringify({ id })
    });
    await loadSubscriptionBlocklist();
    await loadStats();
  } catch (e) {
    alert(e.message);
  }
}

// Subscription management functions
async function loadSubscriptions() {
  try {
    const data = await apiFetch("admin_subscriptions.php");
    const subscriptions = data.subscriptions || [];
    
    const list = $("subscriptionsList");
    list.innerHTML = "";
    
    if (subscriptions.length === 0) {
      list.innerHTML = `<div class="item"><span class="badge">Geen abonnementen</span></div>`;
      return;
    }
    
    for (const s of subscriptions) {
      const div = document.createElement("div");
      div.className = "item";
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const startDate = new Date(s.start_date);
      const endDate = new Date(s.end_date);
      const isActive = s.status === 'active' && startDate <= today && endDate >= today;
      const planNames = { basic: 'Basic (2 devices)', family: 'Family (5 devices)', premium: 'Premium (10 devices)' };
      
      div.innerHTML = `
        <div style="flex: 1;">
          <div>
            <b>${escapeHtml(s.user_email)}</b>
            <span class="badge ${isActive ? 'success' : ''}">${s.status}</span>
            <span class="badge">${planNames[s.plan] || s.plan}</span>
            ${isActive ? `<span class="badge">${s.device_count}/${s.max_devices} devices</span>` : ''}
            ${isActive ? '<span class="badge success">✓ Direct actief</span>' : ''}
            ${s.stripe_subscription_id ? '<span class="badge" style="background: #635bff;">Stripe: ' + s.stripe_subscription_id.substring(0, 20) + '...</span>' : ''}
          </div>
          <div class="small">
            Start: ${new Date(s.start_date).toLocaleDateString('nl-NL')} | 
            Eind: ${new Date(s.end_date).toLocaleDateString('nl-NL')} |
            ${isActive ? '<strong style="color: var(--success);">Actief - werkt direct</strong>' : 'Niet actief'}
            ${s.stripe_customer_id ? ' | Stripe Customer: ' + s.stripe_customer_id.substring(0, 20) + '...' : ''}
          </div>
        </div>
        <div style="display: flex; gap: 10px; align-items: center;">
          <button class="secondary" onclick="editSubscription(${s.id}, '${s.plan}', '${s.start_date}', '${s.end_date}', '${s.status}')">✏️ Bewerken</button>
          ${isActive ? '<button class="secondary danger" onclick="cancelSubscription(' + s.id + ')">🚫 Stopzetten</button>' : '<button class="secondary" onclick="activateSubscription(' + s.id + ')">✅ Activeren</button>'}
        </div>
      `;
      list.appendChild(div);
    }
  } catch (e) {
    setMsg($("subMsg"), e.message);
  }
}

async function addSubscription() {
  setMsg($("subMsg"), "");
  const user_id = parseInt($("newSubUser").value, 10);
  const plan = $("newSubPlan").value;
  let start_date = $("newSubStartDate").value;
  let end_date = $("newSubEndDate").value;
  
  if (!user_id || !plan) {
    setMsg($("subMsg"), "Gebruiker en plan zijn verplicht");
    return;
  }
  
  // If no start_date, use today (so it works immediately)
  if (!start_date) {
    start_date = new Date().toISOString().split('T')[0];
    $("newSubStartDate").value = start_date;
  }
  
  // If no end_date, calculate 1 month from start
  if (!end_date) {
    const end = new Date(start_date);
    end.setMonth(end.getMonth() + 1);
    end_date = end.toISOString().split('T')[0];
    $("newSubEndDate").value = end_date;
  }
  
  try {
    const data = await apiFetch("admin_subscriptions.php", {
      method: "POST",
      body: JSON.stringify({ user_id, plan, status: 'active', start_date, end_date })
    });
    $("newSubUser").value = "";
    
    if (data.auto_device_created && data.device) {
      setMsg($("subMsg"), `✅ Abonnement actief → ✅ Device "${data.device.device_name}" automatisch geregistreerd → ✅ Direct beschermd!`);
    } else {
      setMsg($("subMsg"), `Abonnement toegevoegd ✅ - Direct actief! Klant kan nu ${data.max_devices} device(s) toevoegen.`);
    }
    
    await loadSubscriptions();
    await loadStats();
  } catch (e) {
    setMsg($("subMsg"), e.message);
  }
}

async function cancelSubscription(subscription_id) {
  if (!confirm("Weet je zeker dat je dit abonnement wilt stopzetten?")) return;
  
  try {
    await apiFetch("admin_subscriptions.php", {
      method: "DELETE",
      body: JSON.stringify({ subscription_id })
    });
    await loadSubscriptions();
    await loadStats();
  } catch (e) {
    alert(e.message);
  }
}

async function editSubscription(subId, currentPlan, currentStart, currentEnd, currentStatus) {
  const newPlan = prompt("Nieuw plan (basic/family/premium):", currentPlan);
  if (!newPlan || !['basic', 'family', 'premium'].includes(newPlan)) return;
  
  const newStart = prompt("Start datum (YYYY-MM-DD):", currentStart);
  if (!newStart) return;
  
  const newEnd = prompt("Eind datum (YYYY-MM-DD):", currentEnd);
  if (!newEnd) return;
  
  try {
    await apiFetch("admin_subscriptions.php", {
      method: "PUT",
      body: JSON.stringify({
        subscription_id: subId,
        plan: newPlan,
        start_date: newStart,
        end_date: newEnd,
        status: currentStatus
      })
    });
    await loadSubscriptions();
    await loadStats();
  } catch (e) {
    alert(e.message);
  }
}

async function activateSubscription(subscription_id) {
  if (!confirm("Dit abonnement activeren?")) return;
  
  try {
    await apiFetch("admin_subscriptions.php", {
      method: "PUT",
      body: JSON.stringify({
        subscription_id,
        status: 'active'
      })
    });
    await loadSubscriptions();
    await loadStats();
  } catch (e) {
    alert(e.message);
  }
}

function filterSubscriptions() {
  const search = $("subscriptionSearch").value.toLowerCase();
  const items = document.querySelectorAll("#subscriptionsList .item");
  
  items.forEach(item => {
    const text = item.textContent.toLowerCase();
    item.style.display = text.includes(search) ? "" : "none";
  });
}

// Wire up
$("loginBtn").onclick = login;
$("logoutBtn").onclick = logout;
$("addUserBtn").onclick = addUser;
$("addBlockBtn").onclick = addBlocklist;
$("importBlockBtn").onclick = importExampleBlocklist;
$("exportBlockBtn").onclick = exportBlocklist;
if ($("addDeviceBtn")) {
  $("addDeviceBtn").onclick = addDevice;
  $("generateLinkBtn").onclick = generateDeviceLink;
}
if ($("autoAddDeviceBtn")) {
  $("autoAddDeviceBtn").onclick = autoAddDevice;
}
// Permanent blocklist buttons removed - read-only
// $("addPermBtn").onclick = addPermanentBlocklist;
// $("importPermBtn").onclick = importPermanentBlocklist;
$("addSubBtn").onclick = addSubscription;
$("addSubBlockBtn").onclick = addSubscriptionBlocklist;
if ($("exportActivityBtn")) {
  $("exportActivityBtn").onclick = exportActivityLogs;
}
if ($("activitySearch")) {
  $("activitySearch").oninput = () => loadActivityLogs();
  $("activityAction").onchange = () => loadActivityLogs();
  $("activityDateFrom").onchange = () => loadActivityLogs();
  $("activityDateTo").onchange = () => loadActivityLogs();
}
if ($("exportDbBtn")) {
  $("exportDbBtn").onclick = exportDatabase;
}
if ($("dbStatsBtn")) {
  $("dbStatsBtn").onclick = loadDatabaseStats;
}
if ($("checkExpiredSubsBtn")) {
  $("checkExpiredSubsBtn").onclick = checkExpiredSubscriptions;
}
if ($("cleanupLogsBtn")) {
  $("cleanupLogsBtn").onclick = cleanupOldLogs;
}
if ($("runHealthCheckBtn")) {
  $("runHealthCheckBtn").onclick = runHealthCheck;
}
if ($("saveNotificationsBtn")) {
  $("saveNotificationsBtn").onclick = saveNotificationSettings;
}
if ($("saveBackupSettingsBtn")) {
  $("saveBackupSettingsBtn").onclick = saveBackupSettings;
}
if ($("paymentSearch")) {
  $("paymentSearch").oninput = () => loadPayments();
  $("paymentStatus").onchange = () => loadPayments();
}

// Auto-refresh every 30 seconds
let autoRefreshInterval = null;

function startAutoRefresh() {
  if (autoRefreshInterval) clearInterval(autoRefreshInterval);
  
  autoRefreshInterval = setInterval(async () => {
    try {
      await loadStats();
      // Only refresh current tab data
      const activeTab = document.querySelector(".tab.active");
      if (activeTab) {
        const tabName = activeTab.dataset.tab;
        if (tabName === 'users') await loadUsers();
        else if (tabName === 'devices') await loadDevices();
        else if (tabName === 'subscriptions') await loadSubscriptions();
        else if (tabName === 'payments') await loadPayments();
        else if (tabName === 'activity') await loadActivityLogs();
        else if (tabName === 'whitelist') await loadWhitelist();
        else if (tabName === 'blocklist') await loadBlocklist();
      }
    } catch (e) {
      console.error("Auto-refresh error:", e);
    }
  }, 30000); // 30 seconds
}

function stopAutoRefresh() {
  if (autoRefreshInterval) {
    clearInterval(autoRefreshInterval);
    autoRefreshInterval = null;
  }
}

// Keyboard shortcuts
document.addEventListener('keydown', (e) => {
  // Ctrl/Cmd + R = Refresh all
  if ((e.ctrlKey || e.metaKey) && e.key === 'r') {
    e.preventDefault();
    quickAction('refreshAll');
  }
  
  // Ctrl/Cmd + E = Export
  if ((e.ctrlKey || e.metaKey) && e.key === 'e') {
    e.preventDefault();
    const activeTab = document.querySelector(".tab.active");
    if (activeTab) {
      const tabName = activeTab.dataset.tab;
      if (tabName === 'users') exportUsers();
      else if (tabName === 'devices') exportDevices();
      else if (tabName === 'activity') exportActivityLogs();
    }
  }
  
  // Escape = Clear selections
  if (e.key === 'Escape') {
    selectedUsers.clear();
    selectedDevices.clear();
    updateBulkUserButton();
  }
});

// Auto-login if token exists
(async () => {
  token = localStorage.getItem("token") || "";
  if (!token) return;
  
  try {
    const isAdmin = await checkAdmin();
    if (isAdmin) {
      showAdmin(true);
      await loadStats();
      await loadUsers();
      await loadDevices();
      await loadSubscriptions();
      await loadPayments();
      await loadWhitelist();
      await loadBlocklist();
      await loadPermanentBlocklist();
      await loadSubscriptionBlocklist();
      await loadSettings();
      
      // Set default dates for subscription form
      setDefaultSubscriptionDates();
      
      // Start auto-refresh
      startAutoRefresh();
    }
  } catch (e) {
    logout();
  }
})();

// Set default dates for new subscription form
function setDefaultSubscriptionDates() {
  const startDateInput = $("newSubStartDate");
  const endDateInput = $("newSubEndDate");
  
  if (startDateInput && endDateInput) {
    const today = new Date();
    const nextMonth = new Date(today);
    nextMonth.setMonth(nextMonth.getMonth() + 1);
    
    // Format as YYYY-MM-DD
    const formatDate = (date) => {
      const year = date.getFullYear();
      const month = String(date.getMonth() + 1).padStart(2, '0');
      const day = String(date.getDate()).padStart(2, '0');
      return `${year}-${month}-${day}`;
    };
    
    startDateInput.value = formatDate(today);
    endDateInput.value = formatDate(nextMonth);
  }
}

// Load Stripe Payments
async function loadPayments() {
  try {
    const data = await apiFetch("admin_subscriptions.php");
    const subscriptions = data.subscriptions || [];
    
    // Filter by search and status
    const search = ($("paymentSearch")?.value || "").toLowerCase();
    const statusFilter = $("paymentStatus")?.value || "";
    
    let filtered = subscriptions.filter(s => {
      const matchSearch = !search || 
        s.user_email?.toLowerCase().includes(search) ||
        s.stripe_subscription_id?.toLowerCase().includes(search) ||
        s.stripe_customer_id?.toLowerCase().includes(search);
      const matchStatus = !statusFilter || s.status === statusFilter;
      return matchSearch && matchStatus;
    });
    
    // Count Stripe subscriptions
    const stripeSubs = subscriptions.filter(s => s.stripe_subscription_id);
    const stripeCustomers = new Set(subscriptions.filter(s => s.stripe_customer_id).map(s => s.stripe_customer_id));
    
    if ($("stripeSubCount")) {
      $("stripeSubCount").textContent = stripeSubs.length;
    }
    if ($("stripeCustomerCount")) {
      $("stripeCustomerCount").textContent = stripeCustomers.size;
    }
    
    const list = $("paymentsList");
    if (!list) return;
    
    list.innerHTML = "";
    
    if (filtered.length === 0) {
      list.innerHTML = "<div class='item'><p>Geen Stripe subscriptions gevonden</p></div>";
      return;
    }
    
    filtered.forEach(s => {
      const div = document.createElement("div");
      div.className = "item";
      div.innerHTML = `
        <div>
          <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 8px;">
            <b>${escapeHtml(s.user_email || 'Onbekend')}</b>
            <span class="badge" style="background: ${s.status === 'active' ? 'var(--success)' : s.status === 'expired' ? 'var(--warning)' : 'var(--muted)'}; color: white;">
              ${s.status === 'active' ? '✅ Actief' : s.status === 'expired' ? '⚠️ Verlopen' : '❌ Geannuleerd'}
            </span>
            ${s.stripe_subscription_id ? '<span class="badge" style="background: #635bff; color: white;">Stripe: ' + s.stripe_subscription_id.substring(0, 20) + '...</span>' : ''}
          </div>
          <div class="small">
            Plan: <strong>${escapeHtml(s.plan_name || s.plan || 'Onbekend')}</strong> | 
            Devices: <strong>${s.device_count || 0}/${s.max_devices || 0}</strong> | 
            Van: <strong>${new Date(s.start_date).toLocaleDateString('nl-NL')}</strong> tot <strong>${new Date(s.end_date).toLocaleDateString('nl-NL')}</strong>
            ${s.stripe_customer_id ? '<br>Stripe Customer: ' + s.stripe_customer_id.substring(0, 30) + '...' : ''}
          </div>
        </div>
      `;
      list.appendChild(div);
    });
  } catch (e) {
    console.error("Payments error:", e);
    if ($("paymentsList")) {
      $("paymentsList").innerHTML = `<div class='item'><p class='error'>Fout bij laden: ${e.message}</p></div>`;
    }
  }
}

// Load Settings
async function loadSettings() {
  try {
    // Load subscription plans
    const data = await apiFetch("admin_subscriptions.php");
    const plans = data.plans || [];
    
    const plansList = $("plansList");
    if (plansList) {
      plansList.innerHTML = "";
      plans.forEach(plan => {
        const div = document.createElement("div");
        div.className = "item";
        div.innerHTML = `
          <div>
            <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 8px;">
              <b>${escapeHtml(plan.name || 'Onbekend')}</b>
              <span class="badge">${plan.max_devices || 0} devices</span>
            </div>
            <div class="small">
              Prijs: <strong>€${(parseFloat(plan.price_monthly) || 0).toFixed(2)}/maand</strong><br>
              ${escapeHtml(plan.description || 'Geen beschrijving')}
            </div>
          </div>
        `;
        plansList.appendChild(div);
      });
    }
  } catch (e) {
    console.error("Settings error:", e);
  }
}

// Export Database
async function exportDatabase() {
  try {
    const res = await fetch(API("admin_export_db.php"), {
      headers: { "Authorization": `Bearer ${token}` }
    });
    
    if (!res.ok) {
      throw new Error("Export mislukt");
    }
    
    const blob = await res.blob();
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `pornfree_backup_${new Date().toISOString().split('T')[0]}.sql`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
    
    toast("Database geëxporteerd ✅");
  } catch (e) {
    alert("Export mislukt: " + e.message);
  }
}

// Load Database Stats
async function loadDatabaseStats() {
  try {
    const data = await apiFetch("admin_db_stats.php");
    const stats = $("dbStats");
    if (stats) {
      stats.style.display = "block";
      stats.innerHTML = `
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px;">
          ${Object.entries(data.stats || {}).map(([key, value]) => `
            <div class="stat-card">
              <div class="stat-label">${key.replace(/_/g, ' ')}</div>
              <div class="stat-value">${value}</div>
            </div>
          `).join('')}
        </div>
      `;
    }
  } catch (e) {
    if ($("dbStats")) {
      $("dbStats").innerHTML = `<p class='error'>Fout: ${e.message}</p>`;
      $("dbStats").style.display = "block";
    }
  }
}

// Check Expired Subscriptions
async function checkExpiredSubscriptions() {
  const msg = $("maintenanceMsg");
  if (msg) setMsg(msg, "Controleren...");
  
  try {
    const data = await apiFetch("check_expired_subscriptions.php");
    if (msg) setMsg(msg, data.message || "Check voltooid ✅", "ok");
    await loadSubscriptions();
    await loadStats();
  } catch (e) {
    if (msg) setMsg(msg, "Fout: " + e.message, "error");
  }
}

// Cleanup Old Logs
async function cleanupOldLogs() {
  if (!confirm("Weet je zeker dat je oude logs wilt opruimen? (ouder dan 90 dagen)")) return;
  
  const msg = $("maintenanceMsg");
  if (msg) setMsg(msg, "Opruimen...");
  
  try {
    const data = await apiFetch("admin_cleanup_logs.php", { method: "POST" });
    if (msg) setMsg(msg, data.message || "Logs opgeruimd ✅", "ok");
    await loadActivityLogs();
  } catch (e) {
    if (msg) setMsg(msg, "Fout: " + e.message, "error");
  }
}

// System Health Check
async function runHealthCheck() {
  try {
    const data = await apiFetch("admin_health.php");
    const health = data;
    
    // Update health cards
    updateHealthCard("healthDb", health.checks.database || {});
    updateHealthCard("healthApi", health.checks.api || {});
    updateHealthCard("healthDisk", health.checks.disk || {});
    updateHealthCard("healthBackup", health.checks.backup || {});
    
    // Generate detailed report
    const report = $("healthReport");
    if (report) {
      let html = `<div style="display: grid; gap: 10px;">`;
      
      Object.entries(health.checks || {}).forEach(([key, check]) => {
        const statusIcon = check.status === 'ok' ? '✅' : check.status === 'warning' ? '⚠️' : '❌';
        const statusColor = check.status === 'ok' ? '#10b981' : check.status === 'warning' ? '#f59e0b' : '#ef4444';
        
        html += `
          <div style="padding: 12px; background: var(--card); border: 1px solid var(--line); border-radius: 8px; border-left: 4px solid ${statusColor};">
            <div style="display: flex; align-items: center; gap: 10px;">
              <span style="font-size: 20px;">${statusIcon}</span>
              <div>
                <strong>${key.charAt(0).toUpperCase() + key.slice(1).replace(/_/g, ' ')}</strong>
                <div class="small" style="margin-top: 4px;">${check.message || 'OK'}</div>
              </div>
            </div>
          </div>
        `;
      });
      
      html += `</div>`;
      report.innerHTML = html;
    }
    
    // Update overall status
    if (health.status === 'unhealthy') {
      toast("⚠️ System Health: Sommige checks zijn mislukt", "warning");
    } else {
      toast("✅ System Health: Alles OK", "success");
    }
  } catch (e) {
    console.error("Health check error:", e);
    toast("❌ Health check mislukt: " + e.message, "error");
  }
}

function updateHealthCard(cardId, check) {
  const card = $(cardId);
  if (!card) return;
  
  const statusIcon = check.status === 'ok' ? '✅' : check.status === 'warning' ? '⚠️' : '❌';
  const statusText = check.status === 'ok' ? 'OK' : check.status === 'warning' ? 'Warning' : 'Error';
  const statusColor = check.status === 'ok' ? '#10b981' : check.status === 'warning' ? '#f59e0b' : '#ef4444';
  
  card.querySelector('.stat-value').innerHTML = `<span style="color: ${statusColor};">${statusIcon} ${statusText}</span>`;
}

// Load Notification Settings
async function loadNotificationSettings() {
  try {
    const data = await apiFetch("admin_notifications.php");
    const settings = data.settings || {};
    
    if ($("adminEmail")) $("adminEmail").value = settings.admin_email || '';
    if ($("notifyNewUser")) $("notifyNewUser").checked = settings.notify_new_user !== false;
    if ($("notifyNewDevice")) $("notifyNewDevice").checked = settings.notify_new_device !== false;
    if ($("notifyExpiredSub")) $("notifyExpiredSub").checked = settings.notify_expired_sub !== false;
    if ($("notifyErrors")) $("notifyErrors").checked = settings.notify_errors !== false;
  } catch (e) {
    console.error("Load notifications error:", e);
  }
}

// Save Notification Settings
async function saveNotificationSettings() {
  const msg = $("notificationMsg");
  if (msg) setMsg(msg, "Opslaan...");
  
  try {
    const data = await apiFetch("admin_notifications.php", {
      method: "POST",
      body: JSON.stringify({
        admin_email: $("adminEmail")?.value || '',
        notify_new_user: $("notifyNewUser")?.checked || false,
        notify_new_device: $("notifyNewDevice")?.checked || false,
        notify_expired_sub: $("notifyExpiredSub")?.checked || false,
        notify_errors: $("notifyErrors")?.checked || false
      })
    });
    
    if (msg) setMsg(msg, data.message || "Instellingen opgeslagen ✅", "ok");
    toast("Notificatie instellingen opgeslagen ✅");
  } catch (e) {
    if (msg) setMsg(msg, "Fout: " + e.message, "error");
  }
}

// Load Backup Settings
async function loadBackupSettings() {
  try {
    const data = await apiFetch("admin_backup_settings.php");
    const settings = data.settings || {};
    
    if ($("autoBackupEnabled")) $("autoBackupEnabled").checked = settings.enabled || false;
    if ($("backupTime")) $("backupTime").value = settings.time || '02:00';
  } catch (e) {
    console.error("Load backup settings error:", e);
  }
}

// Save Backup Settings
async function saveBackupSettings() {
  const msg = $("backupMsg");
  if (msg) setMsg(msg, "Opslaan...");
  
  try {
    const data = await apiFetch("admin_backup_settings.php", {
      method: "POST",
      body: JSON.stringify({
        enabled: $("autoBackupEnabled")?.checked || false,
        time: $("backupTime")?.value || '02:00'
      })
    });
    
    if (msg) setMsg(msg, data.message || "Backup instellingen opgeslagen ✅", "ok");
    toast("Backup instellingen opgeslagen ✅");
  } catch (e) {
    if (msg) setMsg(msg, "Fout: " + e.message, "error");
  }
}



