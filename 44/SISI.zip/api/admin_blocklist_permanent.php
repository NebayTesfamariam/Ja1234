<?php
/**
 * Admin endpoint for PERMANENT blocklist
 * These domains can NEVER be disabled - always blocked
 */
require __DIR__ . '/../config.php';
$user = require_user($conn);

// Check admin
$stmt = $conn->prepare("SELECT is_admin FROM users WHERE id=?");
$stmt->bind_param("i", $user['id']);
$stmt->execute();
$result = $stmt->get_result()->fetch_assoc();
if (!$result || !$result['is_admin']) {
  json_out(['message' => 'Access denied'], 403);
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
  // Get all permanent blocklist entries
  $stmt = $conn->prepare("
    SELECT id, domain, category, source, created_at 
    FROM blocklist_permanent 
    ORDER BY domain ASC
  ");
  $stmt->execute();
  $res = $stmt->get_result();
  
  $entries = [];
  while ($row = $res->fetch_assoc()) {
    $row['id'] = (int)$row['id'];
    $entries[] = $row;
  }
  
  json_out(['entries' => $entries, 'type' => 'permanent']);
  
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
  // Only allow automatic additions (source: auto_block_keyword or auto_block_url_keyword)
  // Manual additions are NOT allowed - permanent blocklist is read-only for admins
  $body = json_decode(file_get_contents('php://input'), true) ?? [];
  $source = trim((string)($body['source'] ?? ''));
  
  // Only allow automatic sources
  if (!in_array($source, ['auto_block_keyword', 'auto_block_url_keyword', 'auto_block_domain'])) {
    json_out([
      'message' => 'Permanente blocklist kan niet handmatig worden beheerd. Alleen automatische toevoeging is toegestaan.',
      'error' => 'read_only'
    ], 403);
  }
  
  $domain = normalize_domain((string)($body['domain'] ?? ''));
  $category = trim((string)($body['category'] ?? 'pornography'));
  
  if ($domain === '') {
    json_out(['message' => 'domain required'], 422);
  }
  
  try {
    $stmt = $conn->prepare("INSERT INTO blocklist_permanent (domain, category, source) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $domain, $category, $source);
    $stmt->execute();
    json_out(['status' => 'added', 'id' => $stmt->insert_id, 'note' => 'Permanent - cannot be disabled'], 201);
  } catch (mysqli_sql_exception $e) {
    if ($conn->errno === 1062) {
      json_out(['message' => 'Domain already in permanent blocklist'], 409);
    }
    json_out(['message' => 'Database error'], 500);
  }
  
} elseif ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
  // DELETE is NOT allowed - permanent blocklist is read-only
  json_out([
    'message' => 'Permanente blocklist kan niet worden beheerd. Domains kunnen niet worden verwijderd.',
    'error' => 'read_only'
  ], 403);
}

