<?php
/**
 * Get blocklist for a device
 * Used by DNS/VPN filter to check if domain should be blocked
 * 
 * Logic (in order of priority):
 * 1. PERMANENT blocklist - ALWAYS active, cannot be disabled, independent of subscriptions
 * 2. Device-specific blocklist
 * 3. GLOBAL blocklist (if enabled)
 * 4. SUBSCRIPTION blocklist (only if user has active subscription)
 * 
 * NOTE: Permanent blocklist works independently - no subscription check needed
 */
require __DIR__ . '/../config.php';

$device_id = (int)($_GET['device_id'] ?? 0);
if ($device_id <= 0) {
  json_out(['message' => 'device_id required'], 422);
}

// Get device info with user_id
$stmt = $conn->prepare("SELECT id, user_id, status, permanent_blocked, admin_created FROM devices WHERE id=?");
$stmt->bind_param("i", $device_id);
$stmt->execute();
$device = $stmt->get_result()->fetch_assoc();

if (!$device) {
  json_out(['blocked_domains' => []], 200);
}

// Check if device is admin_created - these work ALWAYS, lifetime, even without subscription
$is_admin_created = (int)($device['admin_created'] ?? 0) === 1;

// BELANGRIJK: Admin-created devices werken ALTIJD - lifetime toegang, geen abonnement nodig
if ($is_admin_created) {
  // Admin-created devices zijn permanent actief - altijd toegang, ook zonder abonnement
  // Zorg dat status altijd 'active' is
  if ($device['status'] !== 'active') {
    $stmt = $conn->prepare("UPDATE devices SET status = 'active' WHERE id = ? AND admin_created = 1");
    $stmt->bind_param("i", $device_id);
    $stmt->execute();
    // Reload device status
    $stmt = $conn->prepare("SELECT id, user_id, status, permanent_blocked, admin_created FROM devices WHERE id=?");
    $stmt->bind_param("i", $device_id);
    $stmt->execute();
    $device = $stmt->get_result()->fetch_assoc();
  }
  
  // Skip subscription check - admin-created devices werken altijd
  $subscription = null; // Don't check subscription for admin-created devices
} else {
  // Check if subscription is still active - if not, block device automatically (unless admin_created)
  $stmt = $conn->prepare("
    SELECT s.id, s.status, s.end_date
    FROM subscriptions s
    WHERE s.user_id = ? 
      AND s.status = 'active' 
      AND s.start_date <= CURDATE()
      AND s.end_date >= CURDATE()
    ORDER BY s.created_at DESC
    LIMIT 1
  ");
  $stmt->bind_param("i", $device['user_id']);
  $stmt->execute();
  $subscription = $stmt->get_result()->fetch_assoc();

  // If no active subscription, automatically block device (but NOT permanent - can be unblocked when subscription reactivates)
  if (!$subscription) {
    // Only block if not already permanent_blocked by admin
    $stmt = $conn->prepare("UPDATE devices SET status = 'blocked' WHERE id = ? AND permanent_blocked = 0");
    $stmt->bind_param("i", $device_id);
    $stmt->execute();
    json_out([
      'blocked_domains' => [], 
      'device_blocked' => true,
      'subscription_expired' => true,
      'note' => 'Abonnement is gestopt - device is geblokkeerd. Betaal opnieuw om service te hervatten.'
    ], 200);
  }
}

// If subscription is active again, automatically unblock device (unless permanent_blocked by admin)
// BELANGRIJK: Dit zorgt ervoor dat devices direct werken na abonnement aansluiten
if ($subscription && $device['status'] === 'blocked' && (int)$device['permanent_blocked'] === 0) {
  $stmt = $conn->prepare("UPDATE devices SET status = 'active' WHERE id = ?");
  $stmt->bind_param("i", $device_id);
  $stmt->execute();
  // Reload device status
  $stmt = $conn->prepare("SELECT id, user_id, status, permanent_blocked FROM devices WHERE id=?");
  $stmt->bind_param("i", $device_id);
  $stmt->execute();
  $device = $stmt->get_result()->fetch_assoc();
}

// BELANGRIJK: Als device status 'inactive' of 'pending' is maar er is een actief abonnement, activeer het direct
// Dit zorgt ervoor dat het systeem direct werkt na abonnement aansluiten
if ($subscription && in_array($device['status'], ['inactive', 'pending']) && (int)$device['permanent_blocked'] === 0) {
  $stmt = $conn->prepare("UPDATE devices SET status = 'active' WHERE id = ?");
  $stmt->bind_param("i", $device_id);
  $stmt->execute();
  // Reload device status
  $stmt = $conn->prepare("SELECT id, user_id, status, permanent_blocked FROM devices WHERE id=?");
  $stmt->bind_param("i", $device_id);
  $stmt->execute();
  $device = $stmt->get_result()->fetch_assoc();
}

// Blocked devices get empty blocklist (no internet access)
if ($device['status'] === 'blocked') {
  $is_permanent = (int)$device['permanent_blocked'] === 1;
  json_out([
    'blocked_domains' => [], 
    'device_blocked' => true,
    'permanent_blocked' => $is_permanent,
    'note' => $is_permanent 
      ? 'Device is permanent geblokkeerd - kan NOOIT worden deblokkeerd' 
      : 'Device is blocked by admin'
  ], 200);
}

// Inactive/pending devices also get empty blocklist
if ($device['status'] !== 'active') {
  json_out(['blocked_domains' => []], 200);
}

$blocked = [];

// STEP 1: PERMANENT blocklist - ALWAYS active, cannot be disabled
// Pornografische content wordt NOOIT getoond - altijd geblokkeerd
// Works independently of subscriptions - always blocked regardless of subscription status
$stmt = $conn->prepare("
  SELECT domain, category 
  FROM blocklist_permanent
");
$stmt->execute();
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) {
  $blocked[] = [
    'domain' => $row['domain'],
    'category' => $row['category'],
    'source' => 'permanent',
    'permanent' => true,
    'cannot_disable' => true,
    'never_visible' => true,
    'independent_of_subscription' => true,
    'note' => 'Pornografische content wordt NOOIT getoond - permanente blokkering'
  ];
}

// STEP 2: Device-specific blocklist
$stmt = $conn->prepare("
  SELECT domain, category 
  FROM blocklist_device 
  WHERE device_id = ? AND enabled = 1
");
$stmt->bind_param("i", $device_id);
$stmt->execute();
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) {
  // Check if already in permanent list
  $exists = false;
  foreach ($blocked as $b) {
    if ($b['domain'] === $row['domain']) {
      $exists = true;
      break;
    }
  }
  if (!$exists) {
    $blocked[] = [
      'domain' => $row['domain'],
      'category' => $row['category'],
      'source' => 'device'
    ];
  }
}

// STEP 3: Global blocklist (can be enabled/disabled)
$stmt = $conn->prepare("
  SELECT domain, category 
  FROM blocklist_global 
  WHERE enabled = 1
");
$stmt->execute();
$res = $stmt->get_result();
while ($row = $res->fetch_assoc()) {
  $exists = false;
  foreach ($blocked as $b) {
    if ($b['domain'] === $row['domain']) {
      $exists = true;
      break;
    }
  }
  if (!$exists) {
    $blocked[] = [
      'domain' => $row['domain'],
      'category' => $row['category'],
      'source' => 'global'
    ];
  }
}

// STEP 4: Subscription blocklist (only if user has active subscription)
// Check if subscription is active and not expired (works immediately when created)
$user_id = (int)$device['user_id'];
$stmt = $conn->prepare("
  SELECT id, plan, end_date
  FROM subscriptions 
  WHERE user_id = ? 
    AND status = 'active' 
    AND start_date <= CURDATE()
    AND end_date >= CURDATE()
  ORDER BY created_at DESC
  LIMIT 1
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$active_subscription = $stmt->get_result()->fetch_assoc();
$has_active_subscription = $active_subscription !== null;

if ($has_active_subscription) {
  $stmt = $conn->prepare("
    SELECT domain, category 
    FROM blocklist_subscription
  ");
  $stmt->execute();
  $res = $stmt->get_result();
  while ($row = $res->fetch_assoc()) {
    $exists = false;
    foreach ($blocked as $b) {
      if ($b['domain'] === $row['domain']) {
        $exists = true;
        break;
      }
    }
    if (!$exists) {
      $blocked[] = [
        'domain' => $row['domain'],
        'category' => $row['category'],
        'source' => 'subscription',
        'requires_subscription' => true
      ];
    }
  }
}

json_out([
  'blocked_domains' => $blocked,
  'count' => count($blocked),
  'permanent_count' => count(array_filter($blocked, fn($b) => isset($b['permanent']) && $b['permanent'])),
  'subscription_active' => $has_active_subscription
]);

