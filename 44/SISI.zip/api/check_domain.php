<?php
/**
 * Check if a domain should be allowed or blocked
 * Used by DNS/VPN filter for real-time decisions
 * 
 * Logic (BLOCKLIST-ONLY MODE - only block pornographic content):
 * 1. If domain in blocklist → BLOCK (pornographic content)
 * 2. Otherwise → ALLOW (normal internet access)
 * 
 * NOTE: 
 * - Whitelist is optional - only used for explicit overrides if needed
 * - For URL-level filtering (including paths), use check_url.php instead
 * - This blocks pornographic content on ALL browsers and devices
 */
require __DIR__ . '/../config.php';
require __DIR__ . '/../config_logging.php';
require __DIR__ . '/../auto_check_init.php'; // Auto-initialize blocklist if needed

$device_id = (int)($_GET['device_id'] ?? 0);
$domain = normalize_domain((string)($_GET['domain'] ?? ''));
$url = trim((string)($_GET['url'] ?? '')); // Optional: full URL for Google search detection

if ($device_id <= 0 || $domain === '') {
  json_out(['message' => 'device_id and domain required'], 422);
}

// If URL is provided and it's a Google search, extract and check the search query
// Also try to extract from domain if it contains search patterns
$search_query = '';
if (!empty($url) && stripos($domain, 'google.') !== false) {
  $parsed = parse_url($url);
  if ($parsed && isset($parsed['query'])) {
    parse_str($parsed['query'], $query_params);
    $search_query = trim((string)($query_params['q'] ?? $query_params['query'] ?? ''));
  }
}

// Fallback: If no URL provided but domain is Google, check if we can get search query from referrer
// This helps when the filter only passes domain but we need to check search queries
if (empty($search_query) && stripos($domain, 'google.') !== false && empty($url)) {
  // Try to get from HTTP_REFERER if available
  $referer = $_SERVER['HTTP_REFERER'] ?? '';
  if (!empty($referer) && stripos($referer, 'google.') !== false) {
    $parsed_ref = parse_url($referer);
    if ($parsed_ref && isset($parsed_ref['query'])) {
      parse_str($parsed_ref['query'], $ref_params);
      $search_query = trim((string)($ref_params['q'] ?? $ref_params['query'] ?? ''));
      $url = $referer; // Use referer as URL for logging
    }
  }
  
  // DEBUG: Log when URL is missing for Google domains (helps identify configuration issues)
  if (empty($search_query)) {
    error_log("WARNING: check_domain.php called for Google domain '{$domain}' without URL parameter. Google search blocking will NOT work. The DNS/VPN filter must pass the full URL: check_domain.php?device_id={$device_id}&domain={$domain}&url=https://...");
  }
}

// Get device info with user_id for logging
$stmt = $conn->prepare("SELECT id, status, user_id, permanent_blocked, admin_created FROM devices WHERE id=?");
$stmt->bind_param("i", $device_id);
$stmt->execute();
$device = $stmt->get_result()->fetch_assoc();

if (!$device) {
  json_out(['allowed' => false, 'reason' => 'device_not_found']);
}

$is_admin_created = (int)($device['admin_created'] ?? 0) === 1;
$permanent_blocked = (int)($device['permanent_blocked'] ?? 0);

// BELANGRIJK: Admin-created devices werken ALTIJD - lifetime toegang, geen abonnement nodig
if ($is_admin_created) {
  // Admin-created devices zijn permanent actief - altijd toegang, ook zonder abonnement
  // Zorg dat status altijd 'active' is
  if ($device['status'] !== 'active') {
    $stmt = $conn->prepare("UPDATE devices SET status = 'active' WHERE id = ? AND admin_created = 1");
    $stmt->bind_param("i", $device_id);
    $stmt->execute();
    // Reload device status
    $stmt = $conn->prepare("SELECT id, status, user_id FROM devices WHERE id=?");
    $stmt->bind_param("i", $device_id);
    $stmt->execute();
    $device = $stmt->get_result()->fetch_assoc();
  }
  // Skip subscription check - admin-created devices werken altijd
} else {
  // BELANGRIJK: Als device niet actief is maar er is een actief abonnement, activeer het direct
  // Dit zorgt ervoor dat het systeem direct werkt na abonnement aansluiten
  if ($device['status'] !== 'active') {
    $user_id = (int)$device['user_id'];
    
    // Check if subscription is active
    $stmt = $conn->prepare("
      SELECT id, plan
      FROM subscriptions 
      WHERE user_id = ? 
        AND status = 'active' 
        AND start_date <= CURDATE()
        AND end_date >= CURDATE()
      ORDER BY created_at DESC
      LIMIT 1
    ");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $active_subscription = $stmt->get_result()->fetch_assoc();
    
    // If subscription is active, automatically activate device (unless permanent_blocked)
    if ($active_subscription && $permanent_blocked === 0) {
      $stmt = $conn->prepare("UPDATE devices SET status = 'active' WHERE id = ?");
      $stmt->bind_param("i", $device_id);
      $stmt->execute();
      // Reload device status
      $stmt = $conn->prepare("SELECT id, status, user_id FROM devices WHERE id=?");
      $stmt->bind_param("i", $device_id);
      $stmt->execute();
      $device = $stmt->get_result()->fetch_assoc();
    } else {
      // No active subscription or permanent blocked - device stays inactive
      json_out(['allowed' => false, 'reason' => 'device_inactive']);
    }
  }
}

// STEP 1: Check PERMANENT blocklist FIRST (ALWAYS blocked, cannot be disabled)
// Pornografische content wordt NOOIT getoond - altijd geblokkeerd, onafhankelijk van alles
// This works independently of subscriptions - always blocked regardless of subscription status
// Check both exact match and subdomain match
// If xhamster.com is blocked, nl.xhamster.com should also be blocked
$stmt = $conn->prepare("
  SELECT domain, category 
  FROM blocklist_permanent 
  WHERE domain = ? OR ? LIKE CONCAT('%.', domain)
  LIMIT 1
");
$stmt->bind_param("ss", $domain, $domain);
$stmt->execute();
$blocked_permanent = $stmt->get_result()->fetch_assoc();

if ($blocked_permanent) {
  // Log blocked domain
  log_activity($conn, [
    'user_id' => $device['user_id'] ?? null,
    'device_id' => $device_id,
    'action' => 'blocked',
    'domain' => $domain,
    'reason' => 'permanent_blocklist',
    'category' => $blocked_permanent['category']
  ]);
  
  json_out([
    'allowed' => false,
    'reason' => 'blocked',
    'category' => $blocked_permanent['category'],
    'source' => 'permanent_blocklist',
    'permanent' => true,
    'cannot_disable' => true,
    'independent_of_subscription' => true,
    'never_visible' => true,
    'note' => 'Pornografische content wordt NOOIT getoond - permanente blokkering kan niet worden uitgeschakeld'
  ]);
}

// STEP 2: Check device-specific blocklist
$stmt = $conn->prepare("
  SELECT domain, category 
  FROM blocklist_device 
  WHERE device_id = ? AND domain = ? AND enabled = 1
  LIMIT 1
");
$stmt->bind_param("is", $device_id, $domain);
$stmt->execute();
$blocked_device = $stmt->get_result()->fetch_assoc();

if ($blocked_device) {
  // Log blocked domain
  log_activity($conn, [
    'user_id' => $device['user_id'] ?? null,
    'device_id' => $device_id,
    'action' => 'blocked',
    'domain' => $domain,
    'reason' => 'device_blocklist',
    'category' => $blocked_device['category']
  ]);
  
  json_out([
    'allowed' => false,
    'reason' => 'blocked',
    'category' => $blocked_device['category'],
    'source' => 'device_blocklist'
  ]);
}

// STEP 3: Check global blocklist
// Also check if the normalized domain (without subdomain) is in the blocklist
// This blocks subdomains like nl.xhamster.com when xhamster.com is blocked
$stmt = $conn->prepare("
  SELECT domain, category 
  FROM blocklist_global 
  WHERE (domain = ? OR ? LIKE CONCAT('%.', domain)) AND enabled = 1
  LIMIT 1
");
$stmt->bind_param("ss", $domain, $domain);
$stmt->execute();
$blocked_global = $stmt->get_result()->fetch_assoc();

if ($blocked_global) {
  // Log blocked domain
  log_activity($conn, [
    'user_id' => $device['user_id'] ?? null,
    'device_id' => $device_id,
    'action' => 'blocked',
    'domain' => $domain,
    'reason' => 'global_blocklist',
    'category' => $blocked_global['category']
  ]);
  
  json_out([
    'allowed' => false,
    'reason' => 'blocked',
    'category' => $blocked_global['category'],
    'source' => 'global_blocklist'
  ]);
}

// STEP 4: Check subscription blocklist (only if user has active subscription)
$stmt = $conn->prepare("SELECT user_id FROM devices WHERE id=?");
$stmt->bind_param("i", $device_id);
$stmt->execute();
$device_info = $stmt->get_result()->fetch_assoc();

if ($device_info) {
  $user_id = (int)$device_info['user_id'];
  // Check if subscription is active and start_date is today or earlier (works immediately)
  $stmt = $conn->prepare("
    SELECT id, plan
    FROM subscriptions 
    WHERE user_id = ? 
      AND status = 'active' 
      AND start_date <= CURDATE()
      AND end_date >= CURDATE()
    ORDER BY created_at DESC
    LIMIT 1
  ");
  $stmt->bind_param("i", $user_id);
  $stmt->execute();
  $active_subscription = $stmt->get_result()->fetch_assoc();
  $has_active_subscription = $active_subscription !== null;
  
  if ($has_active_subscription) {
    $stmt = $conn->prepare("
      SELECT domain, category 
      FROM blocklist_subscription 
      WHERE domain = ?
      LIMIT 1
    ");
    $stmt->bind_param("s", $domain);
    $stmt->execute();
    $blocked_subscription = $stmt->get_result()->fetch_assoc();
    
    if ($blocked_subscription) {
      // Log blocked domain
      log_activity($conn, [
        'user_id' => $user_id,
        'device_id' => $device_id,
        'action' => 'blocked',
        'domain' => $domain,
        'reason' => 'subscription_blocklist',
        'category' => $blocked_subscription['category']
      ]);
      
      json_out([
        'allowed' => false,
        'reason' => 'blocked',
        'category' => $blocked_subscription['category'],
        'source' => 'subscription_blocklist',
        'requires_subscription' => true,
        'note' => 'Blocked by subscription - will stop if subscription ends'
      ]);
    }
  }
}

// STEP 5: Check whitelist (optional override - BUT pornographic content can NEVER be whitelisted)
// NOTE: Permanent blocklist ALWAYS takes precedence - pornographic content is NEVER visible
$stmt = $conn->prepare("
  SELECT id, domain, enabled 
  FROM whitelist 
  WHERE device_id = ? AND domain = ? AND enabled = 1
  LIMIT 1
");
$stmt->bind_param("is", $device_id, $domain);
$stmt->execute();
$whitelisted = $stmt->get_result()->fetch_assoc();

// If explicitly whitelisted, allow ONLY if NOT in permanent blocklist
// Pornografische content wordt NOOIT getoond - permanente blocklist heeft altijd voorrang
if ($whitelisted) {
  // Double-check: permanent blocklist always wins
  $stmt = $conn->prepare("SELECT domain FROM blocklist_permanent WHERE domain = ? LIMIT 1");
  $stmt->bind_param("s", $domain);
  $stmt->execute();
  if ($stmt->get_result()->fetch_assoc()) {
    // Pornografische content - NOOIT toegestaan, zelfs niet via whitelist
    json_out([
      'allowed' => false,
      'reason' => 'blocked',
      'source' => 'permanent_blocklist',
      'note' => 'Pornografische content wordt NOOIT getoond - permanente blocklist heeft altijd voorrang'
    ]);
  }
  
  // Allow if not in permanent blocklist
  json_out([
    'allowed' => true,
    'reason' => 'whitelisted_override',
    'note' => 'Domain explicitly whitelisted - user override'
  ]);
}

// STEP 6: Check for pornographic keywords - AUTO-BLOCK new pornographic sites
// Meertalige detectie - werkt in alle talen
// AUTOMATISCH: Detecteert en blokkeert nieuwe pornografische sites direct
require __DIR__ . '/../config_keywords.php';
$porn_keywords = get_pornographic_keywords();

$domain_lower = strtolower($domain);
$is_pornographic = false;
$detected_keyword = '';

foreach ($porn_keywords as $keyword) {
    $keyword_lower = strtolower($keyword);
    if (strpos($domain_lower, $keyword_lower) !== false) {
        $is_pornographic = true;
        $detected_keyword = $keyword;
        break;
    }
}

// If domain contains pornographic keywords but not in blocklist yet, auto-block it
// AUTOMATISCH: Voegt toe aan zowel permanent als global blocklist
if ($is_pornographic) {
    // Get normalized domain (without subdomain) to block all subdomains
    $normalized_domain = normalize_domain($domain);
    
    // Automatically add normalized domain to permanent blocklist (always blocked, cannot be disabled)
    // This blocks all subdomains automatically (e.g., nl.xhamster.com → xhamster.com is blocked)
    try {
        $stmt = $conn->prepare("INSERT INTO blocklist_permanent (domain, category, source) VALUES (?, 'pornography', 'auto_block_keyword')");
        $stmt->bind_param("s", $normalized_domain);
        $stmt->execute();
    } catch (mysqli_sql_exception $e) {
        // Already exists or error - continue
    }
    
    // ALSO automatically add to global blocklist (always enabled, cannot be disabled)
    try {
        $stmt = $conn->prepare("INSERT INTO blocklist_global (domain, category, source, enabled) VALUES (?, 'pornography', 'auto_block_keyword', 1) ON DUPLICATE KEY UPDATE enabled = 1, source = 'auto_block_keyword'");
        $stmt->bind_param("s", $normalized_domain);
        $stmt->execute();
    } catch (mysqli_sql_exception $e) {
        // Already exists or error - continue
    }
    
    // Log auto-blocked domain
    log_activity($conn, [
        'user_id' => $device['user_id'] ?? null,
        'device_id' => $device_id,
        'action' => 'blocked',
        'domain' => $domain,
        'normalized_domain' => $normalized_domain,
        'reason' => 'auto_block_keyword',
        'category' => 'pornography',
        'keyword' => $detected_keyword
    ]);
    
    json_out([
        'allowed' => false,
        'reason' => 'blocked',
        'source' => 'auto_blocked',
        'keyword' => $detected_keyword,
        'normalized_domain' => $normalized_domain,
        'auto_added' => true,
        'note' => 'Nieuwe pornografische site automatisch gedetecteerd en toegevoegd aan permanente en globale blocklist. Alle subdomains worden automatisch geblokkeerd.'
    ]);
}

// STEP 6: Check for pornographic keywords in Google search queries
// This blocks pornographic searches even if google.nl itself is not blocked
if (!empty($search_query) && stripos($domain, 'google.') !== false) {
  require __DIR__ . '/../config_keywords.php';
  $porn_keywords = get_pornographic_keywords();
  
  $search_lower = strtolower(urldecode($search_query));
  foreach ($porn_keywords as $keyword) {
    $keyword_lower = strtolower($keyword);
    if (strpos($search_lower, $keyword_lower) !== false) {
      // Log blocked Google search
      log_activity($conn, [
        'user_id' => $device['user_id'] ?? null,
        'device_id' => $device_id,
        'action' => 'blocked',
        'domain' => $domain,
        'url' => $url,
        'reason' => 'google_search_pornographic_query',
        'category' => 'pornography',
        'search_query' => $search_query
      ]);
      
      json_out([
        'allowed' => false,
        'reason' => 'blocked',
        'source' => 'google_search_filter',
        'keyword' => $keyword,
        'search_query' => $search_query,
        'note' => 'Pornografische zoekopdracht in Google wordt geblokkeerd'
      ]);
    }
  }
}

// STEP 7: Default ALLOW (only block pornographic content in blocklist)
// Normal internet access - only pornographic sites are blocked
// NO WHITELIST REQUIRED - all normal websites work automatically
json_out([
  'allowed' => true,
  'reason' => 'allowed',
  'mode' => 'blocklist_only',
  'note' => 'Domain not in blocklist - normal internet access allowed. No whitelist required for normal websites.'
]);

