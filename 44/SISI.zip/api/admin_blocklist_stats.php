<?php
/**
 * Get blocklist statistics
 * Shows how many domains are permanently blocked
 */
require __DIR__ . '/../config.php';
$user = require_user($conn);

// Check admin
$stmt = $conn->prepare("SELECT is_admin FROM users WHERE id=?");
$stmt->bind_param("i", $user['id']);
$stmt->execute();
$result = $stmt->get_result()->fetch_assoc();
if (!$result || !$result['is_admin']) {
  json_out(['message' => 'Access denied'], 403);
}

$stats = [];

// Total blocked domains
$result = $conn->query("SELECT COUNT(*) as count FROM blocklist_global WHERE enabled = 1");
$stats['total_blocked'] = (int)$result->fetch_assoc()['count'];

// By category
$result = $conn->query("
  SELECT category, COUNT(*) as count 
  FROM blocklist_global 
  WHERE enabled = 1 
  GROUP BY category
");
$stats['by_category'] = [];
while ($row = $result->fetch_assoc()) {
  $stats['by_category'][$row['category']] = (int)$row['count'];
}

// Device-specific blocks
$result = $conn->query("SELECT COUNT(*) as count FROM blocklist_device WHERE enabled = 1");
$stats['device_specific_blocks'] = (int)$result->fetch_assoc()['count'];

json_out(['stats' => $stats]);

