<?php
/**
 * Admin API voor automatische blokkering instellingen
 * GET: Haal instellingen op
 * POST: Update instellingen
 */
require __DIR__ . '/../config.php';
$user = require_user($conn);

// Check admin
$stmt = $conn->prepare("SELECT is_admin FROM users WHERE id=?");
$stmt->bind_param("i", $user['id']);
$stmt->execute();
$result = $stmt->get_result()->fetch_assoc();
if (!$result || !$result['is_admin']) {
    json_out(['message' => 'Access denied'], 403);
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Get auto-block statistics
    $stmt = $conn->prepare("
        SELECT COUNT(*) as count, source 
        FROM blocklist_permanent 
        WHERE source LIKE 'auto_block%'
        GROUP BY source
    ");
    $stmt->execute();
    $res = $stmt->get_result();
    
    $stats = [];
    $total = 0;
    while ($row = $res->fetch_assoc()) {
        $stats[] = $row;
        $total += (int)$row['count'];
    }
    
    json_out([
        'auto_block_enabled' => true,
        'total_auto_blocked' => $total,
        'by_source' => $stats,
        'note' => 'Automatische blokkering is altijd actief - nieuwe pornografische sites worden automatisch gedetecteerd en geblokkeerd'
    ]);
    
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Manual trigger: scan and auto-block domains
    $body = json_decode(file_get_contents('php://input'), true) ?? [];
    $action = $body['action'] ?? 'scan';
    
    if ($action === 'scan') {
        // Get recent domains that might be pornographic but not yet blocked
        // This is a placeholder - in production you might want to scan logs or use other methods
        json_out([
            'status' => 'scan_complete',
            'note' => 'Automatische blokkering werkt real-time - geen scan nodig'
        ]);
    } else {
        json_out(['message' => 'Invalid action'], 422);
    }
}

