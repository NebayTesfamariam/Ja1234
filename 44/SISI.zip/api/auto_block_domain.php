<?php
/**
 * Automatisch een domain blokkeren als het pornografische content bevat
 * Wordt automatisch aangeroepen wanneer pornografische keywords worden gedetecteerd
 * 
 * Dit endpoint wordt intern gebruikt door check_url.php en check_domain.php
 * om nieuwe pornografische sites automatisch toe te voegen aan de permanente blocklist
 */
require __DIR__ . '/../config.php';

$domain = normalize_domain((string)($_GET['domain'] ?? $_POST['domain'] ?? ''));
$reason = trim((string)($_GET['reason'] ?? $_POST['reason'] ?? 'keyword_detection'));

if (empty($domain)) {
    json_out(['message' => 'domain required'], 422);
}

// Check if domain is already in permanent blocklist
$stmt = $conn->prepare("SELECT id FROM blocklist_permanent WHERE domain = ? LIMIT 1");
$stmt->bind_param("s", $domain);
$stmt->execute();
if ($stmt->get_result()->fetch_assoc()) {
    json_out(['status' => 'already_blocked', 'domain' => $domain]);
}

// Check if domain contains pornographic keywords
// Meertalige detectie - werkt in alle talen
require __DIR__ . '/../config_keywords.php';
$porn_keywords = get_pornographic_keywords();

$domain_lower = strtolower($domain);
$is_pornographic = false;
$detected_keyword = '';

foreach ($porn_keywords as $keyword) {
    $keyword_lower = strtolower($keyword);
    if (strpos($domain_lower, $keyword_lower) !== false) {
        $is_pornographic = true;
        $detected_keyword = $keyword;
        break;
    }
}

if (!$is_pornographic) {
    json_out(['status' => 'not_pornographic', 'domain' => $domain, 'note' => 'Domain does not contain pornographic keywords']);
}

// Automatically add to permanent blocklist (always blocked, cannot be disabled)
try {
    $stmt = $conn->prepare("INSERT INTO blocklist_permanent (domain, category, source) VALUES (?, 'pornography', ?)");
    $source = 'auto_block_' . $reason;
    $stmt->bind_param("ss", $domain, $source);
    $stmt->execute();
} catch (mysqli_sql_exception $e) {
    // Already exists or error - continue
}

// ALSO automatically add to global blocklist (always enabled, cannot be disabled)
try {
    $source = 'auto_block_' . $reason;
    $stmt = $conn->prepare("INSERT INTO blocklist_global (domain, category, source, enabled) VALUES (?, 'pornography', ?, 1) ON DUPLICATE KEY UPDATE enabled = 1, source = ?");
    $stmt->bind_param("sss", $domain, $source, $source);
    $stmt->execute();
} catch (mysqli_sql_exception $e) {
    // Already exists or error - continue
}

json_out([
    'status' => 'auto_blocked',
    'domain' => $domain,
    'keyword' => $detected_keyword,
    'source' => 'auto_block_' . $reason,
    'note' => 'Nieuwe pornografische site automatisch toegevoegd aan permanente en globale blocklist'
], 201);

