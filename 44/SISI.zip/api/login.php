<?php
/**
 * Login API
 * Handles user authentication
 */

// Error handling - log errors but don't expose details to user
error_reporting(E_ALL);
ini_set('display_errors', 0); // Don't display errors in production
ini_set('log_errors', 1);

try {
  require __DIR__ . '/../config.php';
} catch (Exception $e) {
  error_log("Config loading error: " . $e->getMessage());
  json_out(['message' => 'Configuration error'], 500);
}

// Only allow POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  json_out(['message' => 'Method not allowed'], 405);
}

$body = json_decode(file_get_contents('php://input'), true) ?? [];
$email = trim((string)($body['email'] ?? ''));
$password = (string)($body['password'] ?? '');

if (!$email || !$password) {
  json_out(['message' => 'Email/password required'], 422);
}

try {
  // Check database connection
  if (!isset($conn) || !($conn instanceof mysqli)) {
    error_log("Login error: Database connection not available");
    json_out(['message' => 'Database connection error'], 500);
  }
  
  // Check if connection is still alive
  if (!$conn->ping()) {
    error_log("Login error: Database connection lost");
    json_out(['message' => 'Database connection error'], 500);
  }
  
  $stmt = $conn->prepare("SELECT id, email, password_hash FROM users WHERE email=?");
  if (!$stmt) {
    error_log("Login error: Prepare failed - " . $conn->error);
    json_out(['message' => 'Database error'], 500);
  }
  
  $stmt->bind_param("s", $email);
  $stmt->execute();
  $user = $stmt->get_result()->fetch_assoc();

  if (!$user) {
    json_out(['message' => 'Ongeldige inloggegevens'], 401);
  }

  // Check if password_hash is valid
  if (empty($user['password_hash']) || strlen($user['password_hash']) < 10) {
    error_log("Login error: Invalid password hash for user " . $email);
    json_out(['message' => 'Ongeldige inloggegevens'], 401);
  }

  $password_valid = password_verify($password, $user['password_hash']);
  
  if (!$password_valid) {
    json_out(['message' => 'Ongeldige inloggegevens'], 401);
  }

  $prefix = substr($user['password_hash'], 0, 12);
  $token = base64_encode($user['id'] . ':' . $prefix);

  json_out([
    'token' => $token,
    'user' => ['id' => (int)$user['id'], 'email' => $user['email']]
  ]);
} catch (mysqli_sql_exception $e) {
  error_log("Login MySQL error: " . $e->getMessage());
  json_out(['message' => 'Database error'], 500);
} catch (Exception $e) {
  error_log("Login error: " . $e->getMessage() . " in " . $e->getFile() . ":" . $e->getLine());
  json_out(['message' => 'Server error'], 500);
}
