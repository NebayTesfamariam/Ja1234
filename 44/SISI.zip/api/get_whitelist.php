<?php
require __DIR__ . '/../config.php';
$user = require_user($conn);

$device_id = (int)($_GET['device_id'] ?? 0);
if ($device_id <= 0) json_out(['message' => 'device_id required'], 422);

// Check if user is admin
$is_admin = false;
$stmt = $conn->prepare("SELECT is_admin FROM users WHERE id = ?");
$stmt->bind_param("i", $user['id']);
$stmt->execute();
$user_info = $stmt->get_result()->fetch_assoc();
if ($user_info && (int)$user_info['is_admin'] === 1) {
  $is_admin = true;
}

// Check ownership (or admin can access any device)
if ($is_admin) {
  // Admin can access any device
  $stmt = $conn->prepare("SELECT id, status, permanent_blocked, admin_created, user_id FROM devices WHERE id=?");
  $stmt->bind_param("i", $device_id);
  $stmt->execute();
  $device = $stmt->get_result()->fetch_assoc();
} else {
  // Regular user can only access their own devices
  $stmt = $conn->prepare("SELECT id, status, permanent_blocked, admin_created, user_id FROM devices WHERE id=? AND user_id=?");
  $stmt->bind_param("ii", $device_id, $user['id']);
  $stmt->execute();
  $device = $stmt->get_result()->fetch_assoc();
}

if (!$device) json_out(['message' => 'Device not found'], 404);

// Check if device is admin_created - these work ALWAYS, lifetime, even without subscription
$is_admin_created = (int)($device['admin_created'] ?? 0) === 1;

// BELANGRIJK: Admin-created devices werken ALTIJD - lifetime toegang, geen abonnement nodig
if ($is_admin_created) {
  // Admin-created devices zijn permanent actief - altijd toegang, ook zonder abonnement
  // Zorg dat status altijd 'active' is
  if ($device['status'] !== 'active') {
    $stmt = $conn->prepare("UPDATE devices SET status = 'active' WHERE id = ? AND admin_created = 1");
    $stmt->bind_param("i", $device_id);
    $stmt->execute();
    // Reload device status
    if ($is_admin) {
      $stmt = $conn->prepare("SELECT id, status, permanent_blocked, admin_created, user_id FROM devices WHERE id=?");
      $stmt->bind_param("i", $device_id);
    } else {
      $stmt = $conn->prepare("SELECT id, status, permanent_blocked, admin_created, user_id FROM devices WHERE id=? AND user_id=?");
      $stmt->bind_param("ii", $device_id, $user['id']);
    }
    $stmt->execute();
    $device = $stmt->get_result()->fetch_assoc();
  }
  
  // Skip subscription check - admin-created devices werken altijd
  $subscription = null; // Don't check subscription for admin-created devices
} else {
  // Check if subscription is still active - if not, block device automatically (unless admin_created)
  // Use device owner's user_id, not the logged-in user (for admin access)
  $device_user_id = (int)$device['user_id'];
  $stmt = $conn->prepare("
    SELECT s.id, s.status, s.end_date
    FROM subscriptions s
    WHERE s.user_id = ? 
      AND s.status = 'active' 
      AND s.start_date <= CURDATE()
      AND s.end_date >= CURDATE()
    ORDER BY s.created_at DESC
    LIMIT 1
  ");
  $stmt->bind_param("i", $device_user_id);
  $stmt->execute();
  $subscription = $stmt->get_result()->fetch_assoc();

  // If no active subscription, automatically block device (but NOT permanent - can be unblocked when subscription reactivates)
  if (!$subscription) {
    // Only block if not already permanent_blocked by admin
    // First check if 'blocked' is in the ENUM, if not, try to fix it
    $result = $conn->query("SHOW COLUMNS FROM devices WHERE Field = 'status'");
    $status_col = $result->fetch_assoc();
    if ($status_col && stripos($status_col['Type'], 'blocked') === false) {
      // Try to fix the ENUM automatically
      try {
        $conn->query("ALTER TABLE devices MODIFY COLUMN `status` ENUM('active', 'inactive', 'pending', 'blocked') DEFAULT 'active'");
      } catch (Exception $e) {
        // If auto-fix fails, return error with instructions
        json_out([
          'error' => 'database_config_error',
          'message' => 'Database configuratie fout: status ENUM bevat geen "blocked". Voer fix_status_enum.php uit om dit te fixen.',
          'fix_url' => '/free/fix_status_enum.php',
          'note' => 'Open http://localhost/free/fix_status_enum.php in je browser om dit automatisch te fixen.'
        ], 500);
      }
    }
    
    $stmt = $conn->prepare("UPDATE devices SET status = 'blocked' WHERE id = ? AND permanent_blocked = 0");
    $stmt->bind_param("i", $device_id);
    if (!$stmt->execute()) {
      // If update fails due to ENUM issue, return helpful error
      if ($conn->errno === 1265 || $conn->errno === 1406) { // Data truncated error
        json_out([
          'error' => 'database_config_error',
          'message' => 'Database configuratie fout: status ENUM bevat geen "blocked". Voer fix_status_enum.php uit om dit te fixen.',
          'fix_url' => '/free/fix_status_enum.php',
          'note' => 'Open http://localhost/free/fix_status_enum.php in je browser om dit automatisch te fixen.'
        ], 500);
      } else {
        json_out(['error' => 'database_error', 'message' => 'Database error: ' . $conn->error], 500);
      }
    }
    json_out([
      'mode' => 'blocklist_only', 
      'entries' => [], 
      'device_blocked' => true, 
      'subscription_expired' => true,
      'note' => 'Abonnement is gestopt - device is geblokkeerd. Betaal opnieuw om service te hervatten.'
    ]);
  }
}

// If subscription is active again, automatically unblock device (unless permanent_blocked by admin)
// BELANGRIJK: Dit zorgt ervoor dat devices direct werken na abonnement aansluiten
if ($subscription && $device['status'] === 'blocked' && (int)$device['permanent_blocked'] === 0) {
  $stmt = $conn->prepare("UPDATE devices SET status = 'active' WHERE id = ?");
  $stmt->bind_param("i", $device_id);
  $stmt->execute();
  // Reload device status
  if ($is_admin) {
    $stmt = $conn->prepare("SELECT id, status, permanent_blocked, user_id FROM devices WHERE id=?");
    $stmt->bind_param("i", $device_id);
  } else {
    $stmt = $conn->prepare("SELECT id, status, permanent_blocked, user_id FROM devices WHERE id=? AND user_id=?");
    $stmt->bind_param("ii", $device_id, $user['id']);
  }
  $stmt->execute();
  $device = $stmt->get_result()->fetch_assoc();
}

// BELANGRIJK: Als device status 'inactive' of 'pending' is maar er is een actief abonnement, activeer het direct
// Dit zorgt ervoor dat het systeem direct werkt na abonnement aansluiten
if ($subscription && in_array($device['status'], ['inactive', 'pending']) && (int)$device['permanent_blocked'] === 0) {
  $stmt = $conn->prepare("UPDATE devices SET status = 'active' WHERE id = ?");
  $stmt->bind_param("i", $device_id);
  $stmt->execute();
  // Reload device status
  if ($is_admin) {
    $stmt = $conn->prepare("SELECT id, status, permanent_blocked, user_id FROM devices WHERE id=?");
    $stmt->bind_param("i", $device_id);
  } else {
    $stmt = $conn->prepare("SELECT id, status, permanent_blocked, user_id FROM devices WHERE id=? AND user_id=?");
    $stmt->bind_param("ii", $device_id, $user['id']);
  }
  $stmt->execute();
  $device = $stmt->get_result()->fetch_assoc();
}

// Blocked devices get empty whitelist (no internet access)
if ($device['status'] === 'blocked') {
  $is_permanent = (int)$device['permanent_blocked'] === 1;
  json_out([
    'mode' => 'blocklist_only', 
    'entries' => [], 
    'device_blocked' => true,
    'permanent_blocked' => $is_permanent,
    'note' => $is_permanent 
      ? 'Device is permanent geblokkeerd - kan NOOIT worden deblokkeerd' 
      : 'Device is blocked by admin - no internet access'
  ]);
}

// Inactive/pending devices also get empty whitelist
if ($device['status'] !== 'active') {
  json_out(['mode' => 'blocklist_only', 'entries' => []]);
}

$stmt = $conn->prepare("SELECT id, domain, enabled, comment, created_at FROM whitelist WHERE device_id=? ORDER BY domain ASC");
$stmt->bind_param("i", $device_id);
$stmt->execute();
$res = $stmt->get_result();

$entries = [];
while ($row = $res->fetch_assoc()) {
  $row['id'] = (int)$row['id'];
  $row['enabled'] = (int)$row['enabled'];
  $entries[] = $row;
}

// Also get blocklist for this device
$blocked = [];
$stmt_block = $conn->prepare("
  SELECT domain, category 
  FROM blocklist_device 
  WHERE device_id = ? AND enabled = 1
");
$stmt_block->bind_param("i", $device_id);
$stmt_block->execute();
$res_block = $stmt_block->get_result();
while ($row = $res_block->fetch_assoc()) {
  $blocked[] = ['domain' => $row['domain'], 'category' => $row['category'], 'source' => 'device'];
}

// Get global blocklist
$stmt_global = $conn->prepare("
  SELECT domain, category 
  FROM blocklist_global 
  WHERE enabled = 1
");
$stmt_global->execute();
$res_global = $stmt_global->get_result();
while ($row = $res_global->fetch_assoc()) {
  $exists = false;
  foreach ($blocked as $b) {
    if ($b['domain'] === $row['domain']) {
      $exists = true;
      break;
    }
  }
  if (!$exists) {
    $blocked[] = ['domain' => $row['domain'], 'category' => $row['category'], 'source' => 'global'];
  }
}

// IMPORTANT: Blocklist always takes precedence over whitelist
// Even if domain is in whitelist, if it's in blocklist → BLOCK

// Remove any whitelist entries that are also in blocklist
$filtered_entries = [];
foreach ($entries as $entry) {
  $is_blocked = false;
  foreach ($blocked as $block) {
    if ($block['domain'] === $entry['domain']) {
      $is_blocked = true;
      break;
    }
  }
  if (!$is_blocked) {
    $filtered_entries[] = $entry;
  }
}

json_out([
  'mode' => 'blocklist_only',
  'entries' => $filtered_entries,
  'blocked_domains' => $blocked,
  'blocked_count' => count($blocked),
  'note' => 'Blocklist mode: Only pornographic content is blocked. Normal internet access allowed. Whitelist is optional for explicit overrides.'
]);
