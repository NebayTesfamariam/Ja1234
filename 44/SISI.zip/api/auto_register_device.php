<?php
/**
 * Automatisch device registreren voor een gebruiker
 * Genereert automatisch WireGuard key en IP adres
 * Wordt aangeroepen na abonnement aansluiten
 */
require __DIR__ . '/../config.php';
$user = require_user($conn);

$body = json_decode(file_get_contents('php://input'), true) ?? [];
$device_name = trim((string)($body['device_name'] ?? 'Auto Device'));

// Check subscription
try {
  $stmt = $conn->prepare("
    SELECT s.*, p.max_devices
    FROM subscriptions s
    LEFT JOIN subscription_plans p ON p.name = s.plan
    WHERE s.user_id = ? 
      AND s.status = 'active' 
      AND s.start_date <= CURDATE()
      AND s.end_date >= CURDATE()
    ORDER BY s.created_at DESC
    LIMIT 1
  ");
  if (!$stmt) {
    json_out([
      'message' => 'Subscription system not initialized. Please run setup_subscriptions.php',
      'error' => 'Database table missing'
    ], 500);
    exit;
  }
  $stmt->bind_param("i", $user['id']);
  $stmt->execute();
  $subscription = $stmt->get_result()->fetch_assoc();
} catch (Exception $e) {
  json_out([
    'message' => 'Database error: ' . $e->getMessage(),
    'error' => 'Subscription check failed'
  ], 500);
  exit;
}

if (!$subscription) {
  json_out([
    'message' => 'Geen actief abonnement gevonden',
    'hint' => 'Abonnement vereist om devices toe te voegen.'
  ], 403);
}

// Count current devices
$stmt = $conn->prepare("SELECT COUNT(*) as count FROM devices WHERE user_id = ?");
$stmt->bind_param("i", $user['id']);
$stmt->execute();
$device_count = (int)$stmt->get_result()->fetch_assoc()['count'];
$max_devices = (int)$subscription['max_devices'];

if ($device_count >= $max_devices) {
  json_out([
    'message' => "Device limiet bereikt. Je plan ({$subscription['plan']}) staat {$max_devices} device(s) toe.",
    'device_count' => $device_count,
    'max_devices' => $max_devices
  ], 403);
}

// Generate automatic WireGuard public key (simulated - in production use real WireGuard)
// Format: base64 encoded random string (typical WireGuard key format)
$wg_public_key = base64_encode(random_bytes(32));

// Generate automatic IP address from range 10.10.0.0/24
// Find next available IP
$stmt = $conn->prepare("SELECT wg_ip FROM devices WHERE wg_ip LIKE '10.10.0.%' ORDER BY wg_ip DESC LIMIT 1");
$stmt->execute();
$last_ip = $stmt->get_result()->fetch_assoc();
$ip_num = 10; // Start from 10.10.0.10

if ($last_ip) {
  $parts = explode('.', $last_ip['wg_ip']);
  $ip_num = (int)$parts[3] + 1;
  if ($ip_num > 254) $ip_num = 10; // Wrap around
}

$wg_ip = "10.10.0.{$ip_num}";

// Check if device already exists for this user (by WireGuard key or IP)
// Prevent duplicate devices
$stmt = $conn->prepare("SELECT id, name, status FROM devices WHERE user_id = ? AND (wg_public_key = ? OR wg_ip = ?) LIMIT 1");
$stmt->bind_param("iss", $user['id'], $wg_public_key, $wg_ip);
$stmt->execute();
$existing_device = $stmt->get_result()->fetch_assoc();

if ($existing_device) {
  // Device already exists - return existing device info
  json_out([
    'status' => 'exists',
    'device_id' => (int)$existing_device['id'],
    'device_name' => $existing_device['name'],
    'wg_public_key' => $wg_public_key,
    'wg_ip' => $wg_ip,
    'message' => 'Device bestaat al - gebruikt bestaand device',
    'note' => 'Dit device is al geregistreerd voor je account.'
  ], 200);
}

// Generate device name if not provided
if (empty($device_name) || $device_name === 'Auto Device') {
  // Detect device type from user agent if available
  $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
  $device_type = 'Device';
  
  if (stripos($user_agent, 'iPhone') !== false) {
    $device_type = 'iPhone';
  } elseif (stripos($user_agent, 'iPad') !== false) {
    $device_type = 'iPad';
  } elseif (stripos($user_agent, 'Android') !== false) {
    $device_type = 'Android';
  } elseif (stripos($user_agent, 'Windows') !== false) {
    $device_type = 'Windows PC';
  } elseif (stripos($user_agent, 'Mac') !== false || stripos($user_agent, 'macOS') !== false) {
    $device_type = 'Mac';
  } elseif (stripos($user_agent, 'Linux') !== false) {
    $device_type = 'Linux PC';
  }
  
  $device_name = $device_type . ' ' . ($device_count + 1);
}

try {
  // Mark as auto_created when created via subscription (permanent, cannot be unblocked by user)
  $auto_created = 1; // Always mark as auto_created when created via subscription
  $stmt = $conn->prepare("INSERT INTO devices (user_id, name, wg_public_key, wg_ip, status, auto_created) VALUES (?,?,?,?,'active',?)");
  $stmt->bind_param("isssi", $user['id'], $device_name, $wg_public_key, $wg_ip, $auto_created);
  $stmt->execute();
  $device_id = $stmt->insert_id;
  
  json_out([
    'status' => 'ok',
    'device_id' => $device_id,
    'device_name' => $device_name,
    'wg_public_key' => $wg_public_key,
    'wg_ip' => $wg_ip,
    'message' => '✅ Device automatisch geregistreerd → ✅ Direct beschermd!',
    'note' => 'Pornografische content wordt nu automatisch geblokkeerd op dit device.'
  ], 201);
} catch (mysqli_sql_exception $e) {
  json_out(['message' => 'Database error: ' . $e->getMessage()], 500);
}

