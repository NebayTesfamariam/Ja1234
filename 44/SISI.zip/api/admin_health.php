<?php
/**
 * System Health Check
 * Checks database, API endpoints, disk space, etc.
 */
require __DIR__ . '/../config.php';
$user = require_user($conn);

// Check admin
$stmt = $conn->prepare("SELECT is_admin FROM users WHERE id=?");
$stmt->bind_param("i", $user['id']);
$stmt->execute();
$result = $stmt->get_result()->fetch_assoc();
if (!$result || !$result['is_admin']) {
  json_out(['message' => 'Access denied'], 403);
}

$health = [
  'status' => 'healthy',
  'timestamp' => date('Y-m-d H:i:s'),
  'checks' => []
];

// 1. Database Connection Check
try {
  $conn->ping();
  $health['checks']['database'] = [
    'status' => 'ok',
    'message' => 'Database verbinding succesvol',
    'response_time' => 'OK'
  ];
} catch (Exception $e) {
  $health['status'] = 'unhealthy';
  $health['checks']['database'] = [
    'status' => 'error',
    'message' => 'Database verbinding mislukt: ' . $e->getMessage()
  ];
}

// 2. Database Tables Check
$required_tables = ['users', 'devices', 'whitelist', 'subscriptions', 'blocklist_permanent', 'blocklist_global', 'activity_logs'];
$missing_tables = [];
foreach ($required_tables as $table) {
  $result = $conn->query("SHOW TABLES LIKE '{$table}'");
  if ($result->num_rows === 0) {
    $missing_tables[] = $table;
  }
}
if (empty($missing_tables)) {
  $health['checks']['tables'] = [
    'status' => 'ok',
    'message' => 'Alle vereiste tabellen aanwezig',
    'count' => count($required_tables)
  ];
} else {
  $health['status'] = 'unhealthy';
  $health['checks']['tables'] = [
    'status' => 'error',
    'message' => 'Ontbrekende tabellen: ' . implode(', ', $missing_tables),
    'missing' => $missing_tables
  ];
}

// 3. API Endpoints Check
$endpoints = [
  'login.php' => 'POST',
  'get_devices.php' => 'GET',
  'check_domain.php' => 'GET',
  'admin_stats.php' => 'GET'
];
$endpoint_status = [];
foreach ($endpoints as $endpoint => $method) {
  $file = __DIR__ . '/' . $endpoint;
  if (file_exists($file)) {
    $endpoint_status[$endpoint] = 'ok';
  } else {
    $endpoint_status[$endpoint] = 'missing';
    $health['status'] = 'unhealthy';
  }
}
$health['checks']['api'] = [
  'status' => empty(array_filter($endpoint_status, fn($s) => $s === 'missing')) ? 'ok' : 'error',
  'message' => empty(array_filter($endpoint_status, fn($s) => $s === 'missing')) 
    ? 'Alle API endpoints aanwezig' 
    : 'Sommige endpoints ontbreken',
  'endpoints' => $endpoint_status
];

// 4. Disk Space Check
$disk_free = disk_free_space(__DIR__);
$disk_total = disk_total_space(__DIR__);
$disk_used_percent = (($disk_total - $disk_free) / $disk_total) * 100;
$health['checks']['disk'] = [
  'status' => $disk_used_percent > 90 ? 'warning' : ($disk_used_percent > 95 ? 'error' : 'ok'),
  'message' => sprintf('Disk gebruik: %.1f%% (%.2f GB vrij van %.2f GB)', 
    $disk_used_percent, 
    $disk_free / 1024 / 1024 / 1024,
    $disk_total / 1024 / 1024 / 1024
  ),
  'free_gb' => round($disk_free / 1024 / 1024 / 1024, 2),
  'total_gb' => round($disk_total / 1024 / 1024 / 1024, 2),
  'used_percent' => round($disk_used_percent, 1)
];

// 5. PHP Version Check
$php_version = PHP_VERSION;
$php_ok = version_compare($php_version, '7.4', '>=');
$health['checks']['php'] = [
  'status' => $php_ok ? 'ok' : 'warning',
  'message' => 'PHP versie: ' . $php_version . ($php_ok ? ' (OK)' : ' (Aanbevolen: 7.4+)'),
  'version' => $php_version
];

// 6. Database Size Check
try {
  $result = $conn->query("
    SELECT 
      ROUND(SUM(data_length + index_length) / 1024 / 1024, 2) AS size_mb,
      COUNT(*) as table_count
    FROM information_schema.tables 
    WHERE table_schema = DATABASE()
  ");
  $db_info = $result->fetch_assoc();
  $health['checks']['database_size'] = [
    'status' => 'ok',
    'message' => sprintf('Database grootte: %.2f MB (%d tabellen)', 
      $db_info['size_mb'] ?? 0,
      $db_info['table_count'] ?? 0
    ),
    'size_mb' => round($db_info['size_mb'] ?? 0, 2),
    'table_count' => (int)($db_info['table_count'] ?? 0)
  ];
} catch (Exception $e) {
  $health['checks']['database_size'] = [
    'status' => 'error',
    'message' => 'Kon database grootte niet bepalen'
  ];
}

// 7. Recent Activity Check
try {
  $result = $conn->query("
    SELECT COUNT(*) as count 
    FROM activity_logs 
    WHERE created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
  ");
  $activity = $result->fetch_assoc();
  $health['checks']['activity'] = [
    'status' => 'ok',
    'message' => sprintf('%d activiteiten in laatste 24 uur', $activity['count'] ?? 0),
    'count_24h' => (int)($activity['count'] ?? 0)
  ];
} catch (Exception $e) {
  $health['checks']['activity'] = [
    'status' => 'warning',
    'message' => 'Activity logs tabel niet beschikbaar'
  ];
}

// 8. Last Backup Check
$backup_dir = __DIR__ . '/../backups';
$last_backup = null;
if (is_dir($backup_dir)) {
  $files = glob($backup_dir . '/*.sql');
  if (!empty($files)) {
    usort($files, function($a, $b) {
      return filemtime($b) - filemtime($a);
    });
    $last_backup = [
      'file' => basename($files[0]),
      'date' => date('Y-m-d H:i:s', filemtime($files[0])),
      'age_hours' => round((time() - filemtime($files[0])) / 3600, 1)
    ];
  }
}

$health['checks']['backup'] = [
  'status' => $last_backup ? ($last_backup['age_hours'] > 48 ? 'warning' : 'ok') : 'warning',
  'message' => $last_backup 
    ? sprintf('Laatste backup: %s (%.1f uur geleden)', $last_backup['date'], $last_backup['age_hours'])
    : 'Geen backups gevonden',
  'last_backup' => $last_backup
];

json_out($health);

