<?php
require __DIR__ . '/../config.php';
$user = require_user($conn);

$body = json_decode(file_get_contents('php://input'), true) ?? [];
$name = trim((string)($body['name'] ?? ''));
$wg_public_key = trim((string)($body['wg_public_key'] ?? ''));
$wg_ip = trim((string)($body['wg_ip'] ?? ''));

if ($name === '' || $wg_public_key === '' || $wg_ip === '') {
  json_out(['message' => 'name, wg_public_key, wg_ip required'], 422);
}

// Basic validation
if (strlen($name) > 255) {
  json_out(['message' => 'Naam is te lang (max 255 karakters)'], 422);
}
if (strlen($wg_public_key) > 255) {
  json_out(['message' => 'WireGuard key is te lang'], 422);
}
if (!filter_var($wg_ip, FILTER_VALIDATE_IP)) {
  json_out(['message' => 'Ongeldig IP adres'], 422);
}

// Check subscription and device limit
// Subscription must be active and start_date must be today or earlier (works immediately)
$stmt = $conn->prepare("
  SELECT s.*, p.max_devices
  FROM subscriptions s
  LEFT JOIN subscription_plans p ON p.name = s.plan
  WHERE s.user_id = ? 
    AND s.status = 'active' 
    AND s.start_date <= CURDATE()
    AND s.end_date >= CURDATE()
  ORDER BY s.created_at DESC
  LIMIT 1
");
$stmt->bind_param("i", $user['id']);
$stmt->execute();
$subscription = $stmt->get_result()->fetch_assoc();

if (!$subscription) {
  json_out([
    'message' => 'Geen actief abonnement. Abonnement vereist om devices toe te voegen.',
    'hint' => 'Neem contact op met admin om een abonnement aan te maken.'
  ], 403);
}

// Count current devices
$stmt = $conn->prepare("SELECT COUNT(*) as count FROM devices WHERE user_id = ?");
$stmt->bind_param("i", $user['id']);
$stmt->execute();
$device_count = (int)$stmt->get_result()->fetch_assoc()['count'];
$max_devices = (int)$subscription['max_devices'];

if ($device_count >= $max_devices) {
  json_out([
    'message' => "Device limiet bereikt. Je plan ({$subscription['plan']}) staat {$max_devices} device(s) toe. Upgrade je plan om meer devices toe te voegen.",
    'device_count' => $device_count,
    'max_devices' => $max_devices,
    'plan' => $subscription['plan']
  ], 403);
}

// Check if device already exists for this user (by WireGuard key or IP)
// Prevent duplicate devices
$stmt = $conn->prepare("SELECT id, name, status FROM devices WHERE user_id = ? AND (wg_public_key = ? OR wg_ip = ?) LIMIT 1");
$stmt->bind_param("iss", $user['id'], $wg_public_key, $wg_ip);
$stmt->execute();
$existing_device = $stmt->get_result()->fetch_assoc();

if ($existing_device) {
  // Device already exists - return existing device info
  json_out([
    'status' => 'exists',
    'device_id' => (int)$existing_device['id'],
    'device_name' => $existing_device['name'],
    'message' => 'Device bestaat al - dit device is al geregistreerd voor je account',
    'note' => 'Je kunt dit device gebruiken zonder het opnieuw toe te voegen.'
  ], 200);
}

try {
  $stmt = $conn->prepare("INSERT INTO devices (user_id, name, wg_public_key, wg_ip) VALUES (?,?,?,?)");
  $stmt->bind_param("isss", $user['id'], $name, $wg_public_key, $wg_ip);
  $stmt->execute();
  json_out(['status' => 'ok', 'device_id' => $stmt->insert_id], 201);
} catch (mysqli_sql_exception $e) {
  if ($conn->errno === 1062) {
    // Duplicate entry - device already exists
    json_out([
      'status' => 'exists',
      'message' => 'Device bestaat al - dit device is al geregistreerd voor je account'
    ], 200);
  } else {
    json_out(['message' => 'Database error: ' . $e->getMessage()], 500);
  }
}
