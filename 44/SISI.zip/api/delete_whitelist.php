<?php
require __DIR__ . '/../config.php';
$user = require_user($conn);

$body = json_decode(file_get_contents('php://input'), true) ?? [];
$id = (int)($body['id'] ?? 0);
if ($id <= 0) json_out(['message' => 'id required'], 422);

$stmt = $conn->prepare("
  DELETE w FROM whitelist w
  JOIN devices d ON d.id = w.device_id
  WHERE w.id=? AND d.user_id=?
");
$stmt->bind_param("ii", $id, $user['id']);
$stmt->execute();

json_out(['ok' => true]);
