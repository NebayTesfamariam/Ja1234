<?php
require __DIR__ . '/../config.php';
$user = require_user($conn);

// Check admin
$stmt = $conn->prepare("SELECT is_admin FROM users WHERE id=?");
$stmt->bind_param("i", $user['id']);
$stmt->execute();
$result = $stmt->get_result()->fetch_assoc();
if (!$result || !$result['is_admin']) {
  json_out(['message' => 'Access denied'], 403);
}

$type = $_GET['type'] ?? 'global'; // 'global' or 'device'
$device_id = isset($_GET['device_id']) ? (int)$_GET['device_id'] : 0;

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
  // Get blocklist entries
  if ($type === 'global') {
    $stmt = $conn->prepare("
      SELECT id, domain, category, source, enabled, created_at 
      FROM blocklist_global 
      ORDER BY domain ASC
    ");
    $stmt->execute();
    $res = $stmt->get_result();
    
    $entries = [];
    while ($row = $res->fetch_assoc()) {
      $row['id'] = (int)$row['id'];
      $row['enabled'] = (bool)$row['enabled'];
      $entries[] = $row;
    }
    
    json_out(['entries' => $entries, 'type' => 'global']);
    
  } elseif ($type === 'device' && $device_id > 0) {
    $stmt = $conn->prepare("
      SELECT id, device_id, domain, category, enabled, created_at 
      FROM blocklist_device 
      WHERE device_id = ?
      ORDER BY domain ASC
    ");
    $stmt->bind_param("i", $device_id);
    $stmt->execute();
    $res = $stmt->get_result();
    
    $entries = [];
    while ($row = $res->fetch_assoc()) {
      $row['id'] = (int)$row['id'];
      $row['device_id'] = (int)$row['device_id'];
      $row['enabled'] = (bool)$row['enabled'];
      $entries[] = $row;
    }
    
    json_out(['entries' => $entries, 'type' => 'device', 'device_id' => $device_id]);
  }
  
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
  // Add blocklist entry
  $body = json_decode(file_get_contents('php://input'), true) ?? [];
  $domain = normalize_domain((string)($body['domain'] ?? ''));
  $category = trim((string)($body['category'] ?? 'pornography'));
  $source = trim((string)($body['source'] ?? 'manual'));
  $enabled = isset($body['enabled']) ? (int)(bool)$body['enabled'] : 1;
  
  if ($domain === '') {
    json_out(['message' => 'domain required'], 422);
  }
  
  if ($type === 'global') {
    // Automatically added entries (auto_block_*) are always enabled and cannot be disabled
    // Manual entries can be enabled/disabled
    $is_auto = strpos($source, 'auto_block') !== false;
    if ($is_auto) {
      $enabled = 1; // Force enabled for auto-added entries
    }
    
    try {
      $stmt = $conn->prepare("INSERT INTO blocklist_global (domain, category, source, enabled) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE enabled = ?");
      $stmt->bind_param("sssii", $domain, $category, $source, $enabled, $enabled);
      $stmt->execute();
      json_out(['status' => 'added', 'id' => $stmt->insert_id], 201);
    } catch (mysqli_sql_exception $e) {
      if ($conn->errno === 1062) {
        json_out(['message' => 'Domain already in blocklist'], 409);
      }
      json_out(['message' => 'Database error'], 500);
    }
    
  } elseif ($type === 'device' && $device_id > 0) {
    try {
      $stmt = $conn->prepare("INSERT INTO blocklist_device (device_id, domain, category, enabled) VALUES (?, ?, ?, ?)");
      $stmt->bind_param("issi", $device_id, $domain, $category, $enabled);
      $stmt->execute();
      json_out(['status' => 'added', 'id' => $stmt->insert_id], 201);
    } catch (mysqli_sql_exception $e) {
      if ($conn->errno === 1062) {
        json_out(['message' => 'Domain already in blocklist for this device'], 409);
      }
      json_out(['message' => 'Database error'], 500);
    }
  }
  
} elseif ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
  // Delete blocklist entry
  $body = json_decode(file_get_contents('php://input'), true) ?? [];
  $id = (int)($body['id'] ?? 0);
  
  if ($id <= 0) {
    json_out(['message' => 'id required'], 422);
  }
  
  if ($type === 'global') {
    // ALL domains in Global Blocklist cannot be deleted - both auto-added and manually added
    // This ensures pornographic content is always blocked
    json_out(['message' => 'Domains in de Global Blocklist kunnen niet worden verwijderd. Alle pornografische sites moeten geblokkeerd blijven - zowel automatisch als handmatig toegevoegde domains zijn permanent.'], 403);
    
  } elseif ($type === 'device') {
    $stmt = $conn->prepare("DELETE FROM blocklist_device WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    json_out(['status' => 'deleted']);
  }
}

