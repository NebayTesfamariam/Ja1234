<?php
/**
 * Admin endpoint for SUBSCRIPTION blocklist
 * These domains are only blocked when user has active subscription
 */
require __DIR__ . '/../config.php';
$user = require_user($conn);

// Check admin
$stmt = $conn->prepare("SELECT is_admin FROM users WHERE id=?");
$stmt->bind_param("i", $user['id']);
$stmt->execute();
$result = $stmt->get_result()->fetch_assoc();
if (!$result || !$result['is_admin']) {
  json_out(['message' => 'Access denied'], 403);
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
  // Get all subscription blocklist entries
  $stmt = $conn->prepare("
    SELECT id, domain, category, source, created_at 
    FROM blocklist_subscription 
    ORDER BY domain ASC
  ");
  $stmt->execute();
  $res = $stmt->get_result();
  
  $entries = [];
  while ($row = $res->fetch_assoc()) {
    $row['id'] = (int)$row['id'];
    $entries[] = $row;
  }
  
  json_out(['entries' => $entries, 'type' => 'subscription']);
  
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
  // Add to subscription blocklist
  $body = json_decode(file_get_contents('php://input'), true) ?? [];
  $domain = normalize_domain((string)($body['domain'] ?? ''));
  $category = trim((string)($body['category'] ?? 'pornography'));
  $source = trim((string)($body['source'] ?? 'subscription'));
  
  if ($domain === '') {
    json_out(['message' => 'domain required'], 422);
  }
  
  try {
    $stmt = $conn->prepare("INSERT INTO blocklist_subscription (domain, category, source) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $domain, $category, $source);
    $stmt->execute();
    json_out(['status' => 'added', 'id' => $stmt->insert_id, 'note' => 'Only active when user has subscription'], 201);
  } catch (mysqli_sql_exception $e) {
    if ($conn->errno === 1062) {
      json_out(['message' => 'Domain already in subscription blocklist'], 409);
    }
    json_out(['message' => 'Database error'], 500);
  }
  
} elseif ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
  // Delete from subscription blocklist
  $body = json_decode(file_get_contents('php://input'), true) ?? [];
  $id = (int)($body['id'] ?? 0);
  
  if ($id <= 0) {
    json_out(['message' => 'id required'], 422);
  }
  
  $stmt = $conn->prepare("DELETE FROM blocklist_subscription WHERE id = ?");
  $stmt->bind_param("i", $id);
  $stmt->execute();
  
  json_out(['status' => 'deleted']);
}

