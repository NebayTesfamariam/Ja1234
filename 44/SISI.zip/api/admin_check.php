<?php
require __DIR__ . '/../config.php';
$user = require_user($conn);

// Check if user is admin
$stmt = $conn->prepare("SELECT is_admin FROM users WHERE id=?");
$stmt->bind_param("i", $user['id']);
$stmt->execute();
$result = $stmt->get_result()->fetch_assoc();

if (!$result || !$result['is_admin']) {
  json_out(['message' => 'Access denied - admin only'], 403);
}

json_out([
  'is_admin' => true,
  'user' => ['id' => (int)$user['id'], 'email' => $user['email']]
]);

