<?php
require __DIR__ . '/../config.php';
$user = require_user($conn);

$body = json_decode(file_get_contents('php://input'), true) ?? [];
$device_id = (int)($body['device_id'] ?? 0);
$domain = normalize_domain((string)($body['domain'] ?? ''));
$comment = trim((string)($body['comment'] ?? ''));

if ($device_id <= 0 || $domain === '') json_out(['message' => 'device_id and domain required'], 422);

// Check if domain is in permanent blocklist - pornografische content kan NOOIT worden toegestaan
$stmt = $conn->prepare("SELECT domain FROM blocklist_permanent WHERE domain = ? LIMIT 1");
$stmt->bind_param("s", $domain);
$stmt->execute();
if ($stmt->get_result()->fetch_assoc()) {
  json_out(['message' => 'Pornografische content kan NOOIT worden toegestaan via whitelist. Deze site staat in de permanente blocklist.'], 403);
}

// Check if domain is in global blocklist (pornography category)
$stmt = $conn->prepare("SELECT domain, category FROM blocklist_global WHERE domain = ? AND enabled = 1 AND category = 'pornography' LIMIT 1");
$stmt->bind_param("s", $domain);
$stmt->execute();
if ($stmt->get_result()->fetch_assoc()) {
  json_out(['message' => 'Pornografische content kan niet worden toegestaan via whitelist. Deze site staat in de blocklist.'], 403);
}

// check device belongs to user
$stmt = $conn->prepare("SELECT id FROM devices WHERE id=? AND user_id=? AND status='active'");
$stmt->bind_param("ii", $device_id, $user['id']);
$stmt->execute();
if (!$stmt->get_result()->fetch_assoc()) json_out(['message' => 'Device not found'], 404);

try {
  $stmt = $conn->prepare("INSERT INTO whitelist (device_id, domain, enabled, comment) VALUES (?,?,1,?)");
  $stmt->bind_param("iss", $device_id, $domain, $comment);
  $stmt->execute();
  json_out(['status' => 'added', 'id' => $stmt->insert_id], 201);
} catch (mysqli_sql_exception $e) {
  if ($conn->errno === 1062) { // Duplicate entry
    json_out(['message' => 'Dit domein staat al in de whitelist voor dit device'], 409);
  }
  json_out(['message' => 'Database error: ' . $e->getMessage()], 500);
}
