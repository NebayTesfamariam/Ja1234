<?php
/**
 * Import blocklist from text file or array
 * Admin only
 */
require __DIR__ . '/../config.php';
$user = require_user($conn);

// Check admin
$stmt = $conn->prepare("SELECT is_admin FROM users WHERE id=?");
$stmt->bind_param("i", $user['id']);
$stmt->execute();
$result = $stmt->get_result()->fetch_assoc();
if (!$result || !$result['is_admin']) {
  json_out(['message' => 'Access denied'], 403);
}

$body = json_decode(file_get_contents('php://input'), true) ?? [];
$domains = $body['domains'] ?? [];
$category = trim((string)($body['category'] ?? 'pornography'));
$source = trim((string)($body['source'] ?? 'import'));

if (empty($domains) || !is_array($domains)) {
  json_out(['message' => 'domains array required'], 422);
}

$added = 0;
$skipped = 0;
$errors = [];

foreach ($domains as $domain) {
  $domain = normalize_domain((string)$domain);
  if (empty($domain)) {
    $skipped++;
    continue;
  }
  
  try {
    $stmt = $conn->prepare("INSERT INTO blocklist_global (domain, category, source, enabled) VALUES (?, ?, ?, 1)");
    $stmt->bind_param("sss", $domain, $category, $source);
    $stmt->execute();
    $added++;
  } catch (mysqli_sql_exception $e) {
    if ($conn->errno === 1062) {
      $skipped++; // Already exists
    } else {
      $errors[] = $domain . ': ' . $e->getMessage();
    }
  }
}

json_out([
  'status' => 'completed',
  'added' => $added,
  'skipped' => $skipped,
  'errors' => $errors
]);

