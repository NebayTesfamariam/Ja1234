<?php
/**
 * Check if a URL should be allowed or blocked
 * Used by DNS/VPN filter for real-time decisions
 * 
 * This checks both domain AND URL path to block pornographic content
 * even when embedded in normal sites or accessed via different browsers
 * 
 * Logic:
 * 1. Extract domain from URL
 * 2. Check if domain is in blocklist → BLOCK
 * 3. Check if URL path contains pornographic keywords → BLOCK
 * 4. Otherwise → ALLOW
 */
require __DIR__ . '/../config.php';
require __DIR__ . '/../config_logging.php';
require __DIR__ . '/../auto_check_init.php'; // Auto-initialize blocklist if needed

$device_id = (int)($_GET['device_id'] ?? 0);
$url = trim((string)($_GET['url'] ?? ''));

if ($device_id <= 0 || $url === '') {
  json_out(['message' => 'device_id and url required'], 422);
}

// Parse URL
$parsed = parse_url($url);
if (!$parsed || !isset($parsed['host'])) {
  json_out(['allowed' => false, 'reason' => 'invalid_url']);
}

$domain = normalize_domain($parsed['host']);
$path = $parsed['path'] ?? '';
$query = $parsed['query'] ?? '';
$full_path = $path . ($query ? '?' . $query : '');

// Special handling for Google search URLs - extract search query
$search_query = '';
if (stripos($domain, 'google.') !== false && isset($parsed['query'])) {
  parse_str($parsed['query'], $query_params);
  $search_query = trim((string)($query_params['q'] ?? $query_params['query'] ?? ''));
}

// Get device info with user_id for logging
$stmt = $conn->prepare("SELECT id, status, user_id, permanent_blocked, admin_created FROM devices WHERE id=?");
$stmt->bind_param("i", $device_id);
$stmt->execute();
$device = $stmt->get_result()->fetch_assoc();

if (!$device) {
  json_out(['allowed' => false, 'reason' => 'device_not_found']);
}

$is_admin_created = (int)($device['admin_created'] ?? 0) === 1;
$permanent_blocked = (int)($device['permanent_blocked'] ?? 0);

// BELANGRIJK: Admin-created devices werken ALTIJD - lifetime toegang, geen abonnement nodig
if ($is_admin_created) {
  // Admin-created devices zijn permanent actief - altijd toegang, ook zonder abonnement
  // Zorg dat status altijd 'active' is
  if ($device['status'] !== 'active') {
    $stmt = $conn->prepare("UPDATE devices SET status = 'active' WHERE id = ? AND admin_created = 1");
    $stmt->bind_param("i", $device_id);
    $stmt->execute();
    // Reload device status
    $stmt = $conn->prepare("SELECT id, status, user_id FROM devices WHERE id=?");
    $stmt->bind_param("i", $device_id);
    $stmt->execute();
    $device = $stmt->get_result()->fetch_assoc();
  }
  // Skip subscription check - admin-created devices werken altijd
} else {
  // BELANGRIJK: Als device niet actief is maar er is een actief abonnement, activeer het direct
  // Dit zorgt ervoor dat het systeem direct werkt na abonnement aansluiten
  if ($device['status'] !== 'active') {
    $user_id = (int)$device['user_id'];
    
    // Check if subscription is active
    $stmt = $conn->prepare("
      SELECT id, plan
      FROM subscriptions 
      WHERE user_id = ? 
        AND status = 'active' 
        AND start_date <= CURDATE()
        AND end_date >= CURDATE()
      ORDER BY created_at DESC
      LIMIT 1
    ");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $active_subscription = $stmt->get_result()->fetch_assoc();
    
    // If subscription is active, automatically activate device (unless permanent_blocked)
    if ($active_subscription && $permanent_blocked === 0) {
      $stmt = $conn->prepare("UPDATE devices SET status = 'active' WHERE id = ?");
      $stmt->bind_param("i", $device_id);
      $stmt->execute();
      // Reload device status
      $stmt = $conn->prepare("SELECT id, status, user_id FROM devices WHERE id=?");
      $stmt->bind_param("i", $device_id);
      $stmt->execute();
      $device = $stmt->get_result()->fetch_assoc();
    } else {
      // No active subscription or permanent blocked - device stays inactive
      json_out(['allowed' => false, 'reason' => 'device_inactive']);
    }
  }
}

// STEP 1: Check domain in blocklist (same as check_domain.php)
// Check PERMANENT blocklist
// Also check if the normalized domain (without subdomain) is in the blocklist
// This blocks subdomains like nl.xhamster.com when xhamster.com is blocked
$stmt = $conn->prepare("SELECT domain, category FROM blocklist_permanent WHERE domain = ? OR ? LIKE CONCAT('%.', domain) LIMIT 1");
$stmt->bind_param("ss", $domain, $domain);
$stmt->execute();
$permanent_block = $stmt->get_result()->fetch_assoc();
if ($permanent_block) {
  // Log blocked URL
  log_activity($conn, [
    'user_id' => $device['user_id'] ?? null,
    'device_id' => $device_id,
    'action' => 'blocked',
    'domain' => $domain,
    'url' => $url,
    'reason' => 'permanent_blocklist',
    'category' => $permanent_block['category']
  ]);
  
  json_out([
    'allowed' => false,
    'reason' => 'blocked',
    'source' => 'permanent_blocklist',
    'note' => 'Pornografische content wordt NOOIT getoond'
  ]);
}

// Check device blocklist
$stmt = $conn->prepare("SELECT domain FROM blocklist_device WHERE device_id = ? AND domain = ? AND enabled = 1 LIMIT 1");
$stmt->bind_param("is", $device_id, $domain);
$stmt->execute();
if ($stmt->get_result()->fetch_assoc()) {
  json_out(['allowed' => false, 'reason' => 'blocked', 'source' => 'device_blocklist']);
}

// Check global blocklist
// Also check if the normalized domain (without subdomain) is in the blocklist
// This blocks subdomains like nl.xhamster.com when xhamster.com is blocked
$stmt = $conn->prepare("SELECT domain FROM blocklist_global WHERE (domain = ? OR ? LIKE CONCAT('%.', domain)) AND enabled = 1 LIMIT 1");
$stmt->bind_param("ss", $domain, $domain);
$stmt->execute();
if ($stmt->get_result()->fetch_assoc()) {
  json_out(['allowed' => false, 'reason' => 'blocked', 'source' => 'global_blocklist']);
}

// STEP 2: Check URL path and query parameters for pornographic keywords
// This blocks pornographic content even when embedded in normal sites
// Meertalige detectie - werkt in alle talen
// Also checks Google search queries and other search engines
require __DIR__ . '/../config_keywords.php';
$porn_keywords = get_pornographic_keywords();

// Decode URL-encoded characters in query string (e.g., %20 = space, + = space)
$decoded_query = urldecode($query);
$decoded_path = urldecode($path);
$decoded_url = urldecode($url);
$decoded_search_query = urldecode($search_query);

// Special check for Google search queries with pornographic terms
// Block Google searches for pornographic content BEFORE checking full URL
if (!empty($search_query) && stripos($domain, 'google.') !== false) {
  $search_lower = strtolower($search_query);
  foreach ($porn_keywords as $keyword) {
    $keyword_lower = strtolower($keyword);
    if (strpos($search_lower, $keyword_lower) !== false) {
      // Log blocked Google search
      log_activity($conn, [
        'user_id' => $device['user_id'] ?? null,
        'device_id' => $device_id,
        'action' => 'blocked',
        'domain' => $domain,
        'url' => $url,
        'reason' => 'google_search_pornographic_query',
        'category' => 'pornography',
        'search_query' => $search_query
      ]);
      
      json_out([
        'allowed' => false,
        'reason' => 'blocked',
        'source' => 'google_search_filter',
        'keyword' => $keyword,
        'search_query' => $search_query,
        'note' => 'Pornografische zoekopdracht in Google wordt geblokkeerd'
      ]);
    }
  }
}

// Check full URL (path + query + domain + search query) for keywords
// Also check decoded versions to catch URL-encoded pornographic terms
// Include Google search query separately for better detection
$url_lower = strtolower($full_path . ' ' . $query . ' ' . $decoded_query . ' ' . $decoded_path . ' ' . $domain . ' ' . $decoded_url . ' ' . $search_query . ' ' . $decoded_search_query);
$detected_keyword = '';
foreach ($porn_keywords as $keyword) {
  $keyword_lower = strtolower($keyword);
  if (strpos($url_lower, $keyword_lower) !== false) {
    $detected_keyword = $keyword;
    
    // AUTO-BLOCK: If domain contains pornographic keywords, automatically add to permanent blocklist
    // Get normalized domain (without subdomain) to block all subdomains automatically
    $normalized_domain = normalize_domain($domain);
    
    try {
      $stmt = $conn->prepare("INSERT INTO blocklist_permanent (domain, category, source) VALUES (?, 'pornography', 'auto_block_url_keyword')");
      $stmt->bind_param("s", $normalized_domain);
      $stmt->execute();
    } catch (mysqli_sql_exception $e) {
      // Already exists or error - continue
    }
    
    // ALSO automatically add to global blocklist (always enabled, cannot be disabled)
    try {
      $stmt = $conn->prepare("INSERT INTO blocklist_global (domain, category, source, enabled) VALUES (?, 'pornography', 'auto_block_url_keyword', 1) ON DUPLICATE KEY UPDATE enabled = 1, source = 'auto_block_url_keyword'");
      $stmt->bind_param("s", $normalized_domain);
      $stmt->execute();
    } catch (mysqli_sql_exception $e) {
      // Already exists or error - continue
    }
    
    // Log auto-blocked URL
    log_activity($conn, [
      'user_id' => $device['user_id'] ?? null,
      'device_id' => $device_id,
      'action' => 'blocked',
      'domain' => $domain,
      'url' => $url,
      'reason' => 'auto_block_url_keyword',
      'category' => 'pornography'
    ]);
    
    json_out([
      'allowed' => false,
      'reason' => 'blocked',
      'source' => 'url_keyword_filter',
      'keyword' => $keyword,
      'auto_blocked' => true,
      'normalized_domain' => $normalized_domain ?? $domain,
      'note' => 'Pornografische content gedetecteerd in URL - automatisch geblokkeerd en toegevoegd aan permanente en globale blocklist. Alle subdomains worden automatisch geblokkeerd.'
    ]);
  }
}

// STEP 3: Check subscription blocklist (if active)
$stmt = $conn->prepare("SELECT user_id FROM devices WHERE id=?");
$stmt->bind_param("i", $device_id);
$stmt->execute();
$device_info = $stmt->get_result()->fetch_assoc();

if ($device_info) {
  $user_id = (int)$device_info['user_id'];
  $stmt = $conn->prepare("
    SELECT id FROM subscriptions 
    WHERE user_id = ? 
      AND status = 'active' 
      AND start_date <= CURDATE()
      AND end_date >= CURDATE()
    LIMIT 1
  ");
  $stmt->bind_param("i", $user_id);
  $stmt->execute();
  if ($stmt->get_result()->fetch_assoc()) {
    $stmt = $conn->prepare("SELECT domain FROM blocklist_subscription WHERE domain = ? LIMIT 1");
    $stmt->bind_param("s", $domain);
    $stmt->execute();
    if ($stmt->get_result()->fetch_assoc()) {
      json_out(['allowed' => false, 'reason' => 'blocked', 'source' => 'subscription_blocklist']);
    }
  }
}

// STEP 4: Default ALLOW (normal internet access)
json_out([
  'allowed' => true,
  'reason' => 'allowed',
  'mode' => 'blocklist_only',
  'note' => 'URL not blocked - normal internet access allowed'
]);

