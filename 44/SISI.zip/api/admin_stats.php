<?php
require __DIR__ . '/../config.php';
$user = require_user($conn);

// Check admin
$stmt = $conn->prepare("SELECT is_admin FROM users WHERE id=?");
$stmt->bind_param("i", $user['id']);
$stmt->execute();
$result = $stmt->get_result()->fetch_assoc();
if (!$result || !$result['is_admin']) {
  json_out(['message' => 'Access denied'], 403);
}

// Get statistics
$stats = [];

// Total users
$result = $conn->query("SELECT COUNT(*) as count FROM users");
$stats['total_users'] = (int)$result->fetch_assoc()['count'];

// Total admins
$result = $conn->query("SELECT COUNT(*) as count FROM users WHERE is_admin = 1");
$stats['total_admins'] = (int)$result->fetch_assoc()['count'];

// Total devices
$result = $conn->query("SELECT COUNT(*) as count FROM devices");
$stats['total_devices'] = (int)$result->fetch_assoc()['count'];

// Active devices
$result = $conn->query("SELECT COUNT(*) as count FROM devices WHERE status = 'active'");
$stats['active_devices'] = (int)$result->fetch_assoc()['count'];

// Total whitelist entries
$result = $conn->query("SELECT COUNT(*) as count FROM whitelist");
$stats['total_whitelist'] = (int)$result->fetch_assoc()['count'];

// Enabled whitelist entries
$result = $conn->query("SELECT COUNT(*) as count FROM whitelist WHERE enabled = 1");
$stats['enabled_whitelist'] = (int)$result->fetch_assoc()['count'];

// Recent users (last 7 days)
$result = $conn->query("SELECT COUNT(*) as count FROM users WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)");
$stats['recent_users'] = (int)$result->fetch_assoc()['count'];

// Recent devices (last 7 days)
$result = $conn->query("SELECT COUNT(*) as count FROM devices WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)");
$stats['recent_devices'] = (int)$result->fetch_assoc()['count'];

json_out(['stats' => $stats]);

