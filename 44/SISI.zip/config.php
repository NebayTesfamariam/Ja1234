<?php

declare(strict_types=1);

/* =====================
   CORS
===================== */
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
  http_response_code(204);
  exit;
}

/* =====================
   MYSQL ERROR MODE
===================== */
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

/* =====================
   ENV DETECTION
===================== */
$is_production = (
  isset($_SERVER['HTTP_HOST']) &&
  (strpos($_SERVER['HTTP_HOST'], 'ja1234.com') !== false)
) || getenv('ENVIRONMENT') === 'production';

/* =====================
   DATABASE CONFIG
===================== */
if ($is_production) {
  $DB_HOST = "localhost";
  $DB_USER = "u402299403_nebaytes";
  $DB_PASS = "JE_ECHTE_DB_WACHTWOORD"; // 🔴 VERPLICHT
  $DB_NAME = "u402299403_ja1234";
} else {
  $DB_HOST = "localhost";
  $DB_USER = "root";
  $DB_PASS = "";
  $DB_NAME = "pornfree";
}

/* =====================
   DB CONNECT
===================== */
try {
  $conn = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);
  $conn->set_charset("utf8mb4");
} catch (Throwable $e) {
  json_out([
    'error' => 'Database connection failed',
    'details' => $e->getMessage()
  ], 500);
}

/* =====================
   HELPERS
===================== */
function json_out($data, int $code = 200): void
{
  http_response_code($code);
  header("Content-Type: application/json; charset=utf-8");
  echo json_encode($data);
  exit;
}
