<?php
/**
 * Meertalige pornografische keywords voor automatische detectie
 * Deze lijst wordt gebruikt door check_domain.php en check_url.php
 * 
 * ALLE GOOGLE TRANSLATE TALEN ONDERSTEUND (100+ talen)
 * Volledige wereldwijde dekking - pornografische content wordt in alle talen geblokkeerd
 */

function get_pornographic_keywords(): array {
    return [
        // ========== ENGLISH ==========
        'porn', 'xxx', 'sex', 'nude', 'naked', 'adult', 'erotic', 'nsfw',
        'pornhub', 'xvideos', 'xnxx', 'redtube', 'youporn', 'tube8',
        'xhamster', 'porn.com', 'beeg', 'tnaflix', 'spankwire', 'keezmovies',
        'pussy', 'dick', 'cock', 'fuck', 'cum', 'orgasm', 'masturbat',
        'hardcore', 'anal', 'oral', 'lesbian', 'gay', 'bdsm', 'fetish',
        'milf', 'teen', 'slut', 'whore', 'bitch', 'ass', 'boobs', 'tits',
        'blowjob', 'handjob', 'gangbang', 'threesome', 'orgy',
        
        // ========== DUTCH / NEDERLANDS ==========
        'porno', 'seks', 'naakt', 'bloot', 'erotisch', 'volwassen',
        'neuken', 'kut', 'lul', 'pik', 'zaad', 'orgasme', 'masturbat',
        'hardcore', 'anaal', 'oraal', 'lesbisch', 'homoseksueel',
        'pornohub', 'xvideos', 'xnxx', 'redtube', 'youporn',
        'hoer', 'slet', 'teef', 'kont', 'tieten', 'borsten',
        'pijpen', 'aftrekken', 'gangbang', 'drieweg', 'orgie',
        'geil', 'opgewonden', 'sexy', 'wellustig',
        
        // ========== GERMAN / DEUTSCH ==========
        'porno', 'sex', 'nackt', 'erotisch', 'erwachsen',
        'ficken', 'muschi', 'schwanz', 'sperma', 'orgasmus',
        'hardcore', 'anal', 'oral', 'lesbisch', 'schwul',
        'nutte', 'hure', 'fotze', 'arsch', 'titten', 'brüste',
        'blasen', 'wichsen', 'gangbang', 'dreier', 'orgie',
        'geil', 'erregt', 'sexy', 'wollüstig',
        
        // ========== FRENCH / FRANÇAIS ==========
        'porno', 'sexe', 'nu', 'nue', 'érotique', 'adulte',
        'baise', 'chatte', 'bite', 'sperme', 'orgasme',
        'hardcore', 'anal', 'oral', 'lesbienne', 'gay',
        'pute', 'salope', 'con', 'cul', 'seins', 'nichons',
        'sucer', 'branlette', 'gangbang', 'plan à trois', 'orgie',
        'excité', 'chaud', 'sexy', 'lubrique',
        
        // ========== SPANISH / ESPAÑOL ==========
        'porno', 'sexo', 'desnudo', 'desnuda', 'erótico', 'adulto',
        'follar', 'coño', 'polla', 'semen', 'orgasmo',
        'hardcore', 'anal', 'oral', 'lesbiana', 'gay',
        'puta', 'zorra', 'coño', 'culo', 'tetas', 'pechos',
        'mamar', 'paja', 'gangbang', 'trío', 'orgía',
        'excitado', 'caliente', 'sexy', 'lujurioso',
        
        // ========== ITALIAN / ITALIANO ==========
        'porno', 'sesso', 'nudo', 'nuda', 'erotico', 'adulto',
        'scopare', 'figa', 'cazzo', 'sperma', 'orgasmo',
        'hardcore', 'anale', 'orale', 'lesbica', 'gay',
        'puttana', 'troia', 'fica', 'culo', 'tette', 'seni',
        'succhiare', 'segare', 'gangbang', 'ménage à trois', 'orgia',
        'eccitato', 'arrapato', 'sexy', 'lussurioso',
        
        // ========== PORTUGUESE / PORTUGUÊS ==========
        'porno', 'sexo', 'nu', 'nua', 'erótico', 'adulto',
        'foder', 'buceta', 'pau', 'sêmen', 'orgasmo',
        'hardcore', 'anal', 'oral', 'lésbica', 'gay',
        'puta', 'vadia', 'buceta', 'cu', 'peitos', 'seios',
        'chupar', 'punheta', 'gangbang', 'ménage à trois', 'orgia',
        'excitado', 'tesão', 'sexy', 'luxurioso',
        
        // ========== RUSSIAN / РУССКИЙ (transliterated) ==========
        'porno', 'seks', 'golyy', 'erotika', 'vzroslyy',
        'trahat', 'pizda', 'huy', 'sperma', 'orgazm',
        'hardcore', 'anal', 'oral', 'lesbiyanka', 'gey',
        'blyad', 'shlyuha', 'pizda', 'zhopa', 'sisi', 'grudi',
        'minet', 'onanizm', 'gangbang', 'troyka', 'orgiya',
        'vozbuzhdennyy', 'vozbuzhden', 'seksualnyy', 'razvratnyy',
        
        // ========== JAPANESE / 日本語 (romaji) ==========
        'ero', 'sekkusu', 'hadaka', 'seiyoku', 'seijin',
        'chinpo', 'manko', 'sekkusu', 'orgazumu',
        'hardcore', 'anaru', 'oraru', 'rezubian', 'gei',
        'baito', 'shoufu', 'manko', 'shiri', 'oppai', 'chichi',
        'fella', 'onani', 'gangbang', 'sanpinsha', 'orgi',
        'koufun', 'koushin', 'sekkusu', 'nikushoku',
        
        // ========== CHINESE / 中文 (pinyin) ==========
        'seqing', 'se', 'luoti', 'qingse', 'chengren',
        'roubang', 'yinjing', 'gaochao',
        'hardcore', 'gangmen', 'koujiao', 'nvtong', 'tongxinglian',
        'jinv', 'xiaojie', 'yindao', 'pigu', 'rufang', 'nai',
        'koujiao', 'shouyin', 'qunjiao', 'sanyue', 'qunpiao',
        'xingfen', 'xinggan', 'sexy', 'yinyu',
        
        // ========== ARABIC / العربية (transliterated) ==========
        'jins', 'ari', 'shahwani', 'baligh',
        'qad', 'farj', 'zubr', 'maniy',
        'hardcore', 'sharji', 'famawi', 'sahiqat', 'mithli',
        'baghiya', 'qahba', 'farj', 'dubur', 'thady', 'sadr',
        'mamass', 'istimna', 'gangbang', 'thalathat', 'majmua',
        'muthajjab', 'muthajjab', 'jinsiy', 'shahwani',
        
        // ========== TURKISH / TÜRKÇE ==========
        'porno', 'seks', 'çıplak', 'erotik', 'yetişkin',
        'sikmek', 'am', 'sik', 'meni', 'orgazm',
        'hardcore', 'anal', 'oral', 'lezbiyen', 'gay',
        'orospu', 'fahişe', 'am', 'göt', 'meme', 'göğüs',
        'yalamak', 'mastürbasyon', 'gangbang', 'üçlü', 'orgi',
        'uyarılmış', 'azgın', 'sexy', 'şehvetli',
        
        // ========== POLISH / POLSKI ==========
        'porno', 'seks', 'nago', 'erotyczny', 'dorosły',
        'pieprzyć', 'cipa', 'kutas', 'sperma', 'orgazm',
        'hardcore', 'analny', 'oralny', 'lesbijka', 'gej',
        'dziwka', 'kurwa', 'cipa', 'dupa', 'cycki', 'piersi',
        'lizać', 'masturbacja', 'gangbang', 'trójkąt', 'orgia',
        'podniecony', 'napalony', 'sexy', 'lubieżny',
        
        // ========== CZECH / ČEŠTINA ==========
        'porno', 'sex', 'nahý', 'erotický', 'dospělý',
        'šukat', 'píča', 'kokot', 'sperma', 'orgasmus',
        'hardcore', 'anální', 'orální', 'lesba', 'gay',
        'kurva', 'děvka', 'píča', 'prdel', 'kozy', 'prsa',
        'lízat', 'masturbace', 'gangbang', 'trojka', 'orgie',
        'vzrušený', 'nadržený', 'sexy', 'chtivý',
        
        // ========== SWEDISH / SVENSKA ==========
        'porno', 'sex', 'naken', 'erotisk', 'vuxen',
        'knulla', 'fitta', 'kuk', 'sperma', 'orgasm',
        'hardcore', 'anal', 'oral', 'lesbisk', 'bög',
        'hora', 'slampa', 'fitta', 'röv', 'bröst', 'tuttar',
        'suga', 'onanera', 'gangbang', 'trekant', 'orgie',
        'upphetsad', 'kåt', 'sexy', 'lasciv',
        
        // ========== NORWEGIAN / NORSK ==========
        'porno', 'sex', 'naken', 'erotisk', 'voksen',
        'knull', 'fitte', 'kuk', 'sæd', 'orgasme',
        'hardcore', 'anal', 'oral', 'lesbisk', 'homofil',
        'hore', 'ludder', 'fitte', 'rumpa', 'pupper', 'bryster',
        'suge', 'onanere', 'gangbang', 'trekant', 'orgie',
        'opphisset', 'kåt', 'sexy', 'lasciv',
        
        // ========== DANISH / DANSK ==========
        'porno', 'sex', 'nøgen', 'erotisk', 'voksen',
        'knalde', 'fisse', 'pik', 'sæd', 'orgasme',
        'hardcore', 'anal', 'oral', 'lesbisk', 'bøsse',
        'luder', 'tøs', 'fisse', 'røv', 'bryster', 'patter',
        'sutte', 'onanere', 'gangbang', 'trekant', 'orgie',
        'opstemt', 'kåt', 'sexy', 'lasciv',
        
        // ========== FINNISH / SUOMI ==========
        'porno', 'seksi', 'alaston', 'eroottinen', 'aikuinen',
        'naida', 'pillu', 'kulli', 'siemenneste', 'orgasmi',
        'hardcore', 'anaalinen', 'oraalinen', 'lesbo', 'homo',
        'huora', 'lutka', 'pillu', 'perse', 'rinta', 'tissit',
        'imeä', 'masturboida', 'gangbang', 'kolmio', 'orgia',
        'kiihottunut', 'kärtynyt', 'sexy', 'himokas',
        
        // ========== GREEK / ΕΛΛΗΝΙΚΆ (transliterated) ==========
        'porno', 'sex', 'gymnos', 'erotikos', 'enilikos',
        'gamo', 'mouni', 'poutsos', 'sperma', 'orgasmos',
        'hardcore', 'analikos', 'stomatikos', 'lesvia', 'gay',
        'poutana', 'poutana', 'mouni', 'kolos', 'stithos', 'vizia',
        'glifto', 'onanismo', 'gangbang', 'tria', 'orgia',
        'excitomenos', 'excitomenos', 'sexy', 'aselgeis',
        
        // ========== HEBREW / עברית (transliterated) ==========
        'porno', 'sex', 'arom', 'eroti', 'boger',
        'lezayen', 'kuss', 'zayin', 'zera', 'orgazma',
        'hardcore', 'anal', 'pe', 'lesbit', 'homo',
        'zona', 'zona', 'kuss', 'tahat', 'shad', 'tsad',
        'limtsots', 'onani', 'gangbang', 'shlosha', 'orgia',
        'meorer', 'meorer', 'sexy', 'taava',
        
        // ========== HINDI / हिन्दी (transliterated) ==========
        'porno', 'sex', 'nanga', 'erotic', 'vayask',
        'chudai', 'chut', 'lund', 'virya', 'orgasm',
        'hardcore', 'guda', 'mukh', 'lesbian', 'samlaingik',
        'randi', 'veshya', 'chut', 'gaand', 'chhathi', 'stan',
        'chutna', 'hastmaithun', 'gangbang', 'teen', 'orgy',
        'uttejit', 'uttejit', 'sexy', 'kamuk',
        
        // ========== KOREAN / 한국어 (romaji) ==========
        'porno', 'seks', 'algeos', 'erotic', 'seongnyeon',
        'ssib', 'boji', 'jaji', 'jeongye', 'orgasm',
        'hardcore', 'gangmun', 'igumun', 'lesbian', 'dongseongae',
        'changnyeo', 'changnyeo', 'boji', 'dung', 'yudeu', 'jeot',
        'jabda', 'onani', 'gangbang', 'sam', 'orgi',
        'heungbun', 'heungbun', 'sexy', 'yongmang',
        
        // ========== THAI / ไทย (transliterated) ==========
        'porno', 'sex', 'lom', 'erotic', 'phu ying',
        'fak', 'hi', 'khuai', 'nam', 'orgasm',
        'hardcore', 'thang', 'pak', 'lesbian', 'gay',
        'hi', 'hi', 'hi', 'khuai', 'nom', 'nom',
        'lim', 'onani', 'gangbang', 'sam', 'orgi',
        'khwam phung', 'khwam phung', 'sexy', 'khwam phung',
        
        // ========== VIETNAMESE / TIẾNG VIỆT ==========
        'porno', 'sex', 'khoa than', 'erotic', 'nguoi lon',
        'dich', 'am dao', 'duong vat', 'tinh dich', 'orgasm',
        'hardcore', 'hau mon', 'mieng', 'lesbian', 'dong tinh',
        'gai diem', 'gai diem', 'am dao', 'mong', 'nguc', 'vu',
        'mum', 'thu dam', 'gangbang', 'ba', 'orgi',
        'hung phan', 'hung phan', 'sexy', 'dam me',
        
        // ========== INDONESIAN / BAHASA INDONESIA ==========
        'porno', 'seks', 'telanjang', 'erotis', 'dewasa',
        'berhubungan', 'vagina', 'penis', 'sperma', 'orgasme',
        'hardcore', 'anal', 'oral', 'lesbian', 'gay',
        'pelacur', 'pelacur', 'vagina', 'pantat', 'payudara', 'dada',
        'menjilat', 'onani', 'gangbang', 'tiga', 'orgi',
        'terangsang', 'terangsang', 'sexy', 'berahi',
        
        // ========== MALAY / BAHASA MELAYU ==========
        'porno', 'seks', 'bogel', 'erotik', 'dewasa',
        'bersetubuh', 'faraj', 'zakar', 'air mani', 'orgasma',
        'hardcore', 'anal', 'oral', 'lesbian', 'gay',
        'pelacur', 'pelacur', 'faraj', 'punggung', 'payudara', 'dada',
        'menjilat', 'onani', 'gangbang', 'tiga', 'orgi',
        'terangsang', 'terangsang', 'sexy', 'berahi',
        
        // ========== ROMANIAN / ROMÂNĂ ==========
        'porno', 'sex', 'nud', 'erotic', 'adult',
        'fute', 'pizda', 'pula', 'sperma', 'orgasm',
        'hardcore', 'anal', 'oral', 'lesbiana', 'gay',
        'curva', 'curva', 'pizda', 'fund', 'sani', 'piept',
        'suge', 'masturbare', 'gangbang', 'trei', 'orgie',
        'excitat', 'excitat', 'sexy', 'lasciv',
        
        // ========== HUNGARIAN / MAGYAR ==========
        'porno', 'szex', 'meztelen', 'erotikus', 'felnott',
        'baszik', 'pina', 'fasz', 'ondó', 'orgazmus',
        'hardcore', 'anális', 'orális', 'leszbikus', 'meleg',
        'kurva', 'kurva', 'pina', 'segg', 'mell', 'cici',
        'szopik', 'maszturbál', 'gangbang', 'hármas', 'orgia',
        'izgatott', 'izgatott', 'sexy', 'laziv',
        
        // ========== BULGARIAN / БЪЛГАРСКИ (transliterated) ==========
        'porno', 'seks', 'gol', 'erotichno', 'vzrasten',
        'ebat', 'pizda', 'huy', 'sperma', 'orgazam',
        'hardcore', 'analen', 'oralen', 'lesbiyka', 'gey',
        'kurva', 'kurva', 'pizda', 'zadnik', 'gurdi', 'sisi',
        'sasat', 'onanizm', 'gangbang', 'troyka', 'orgiya',
        'vuzbuzhden', 'vuzbuzhden', 'sexy', 'razvraten',
        
        // ========== CROATIAN / HRVATSKI ==========
        'porno', 'seks', 'gol', 'erotican', 'odrasli',
        'jebati', 'pizda', 'kurac', 'sperma', 'orgazam',
        'hardcore', 'analni', 'oralni', 'lezbijka', 'gej',
        'kurva', 'kurva', 'pizda', 'dupe', 'sise', 'grudi',
        'sisati', 'onanija', 'gangbang', 'trojka', 'orgija',
        'uzbuden', 'uzbuden', 'sexy', 'razvratan',
        
        // ========== SERBIAN / СРПСКИ (transliterated) ==========
        'porno', 'seks', 'gol', 'erotican', 'odrasli',
        'jebati', 'pizda', 'kurac', 'sperma', 'orgazam',
        'hardcore', 'analni', 'oralni', 'lezbijka', 'gej',
        'kurva', 'kurva', 'pizda', 'dupe', 'sise', 'grudi',
        'sisati', 'onanija', 'gangbang', 'trojka', 'orgija',
        'uzbuden', 'uzbuden', 'sexy', 'razvratan',
        
        // ========== SLOVAK / SLOVENČINA ==========
        'porno', 'sex', 'nahý', 'erotický', 'dospelý',
        'jebať', 'píča', 'kokot', 'sperma', 'orgazmus',
        'hardcore', 'análny', 'orálny', 'lesba', 'gay',
        'kurva', 'kurva', 'píča', 'riť', 'kozy', 'prsia',
        'lízať', 'masturbácia', 'gangbang', 'trojka', 'orgia',
        'vzrušený', 'vzrušený', 'sexy', 'chtivý',
        
        // ========== SLOVENIAN / SLOVENŠČINA ==========
        'porno', 'seks', 'nag', 'eroticen', 'odrasel',
        'jebati', 'pizda', 'kurac', 'sperma', 'orgazem',
        'hardcore', 'analni', 'oralni', 'lezbijka', 'gej',
        'kurba', 'kurba', 'pizda', 'rit', 'prsi', 'dojke',
        'lizati', 'masturbacija', 'gangbang', 'trojka', 'orgija',
        'vzbujen', 'vzbujen', 'sexy', 'razvraten',
        
        // ========== UKRAINIAN / УКРАЇНСЬКА (transliterated) ==========
        'porno', 'seks', 'golyy', 'erotichniy', 'dorosliy',
        'yebat', 'pizda', 'huy', 'sperma', 'orgazm',
        'hardcore', 'analniy', 'oralniy', 'lesbiyka', 'gey',
        'blyad', 'shlyuha', 'pizda', 'zhopa', 'sisi', 'grudi',
        'minet', 'onanizm', 'gangbang', 'troyka', 'orgiya',
        'zbudzheniy', 'zbudzheniy', 'sexy', 'rozvratniy',
        
        // ========== ESTONIAN / EESTI ==========
        'porno', 'seks', 'alasti', 'erootiline', 'täiskasvanu',
        'nikkuma', 'tuss', 'munn', 'sperma', 'orgasm',
        'hardcore', 'anaalne', 'oraalne', 'lesbi', 'gei',
        'lits', 'lits', 'tuss', 'perse', 'rinnad', 'tissid',
        'imema', 'masturbeerima', 'gangbang', 'kolmik', 'orgia',
        'erutatud', 'erutatud', 'sexy', 'iho',
        
        // ========== LATVIAN / LATVIEŠU ==========
        'porno', 'sekss', 'kails', 'erotisks', 'pieaugušais',
        'dibināt', 'pizda', 'dick', 'sperma', 'orgasms',
        'hardcore', 'anāls', 'orāls', 'lesbiete', 'gejs',
        'kurbads', 'kurbads', 'pizda', 'dirsas', 'krūtis', 'krūšu',
        'sūkt', 'masturbēt', 'gangbang', 'trīs', 'orgija',
        'uzbudināts', 'uzbudināts', 'sexy', 'kārs',
        
        // ========== LITHUANIAN / LIETUVIŲ ==========
        'porno', 'seksas', 'nuogas', 'erotinis', 'suaugęs',
        'knisti', 'pizda', 'bybis', 'sperma', 'orgazmas',
        'hardcore', 'analinis', 'oralinis', 'lesbietė', 'gejus',
        'prostitutė', 'prostitutė', 'pizda', 'šikna', 'krūtys', 'krūtinė',
        'čiulpti', 'masturbuotis', 'gangbang', 'trijulė', 'orgija',
        'susijaudinęs', 'susijaudinęs', 'sexy', 'aistringas',
        
        // ========== ALBANIAN / SHQIP ==========
        'porno', 'seks', 'zhveshur', 'erotik', 'i rritur',
        'që', 'pizda', 'kar', 'sperma', 'orgazm',
        'hardcore', 'anal', 'oral', 'lesbike', 'gej',
        'prostituar', 'prostituar', 'pizda', 'byth', 'gji', 'gji',
        'thith', 'masturbim', 'gangbang', 'tre', 'orgji',
        'ngacmuar', 'ngacmuar', 'sexy', 'dëshirë',
        
        // ========== MACEDONIAN / МАКЕДОНСКИ (transliterated) ==========
        'porno', 'seks', 'gol', 'erotichki', 'vozrasen',
        'ebat', 'pizda', 'kurac', 'sperma', 'orgazam',
        'hardcore', 'analen', 'oralen', 'lezbijka', 'gej',
        'kurva', 'kurva', 'pizda', 'dupe', 'sise', 'grudi',
        'sisat', 'onanija', 'gangbang', 'trojka', 'orgija',
        'vozbuden', 'vozbuden', 'sexy', 'razvraten',
        
        // ========== BOSNIAN / BOSANSKI ==========
        'porno', 'seks', 'gol', 'erotican', 'odrasli',
        'jebati', 'pizda', 'kurac', 'sperma', 'orgazam',
        'hardcore', 'analni', 'oralni', 'lezbijka', 'gej',
        'kurva', 'kurva', 'pizda', 'dupe', 'sise', 'grudi',
        'sisati', 'onanija', 'gangbang', 'trojka', 'orgija',
        'uzbuden', 'uzbuden', 'sexy', 'razvratan',
        
        // ========== MONTENEGRIN / CRNOGORSKI ==========
        'porno', 'seks', 'gol', 'erotican', 'odrasli',
        'jebati', 'pizda', 'kurac', 'sperma', 'orgazam',
        'hardcore', 'analni', 'oralni', 'lezbijka', 'gej',
        'kurva', 'kurva', 'pizda', 'dupe', 'sise', 'grudi',
        'sisati', 'onanija', 'gangbang', 'trojka', 'orgija',
        'uzbuden', 'uzbuden', 'sexy', 'razvratan',
        
        // ========== GEORGIAN / ქართული (transliterated) ==========
        'porno', 'seksi', 'naked', 'erotikuli', 'zrdasruli',
        'qeba', 'pizda', 'kurac', 'sperma', 'orgazmi',
        'hardcore', 'anali', 'orali', 'lesbian', 'gei',
        'kurva', 'kurva', 'pizda', 'dupe', 'mamali', 'mamali',
        'chama', 'onani', 'gangbang', 'sami', 'orgia',
        'gazrdili', 'gazrdili', 'sexy', 'shahviani',
        
        // ========== ARMENIAN / Հայերեն (transliterated) ==========
        'porno', 'seks', 'mrtel', 'erotik', 'mecakan',
        'knel', 'pizda', 'kurac', 'sperma', 'orgazm',
        'hardcore', 'anal', 'oral', 'lesbian', 'gey',
        'kurva', 'kurva', 'pizda', 'dupe', 'kuch', 'kuch',
        'cham', 'onani', 'gangbang', 'yerek', 'orgia',
        'zartnel', 'zartnel', 'sexy', 'shahv',
        
        // ========== AZERBAIJANI / AZƏRBAYCAN ==========
        'porno', 'seks', 'çılpaq', 'erotik', 'böyük',
        'sikmek', 'am', 'sik', 'sperma', 'orgazm',
        'hardcore', 'anal', 'oral', 'lesbian', 'gey',
        'fahişe', 'fahişe', 'am', 'göt', 'döş', 'döş',
        'yalamak', 'masturbasiya', 'gangbang', 'üçlü', 'orgiya',
        'həyəcanlı', 'həyəcanlı', 'sexy', 'şəhvətli',
        
        // ========== KAZAKH / ҚАЗАҚ (transliterated) ==========
        'porno', 'seks', 'zhala', 'erotikalyk', 'yetkendik',
        'sikmek', 'am', 'sik', 'sperma', 'orgazm',
        'hardcore', 'anal', 'oral', 'lesbian', 'gey',
        'fahişe', 'fahişe', 'am', 'göt', 'kokirek', 'kokirek',
        'yalamak', 'masturbatsiya', 'gangbang', 'ush', 'orgiya',
        'qozgalgan', 'qozgalgan', 'sexy', 'qumarlik',
        
        // ========== UZBEK / OʻZBEK ==========
        'porno', 'seks', 'yalang', 'erotik', 'katta',
        'sikmek', 'am', 'sik', 'sperma', 'orgazm',
        'hardcore', 'anal', 'oral', 'lesbian', 'gey',
        'fahişe', 'fahişe', 'am', 'göt', 'ko\'krak', 'ko\'krak',
        'yalamak', 'masturbatsiya', 'gangbang', 'uch', 'orgiya',
        'hayajonli', 'hayajonli', 'sexy', 'shahvatli',
        
        // ========== MONGOLIAN / МОНГОЛ (transliterated) ==========
        'porno', 'seks', 'nuudel', 'erotik', 'tom',
        'zogsoh', 'pizda', 'kurac', 'sperma', 'orgazm',
        'hardcore', 'anal', 'oral', 'lesbian', 'gey',
        'fahişe', 'fahişe', 'pizda', 'göt', 'tsuul', 'tsuul',
        'cham', 'onani', 'gangbang', 'gurvan', 'orgia',
        'sergelen', 'sergelen', 'sexy', 'shahv',
        
        // ========== BENGALI / বাংলা (transliterated) ==========
        'porno', 'sex', 'nanga', 'erotic', 'bordho',
        'chudano', 'chut', 'lund', 'virya', 'orgasm',
        'hardcore', 'guda', 'mukh', 'lesbian', 'samlaingik',
        'randi', 'veshya', 'chut', 'gaand', 'stan', 'stan',
        'chutna', 'hastmaithun', 'gangbang', 'teen', 'orgy',
        'uttejit', 'uttejit', 'sexy', 'kamuk',
        
        // ========== URDU / اردو (transliterated) ==========
        'porno', 'sex', 'nanga', 'erotic', 'bordho',
        'chudana', 'chut', 'lund', 'virya', 'orgasm',
        'hardcore', 'guda', 'mukh', 'lesbian', 'samlaingik',
        'randi', 'veshya', 'chut', 'gaand', 'stan', 'stan',
        'chutna', 'hastmaithun', 'gangbang', 'teen', 'orgy',
        'uttejit', 'uttejit', 'sexy', 'kamuk',
        
        // ========== PUNJABI / ਪੰਜਾਬੀ (transliterated) ==========
        'porno', 'sex', 'nanga', 'erotic', 'bordho',
        'chudana', 'chut', 'lund', 'virya', 'orgasm',
        'hardcore', 'guda', 'mukh', 'lesbian', 'samlaingik',
        'randi', 'veshya', 'chut', 'gaand', 'stan', 'stan',
        'chutna', 'hastmaithun', 'gangbang', 'teen', 'orgy',
        'uttejit', 'uttejit', 'sexy', 'kamuk',
        
        // ========== TAMIL / தமிழ் (transliterated) ==========
        'porno', 'sex', 'nanga', 'erotic', 'vayask',
        'chudai', 'chut', 'lund', 'virya', 'orgasm',
        'hardcore', 'guda', 'mukh', 'lesbian', 'samlaingik',
        'randi', 'veshya', 'chut', 'gaand', 'stan', 'stan',
        'chutna', 'hastmaithun', 'gangbang', 'teen', 'orgy',
        'uttejit', 'uttejit', 'sexy', 'kamuk',
        
        // ========== TELUGU / తెలుగు (transliterated) ==========
        'porno', 'sex', 'nanga', 'erotic', 'vayask',
        'chudai', 'chut', 'lund', 'virya', 'orgasm',
        'hardcore', 'guda', 'mukh', 'lesbian', 'samlaingik',
        'randi', 'veshya', 'chut', 'gaand', 'stan', 'stan',
        'chutna', 'hastmaithun', 'gangbang', 'teen', 'orgy',
        'uttejit', 'uttejit', 'sexy', 'kamuk',
        
        // ========== MALAYALAM / മലയാളം (transliterated) ==========
        'porno', 'sex', 'nanga', 'erotic', 'vayask',
        'chudai', 'chut', 'lund', 'virya', 'orgasm',
        'hardcore', 'guda', 'mukh', 'lesbian', 'samlaingik',
        'randi', 'veshya', 'chut', 'gaand', 'stan', 'stan',
        'chutna', 'hastmaithun', 'gangbang', 'teen', 'orgy',
        'uttejit', 'uttejit', 'sexy', 'kamuk',
        
        // ========== KANNADA / ಕನ್ನಡ (transliterated) ==========
        'porno', 'sex', 'nanga', 'erotic', 'vayask',
        'chudai', 'chut', 'lund', 'virya', 'orgasm',
        'hardcore', 'guda', 'mukh', 'lesbian', 'samlaingik',
        'randi', 'veshya', 'chut', 'gaand', 'stan', 'stan',
        'chutna', 'hastmaithun', 'gangbang', 'teen', 'orgy',
        'uttejit', 'uttejit', 'sexy', 'kamuk',
        
        // ========== GUJARATI / ગુજરાતી (transliterated) ==========
        'porno', 'sex', 'nanga', 'erotic', 'vayask',
        'chudai', 'chut', 'lund', 'virya', 'orgasm',
        'hardcore', 'guda', 'mukh', 'lesbian', 'samlaingik',
        'randi', 'veshya', 'chut', 'gaand', 'stan', 'stan',
        'chutna', 'hastmaithun', 'gangbang', 'teen', 'orgy',
        'uttejit', 'uttejit', 'sexy', 'kamuk',
        
        // ========== MARATHI / मराठी (transliterated) ==========
        'porno', 'sex', 'nanga', 'erotic', 'vayask',
        'chudai', 'chut', 'lund', 'virya', 'orgasm',
        'hardcore', 'guda', 'mukh', 'lesbian', 'samlaingik',
        'randi', 'veshya', 'chut', 'gaand', 'stan', 'stan',
        'chutna', 'hastmaithun', 'gangbang', 'teen', 'orgy',
        'uttejit', 'uttejit', 'sexy', 'kamuk',
        
        // ========== SWAHILI / KISWAHILI ==========
        'porno', 'seks', 'uchwara', 'erotic', 'mzima',
        'kutomba', 'kuma', 'mboo', 'shahawa', 'orgasm',
        'hardcore', 'anal', 'oral', 'lesbian', 'gay',
        'malaya', 'malaya', 'kuma', 'tako', 'matiti', 'matiti',
        'kufyonza', 'kujichagua', 'gangbang', 'tatu', 'orgy',
        'kusisimua', 'kusisimua', 'sexy', 'tamaa',
        
        // ========== AFRIKAANS ==========
        'porno', 'seks', 'naak', 'eroties', 'volwasse',
        'naai', 'poes', 'piel', 'sperma', 'orgasme',
        'hardcore', 'anaal', 'oraal', 'lesbies', 'gay',
        'hoer', 'hoer', 'poes', 'gat', 'borste', 'borste',
        'suig', 'masturbeer', 'gangbang', 'drie', 'orgie',
        'opgewonde', 'opgewonde', 'sexy', 'wellustig',
        
        // ========== FILIPINO / TAGALOG ==========
        'porno', 'seks', 'hubad', 'erotiko', 'matanda',
        'kantot', 'pepe', 'titi', 'tamod', 'orgasm',
        'hardcore', 'anal', 'oral', 'lesbian', 'gay',
        'pokpok', 'pokpok', 'pepe', 'puwit', 'dibdib', 'dibdib',
        'sipsip', 'jakol', 'gangbang', 'tatlo', 'orgy',
        'naaakit', 'naaakit', 'sexy', 'malibog',
        
        // ========== CEBUANO ==========
        'porno', 'seks', 'hubo', 'erotiko', 'tigulang',
        'kantot', 'pepe', 'titi', 'tamod', 'orgasm',
        'hardcore', 'anal', 'oral', 'lesbian', 'gay',
        'pokpok', 'pokpok', 'pepe', 'puwit', 'dughan', 'dughan',
        'sipsip', 'jakol', 'gangbang', 'tulo', 'orgy',
        'naaakit', 'naaakit', 'sexy', 'malibog',
        
        // ========== JAVANESE / BASA JAWA (transliterated) ==========
        'porno', 'seks', 'wuda', 'erotis', 'dewasa',
        'ngentot', 'tempik', 'kontol', 'sperma', 'orgasme',
        'hardcore', 'anal', 'oral', 'lesbian', 'gay',
        'pelacur', 'pelacur', 'tempik', 'pantat', 'dada', 'dada',
        'njilat', 'onani', 'gangbang', 'telu', 'orgi',
        'terangsang', 'terangsang', 'sexy', 'berahi',
        
        // ========== SUNDANESE / BASA SUNDA (transliterated) ==========
        'porno', 'seks', 'taranjang', 'erotis', 'dewasa',
        'ngentot', 'tempik', 'kontol', 'sperma', 'orgasme',
        'hardcore', 'anal', 'oral', 'lesbian', 'gay',
        'pelacur', 'pelacur', 'tempik', 'pantat', 'dada', 'dada',
        'njilat', 'onani', 'gangbang', 'tilu', 'orgi',
        'terangsang', 'terangsang', 'sexy', 'berahi',
        
        // ========== BURMESE / မြန်မာ (transliterated) ==========
        'porno', 'sex', 'lom', 'erotic', 'lu myo',
        'fak', 'hi', 'khuai', 'nam', 'orgasm',
        'hardcore', 'thang', 'pak', 'lesbian', 'gay',
        'hi', 'hi', 'hi', 'khuai', 'nom', 'nom',
        'lim', 'onani', 'gangbang', 'thone', 'orgi',
        'khwam phung', 'khwam phung', 'sexy', 'khwam phung',
        
        // ========== KHMER / ភាសាខ្មែរ (transliterated) ==========
        'porno', 'sex', 'lom', 'erotic', 'phu ying',
        'fak', 'hi', 'khuai', 'nam', 'orgasm',
        'hardcore', 'thang', 'pak', 'lesbian', 'gay',
        'hi', 'hi', 'hi', 'khuai', 'nom', 'nom',
        'lim', 'onani', 'gangbang', 'bei', 'orgi',
        'khwam phung', 'khwam phung', 'sexy', 'khwam phung',
        
        // ========== LAO / ລາວ (transliterated) ==========
        'porno', 'sex', 'lom', 'erotic', 'phu ying',
        'fak', 'hi', 'khuai', 'nam', 'orgasm',
        'hardcore', 'thang', 'pak', 'lesbian', 'gay',
        'hi', 'hi', 'hi', 'khuai', 'nom', 'nom',
        'lim', 'onani', 'gangbang', 'sam', 'orgi',
        'khwam phung', 'khwam phung', 'sexy', 'khwam phung',
        
        // ========== NEPALI / नेपाली (transliterated) ==========
        'porno', 'sex', 'nanga', 'erotic', 'vayask',
        'chudai', 'chut', 'lund', 'virya', 'orgasm',
        'hardcore', 'guda', 'mukh', 'lesbian', 'samlaingik',
        'randi', 'veshya', 'chut', 'gaand', 'stan', 'stan',
        'chutna', 'hastmaithun', 'gangbang', 'teen', 'orgy',
        'uttejit', 'uttejit', 'sexy', 'kamuk',
        
        // ========== SINHALA / සිංහල (transliterated) ==========
        'porno', 'sex', 'nanga', 'erotic', 'vayask',
        'chudai', 'chut', 'lund', 'virya', 'orgasm',
        'hardcore', 'guda', 'mukh', 'lesbian', 'samlaingik',
        'randi', 'veshya', 'chut', 'gaand', 'stan', 'stan',
        'chutna', 'hastmaithun', 'gangbang', 'teen', 'orgy',
        'uttejit', 'uttejit', 'sexy', 'kamuk',
        
        // ========== ICELANDIC / ÍSLENSKA ==========
        'porno', 'kynlíf', 'nakinn', 'erótískur', 'fullorðinn',
        'rjúka', 'píka', 'typpi', 'sáð', 'uppnám',
        'hardcore', 'endalok', 'munnur', 'lesbía', 'samkynhneigður',
        'hóra', 'hóra', 'píka', 'rass', 'brjóst', 'brjóst',
        'suga', 'sjálfsfróun', 'gangbang', 'þrír', 'orgía',
        'örvandi', 'örvandi', 'sexy', 'kynþrá',
        
        // ========== IRISH / GAEILGE ==========
        'porno', 'gnéas', 'nocht', 'éiréadach', 'fásta',
        'fuck', 'píosa', 'bod', 'sperm', 'orgasm',
        'hardcore', 'anal', 'béal', 'lesbian', 'aerach',
        'striapach', 'striapach', 'píosa', 'tóin', 'cíoch', 'cíoch',
        'sú', 'masturbáil', 'gangbang', 'trí', 'orgy',
        'spreagtha', 'spreagtha', 'sexy', 'drúis',
        
        // ========== WELSH / CYMRAG ==========
        'porno', 'rhyw', 'noeth', 'erotig', 'oedolyn',
        'ffwcio', 'pws', 'pidl', 'sperm', 'orgasm',
        'hardcore', 'anal', 'ceg', 'lesbian', 'gay',
        'putain', 'putain', 'pws', 'tin', 'bronnau', 'bronnau',
        'sugno', 'masturbio', 'gangbang', 'tri', 'orgy',
        'cyffroi', 'cyffroi', 'sexy', 'chwant',
        
        // ========== BASQUE / EUSKARA ==========
        'porno', 'sexu', 'biluzik', 'erotiko', 'heldu',
        'larrua', 'alua', 'zakil', 'esperma', 'orgasmo',
        'hardcore', 'anal', 'aho', 'lesbiana', 'gay',
        'puta', 'puta', 'alua', 'ipurdia', 'bularrak', 'bularrak',
        'xurgatu', 'masturbatu', 'gangbang', 'hiru', 'orgia',
        'kitzikatu', 'kitzikatu', 'sexy', 'desira',
        
        // ========== CATALAN / CATALÀ ==========
        'porno', 'sexe', 'nu', 'eròtic', 'adult',
        'fotre', 'cony', 'polla', 'semen', 'orgasme',
        'hardcore', 'anal', 'oral', 'lesbiana', 'gai',
        'puta', 'puta', 'cony', 'cul', 'tetes', 'tetes',
        'xuclar', 'masturbar', 'gangbang', 'tres', 'orgia',
        'excitat', 'excitat', 'sexy', 'lasciv',
        
        // ========== GALICIAN / GALEGO ==========
        'porno', 'sexo', 'nu', 'erótico', 'adulto',
        'foder', 'cona', 'polla', 'semen', 'orgasmo',
        'hardcore', 'anal', 'oral', 'lesbiana', 'gay',
        'puta', 'puta', 'cona', 'cu', 'tetas', 'tetas',
        'chupar', 'masturbar', 'gangbang', 'tres', 'orgia',
        'excitado', 'excitado', 'sexy', 'lascivo',
        
        // ========== MALTESE / MALTESE ==========
        'porno', 'sess', 'nudi', 'erotiku', 'adult',
        'jigbed', 'pizda', 'zobb', 'sperma', 'orgasm',
        'hardcore', 'anali', 'orali', 'lesbjana', 'gay',
        'prostituta', 'prostituta', 'pizda', 'taht', 'sider', 'sider',
        'jissorbi', 'masturbazzjoni', 'gangbang', 'tlieta', 'orgia',
        'eccitati', 'eccitati', 'sexy', 'xewqa',
        
        // ========== LUXEMBOURGISH / LËTZEBUERGESCH ==========
        'porno', 'sex', 'naakteg', 'erotesch', 'erwuessen',
        'ficken', 'muschi', 'schwanz', 'sperma', 'orgasmus',
        'hardcore', 'anal', 'oral', 'lesbesch', 'schwul',
        'huer', 'huer', 'muschi', 'aasch', 'brëscht', 'brëscht',
        'sucken', 'onanéieren', 'gangbang', 'dräi', 'orgie',
        'erreegt', 'erreegt', 'sexy', 'wollüsteg',
        
        // ========== FAROESE / FØROYSKT ==========
        'porno', 'kynlív', 'nakinn', 'erótiskur', 'vaksin',
        'rjúka', 'píka', 'typpi', 'sáð', 'uppnám',
        'hardcore', 'endalok', 'munnur', 'lesbía', 'samkyndur',
        'hóra', 'hóra', 'píka', 'rass', 'brjóst', 'brjóst',
        'suga', 'sjálfsfróun', 'gangbang', 'tríggir', 'orgía',
        'örvandi', 'örvandi', 'sexy', 'kynþrá',
        
        // ========== YIDDISH / ייִדיש (transliterated) ==========
        'porno', 'seks', 'naket', 'erotish', 'vaksn',
        'fuck', 'pizda', 'shvants', 'sperma', 'orgazm',
        'hardcore', 'anal', 'moyl', 'lesbian', 'gay',
        'kurve', 'kurve', 'pizda', 'tukhes', 'brust', 'brust',
        'zugn', 'masturbatsye', 'gangbang', 'dray', 'orgie',
        'oysgeviklt', 'oysgeviklt', 'sexy', 'lust',
        
        // ========== PERSIAN / فارسی (transliterated) ==========
        'porno', 'seks', 'berahne', 'erotik', 'bozorgsal',
        'gaah', 'kos', 'kir', 'mani', 'orgazm',
        'hardcore', 'anal', 'dahani', 'lesbian', 'hamjensbaz',
        'fahishe', 'fahishe', 'kos', 'kun', 'sine', 'sine',
        'mekidan', 'khodlazat', 'gangbang', 'se', 'orgi',
        'angikhte', 'angikhte', 'sexy', 'shahvat',
        
        // ========== KURDISH / کوردی (transliterated) ==========
        'porno', 'seks', 'beraw', 'erotik', 'mezin',
        'gaah', 'kos', 'kir', 'mani', 'orgazm',
        'hardcore', 'anal', 'dev', 'lesbian', 'gay',
        'fahishe', 'fahishe', 'kos', 'kun', 'memik', 'memik',
        'mekidan', 'khodlazat', 'gangbang', 'se', 'orgi',
        'angikhte', 'angikhte', 'sexy', 'shahvat',
        
        // ========== PASHTO / پښتو (transliterated) ==========
        'porno', 'seks', 'beraw', 'erotik', 'loy',
        'gaah', 'kos', 'kir', 'mani', 'orgazm',
        'hardcore', 'anal', 'khula', 'lesbian', 'gay',
        'fahishe', 'fahishe', 'kos', 'kun', 'sine', 'sine',
        'mekidan', 'khodlazat', 'gangbang', 'dre', 'orgi',
        'angikhte', 'angikhte', 'sexy', 'shahvat',
        
        // ========== UYGHUR / ئۇيغۇرچە (transliterated) ==========
        'porno', 'seks', 'yalang', 'erotik', 'chong',
        'sikmek', 'am', 'sik', 'sperma', 'orgazm',
        'hardcore', 'anal', 'ogiz', 'lesbian', 'gey',
        'fahishe', 'fahishe', 'am', 'göt', 'kokirek', 'kokirek',
        'yalamak', 'masturbatsiya', 'gangbang', 'uch', 'orgiya',
        'qozgalgan', 'qozgalgan', 'sexy', 'qumarlik',
        
        // ========== TIBETAN / བོད་སྐད་ (transliterated) ==========
        'porno', 'seks', 'naked', 'erotic', 'chen',
        'fuck', 'pizda', 'dick', 'sperma', 'orgasm',
        'hardcore', 'anal', 'kha', 'lesbian', 'gay',
        'fahishe', 'fahishe', 'pizda', 'göt', 'nu ma', 'nu ma',
        'mekidan', 'khodlazat', 'gangbang', 'gsum', 'orgi',
        'angikhte', 'angikhte', 'sexy', 'shahvat',
        
        // ========== AMHARIC / አማርኛ (transliterated) ==========
        'porno', 'seks', 'beraw', 'erotik', 'mechach',
        'gaah', 'kos', 'kir', 'mani', 'orgazm',
        'hardcore', 'anal', 'af', 'lesbian', 'gay',
        'fahishe', 'fahishe', 'kos', 'kun', 'sine', 'sine',
        'mekidan', 'khodlazat', 'gangbang', 'sost', 'orgi',
        'angikhte', 'angikhte', 'sexy', 'shahvat',
        
        // ========== HAUSA / HAUSA ==========
        'porno', 'jima\'i', 'tsirara', 'erotic', 'babba',
        'fuck', 'pizda', 'dick', 'sperma', 'orgasm',
        'hardcore', 'anal', 'baki', 'lesbian', 'gay',
        'karuwa', 'karuwa', 'pizda', 'göt', 'nono', 'nono',
        'tsotsa', 'masturbation', 'gangbang', 'uku', 'orgy',
        'tada', 'tada', 'sexy', 'sha\'awa',
        
        // ========== YORUBA / YORÙBÁ ==========
        'porno', 'jima\'i', 'tutu', 'erotic', 'agba',
        'fuck', 'pizda', 'dick', 'sperma', 'orgasm',
        'hardcore', 'anal', 'enu', 'lesbian', 'gay',
        'ashewo', 'ashewo', 'pizda', 'göt', 'oyun', 'oyun',
        'fon', 'masturbation', 'gangbang', 'meta', 'orgy',
        'tada', 'tada', 'sexy', 'sha\'awa',
        
        // ========== ZULU / ISIZULU ==========
        'porno', 'ucansi', 'ze', 'erotic', 'omdala',
        'fuck', 'pizda', 'dick', 'sperma', 'orgasm',
        'hardcore', 'anal', 'umlomo', 'lesbian', 'gay',
        'isifebe', 'isifebe', 'pizda', 'göt', 'amabele', 'amabele',
        'munca', 'masturbation', 'gangbang', 'thathu', 'orgy',
        'tada', 'tada', 'sexy', 'sha\'awa',
        
        // ========== XHOSA / ISIXHOSA ==========
        'porno', 'ucansi', 'ze', 'erotic', 'omdala',
        'fuck', 'pizda', 'dick', 'sperma', 'orgasm',
        'hardcore', 'anal', 'umlomo', 'lesbian', 'gay',
        'isifebe', 'isifebe', 'pizda', 'göt', 'amabele', 'amabele',
        'munca', 'masturbation', 'gangbang', 'thathu', 'orgy',
        'tada', 'tada', 'sexy', 'sha\'awa',
        
        // ========== HAWAIIAN / ʻŌLELO HAWAIʻI ==========
        'porno', 'moekolohe', 'kohu', 'erotic', 'makua',
        'fuck', 'pizda', 'dick', 'sperma', 'orgasm',
        'hardcore', 'anal', 'waha', 'lesbian', 'gay',
        'wahine', 'wahine', 'pizda', 'göt', 'umauma', 'umauma',
        'omi', 'masturbation', 'gangbang', 'ekolu', 'orgy',
        'ho\'onui', 'ho\'onui', 'sexy', 'makemake',
        
        // ========== MAORI / TE REO MĀORI ==========
        'porno', 'taihemahema', 'tu', 'erotic', 'pakeke',
        'fuck', 'pizda', 'dick', 'sperma', 'orgasm',
        'hardcore', 'anal', 'waha', 'lesbian', 'gay',
        'wahine', 'wahine', 'pizda', 'göt', 'uma', 'uma',
        'ngote', 'masturbation', 'gangbang', 'toru', 'orgy',
        'whakaputa', 'whakaputa', 'sexy', 'hiahia',
        
        // ========== SAMOAN / GAGANA SAMOA ==========
        'porno', 'feusuaiga', 'le lavalava', 'erotic', 'matua',
        'fuck', 'pizda', 'dick', 'sperma', 'orgasm',
        'hardcore', 'anal', 'gutu', 'lesbian', 'gay',
        'fafine', 'fafine', 'pizda', 'göt', 'fatafata', 'fatafata',
        'momi', 'masturbation', 'gangbang', 'tolu', 'orgy',
        'fa\'aoso', 'fa\'aoso', 'sexy', 'mana\'o',
        
        // ========== TAHITIAN / REO TAHITI ==========
        'porno', 'moemoe', 'tu', 'erotic', 'matua',
        'fuck', 'pizda', 'dick', 'sperma', 'orgasm',
        'hardcore', 'anal', 'vaha', 'lesbian', 'gay',
        'vahine', 'vahine', 'pizda', 'göt', 'uma', 'uma',
        'omi', 'masturbation', 'gangbang', 'toru', 'orgy',
        'fa\'aoso', 'fa\'aoso', 'sexy', 'hina\'aro',
        
        // ========== FIJIAN / VOSA VAKAVITI ==========
        'porno', 'veitalanoa', 'sivia', 'erotic', 'matua',
        'fuck', 'pizda', 'dick', 'sperma', 'orgasm',
        'hardcore', 'anal', 'gusu', 'lesbian', 'gay',
        'yabaki', 'yabaki', 'pizda', 'göt', 'sucu', 'sucu',
        'momi', 'masturbation', 'gangbang', 'tolu', 'orgy',
        'vakayacora', 'vakayacora', 'sexy', 'mana',
        
        // ========== ADDITIONAL GOOGLE TRANSLATE LANGUAGES ==========
        // Alle overige talen die Google Translate ondersteunt
        
        // ========== ASSAMESE / অসমীয়া (transliterated) ==========
        'porno', 'sex', 'nanga', 'erotic', 'bordho',
        'chudano', 'chut', 'lund', 'virya', 'orgasm',
        'hardcore', 'guda', 'mukh', 'lesbian', 'samlaingik',
        'randi', 'veshya', 'chut', 'gaand', 'stan', 'stan',
        'chutna', 'hastmaithun', 'gangbang', 'teen', 'orgy',
        'uttejit', 'uttejit', 'sexy', 'kamuk',
        
        // ========== ODIA / ଓଡ଼ିଆ (transliterated) ==========
        'porno', 'sex', 'nanga', 'erotic', 'bordho',
        'chudano', 'chut', 'lund', 'virya', 'orgasm',
        'hardcore', 'guda', 'mukh', 'lesbian', 'samlaingik',
        'randi', 'veshya', 'chut', 'gaand', 'stan', 'stan',
        'chutna', 'hastmaithun', 'gangbang', 'teen', 'orgy',
        'uttejit', 'uttejit', 'sexy', 'kamuk',
        
        // ========== MAITHILI / मैथिली (transliterated) ==========
        'porno', 'sex', 'nanga', 'erotic', 'bordho',
        'chudano', 'chut', 'lund', 'virya', 'orgasm',
        'hardcore', 'guda', 'mukh', 'lesbian', 'samlaingik',
        'randi', 'veshya', 'chut', 'gaand', 'stan', 'stan',
        'chutna', 'hastmaithun', 'gangbang', 'teen', 'orgy',
        'uttejit', 'uttejit', 'sexy', 'kamuk',
        
        // ========== BHOJPURI / भोजपुरी (transliterated) ==========
        'porno', 'sex', 'nanga', 'erotic', 'bordho',
        'chudano', 'chut', 'lund', 'virya', 'orgasm',
        'hardcore', 'guda', 'mukh', 'lesbian', 'samlaingik',
        'randi', 'veshya', 'chut', 'gaand', 'stan', 'stan',
        'chutna', 'hastmaithun', 'gangbang', 'teen', 'orgy',
        'uttejit', 'uttejit', 'sexy', 'kamuk',
        
        // ========== DOGRI / डोगरी (transliterated) ==========
        'porno', 'sex', 'nanga', 'erotic', 'bordho',
        'chudano', 'chut', 'lund', 'virya', 'orgasm',
        'hardcore', 'guda', 'mukh', 'lesbian', 'samlaingik',
        'randi', 'veshya', 'chut', 'gaand', 'stan', 'stan',
        'chutna', 'hastmaithun', 'gangbang', 'teen', 'orgy',
        'uttejit', 'uttejit', 'sexy', 'kamuk',
        
        // ========== KONKANI / कोंकणी (transliterated) ==========
        'porno', 'sex', 'nanga', 'erotic', 'bordho',
        'chudano', 'chut', 'lund', 'virya', 'orgasm',
        'hardcore', 'guda', 'mukh', 'lesbian', 'samlaingik',
        'randi', 'veshya', 'chut', 'gaand', 'stan', 'stan',
        'chutna', 'hastmaithun', 'gangbang', 'teen', 'orgy',
        'uttejit', 'uttejit', 'sexy', 'kamuk',
        
        // ========== MEITEILON / MANIPURI / ꯃꯩꯇꯩꯂꯣꯟ (transliterated) ==========
        'porno', 'sex', 'nanga', 'erotic', 'bordho',
        'chudano', 'chut', 'lund', 'virya', 'orgasm',
        'hardcore', 'guda', 'mukh', 'lesbian', 'samlaingik',
        'randi', 'veshya', 'chut', 'gaand', 'stan', 'stan',
        'chutna', 'hastmaithun', 'gangbang', 'teen', 'orgy',
        'uttejit', 'uttejit', 'sexy', 'kamuk',
        
        // ========== MIZO / MIZO ==========
        'porno', 'sex', 'nanga', 'erotic', 'bordho',
        'chudano', 'chut', 'lund', 'virya', 'orgasm',
        'hardcore', 'guda', 'mukh', 'lesbian', 'samlaingik',
        'randi', 'veshya', 'chut', 'gaand', 'stan', 'stan',
        'chutna', 'hastmaithun', 'gangbang', 'teen', 'orgy',
        'uttejit', 'uttejit', 'sexy', 'kamuk',
        
        // ========== KOKBOROK / KOKBOROK ==========
        'porno', 'sex', 'nanga', 'erotic', 'bordho',
        'chudano', 'chut', 'lund', 'virya', 'orgasm',
        'hardcore', 'guda', 'mukh', 'lesbian', 'samlaingik',
        'randi', 'veshya', 'chut', 'gaand', 'stan', 'stan',
        'chutna', 'hastmaithun', 'gangbang', 'teen', 'orgy',
        'uttejit', 'uttejit', 'sexy', 'kamuk',
        
        // ========== HILIGAYNON / HILIGAYNON ==========
        'porno', 'seks', 'hubad', 'erotiko', 'matanda',
        'kantot', 'pepe', 'titi', 'tamod', 'orgasm',
        'hardcore', 'anal', 'oral', 'lesbian', 'gay',
        'pokpok', 'pokpok', 'pepe', 'puwit', 'dibdib', 'dibdib',
        'sipsip', 'jakol', 'gangbang', 'tatlo', 'orgy',
        'naaakit', 'naaakit', 'sexy', 'malibog',
        
        // ========== ILOKANO / ILOKANO ==========
        'porno', 'seks', 'hubad', 'erotiko', 'matanda',
        'kantot', 'pepe', 'titi', 'tamod', 'orgasm',
        'hardcore', 'anal', 'oral', 'lesbian', 'gay',
        'pokpok', 'pokpok', 'pepe', 'puwit', 'dibdib', 'dibdib',
        'sipsip', 'jakol', 'gangbang', 'tallo', 'orgy',
        'naaakit', 'naaakit', 'sexy', 'malibog',
        
        // ========== BIKOL / BIKOL ==========
        'porno', 'seks', 'hubad', 'erotiko', 'matanda',
        'kantot', 'pepe', 'titi', 'tamod', 'orgasm',
        'hardcore', 'anal', 'oral', 'lesbian', 'gay',
        'pokpok', 'pokpok', 'pepe', 'puwit', 'dibdib', 'dibdib',
        'sipsip', 'jakol', 'gangbang', 'tulo', 'orgy',
        'naaakit', 'naaakit', 'sexy', 'malibog',
        
        // ========== KAPAMPANGAN / KAPAMPANGAN ==========
        'porno', 'seks', 'hubad', 'erotiko', 'matanda',
        'kantot', 'pepe', 'titi', 'tamod', 'orgasm',
        'hardcore', 'anal', 'oral', 'lesbian', 'gay',
        'pokpok', 'pokpok', 'pepe', 'puwit', 'dibdib', 'dibdib',
        'sipsip', 'jakol', 'gangbang', 'atlu', 'orgy',
        'naaakit', 'naaakit', 'sexy', 'malibog',
        
        // ========== WARAY / WARAY ==========
        'porno', 'seks', 'hubad', 'erotiko', 'matanda',
        'kantot', 'pepe', 'titi', 'tamod', 'orgasm',
        'hardcore', 'anal', 'oral', 'lesbian', 'gay',
        'pokpok', 'pokpok', 'pepe', 'puwit', 'dibdib', 'dibdib',
        'sipsip', 'jakol', 'gangbang', 'tulo', 'orgy',
        'naaakit', 'naaakit', 'sexy', 'malibog',
        
        // ========== MADURESE / MADURESE ==========
        'porno', 'seks', 'telanjang', 'erotis', 'dewasa',
        'ngentot', 'tempik', 'kontol', 'sperma', 'orgasme',
        'hardcore', 'anal', 'oral', 'lesbian', 'gay',
        'pelacur', 'pelacur', 'tempik', 'pantat', 'dada', 'dada',
        'njilat', 'onani', 'gangbang', 'tello', 'orgi',
        'terangsang', 'terangsang', 'sexy', 'berahi',
        
        // ========== MINANGKABAU / MINANGKABAU ==========
        'porno', 'seks', 'telanjang', 'erotis', 'dewasa',
        'ngentot', 'tempik', 'kontol', 'sperma', 'orgasme',
        'hardcore', 'anal', 'oral', 'lesbian', 'gay',
        'pelacur', 'pelacur', 'tempik', 'pantat', 'dada', 'dada',
        'njilat', 'onani', 'gangbang', 'tigo', 'orgi',
        'terangsang', 'terangsang', 'sexy', 'berahi',
        
        // ========== BETAVI / BETAVI ==========
        'porno', 'seks', 'telanjang', 'erotis', 'dewasa',
        'ngentot', 'tempik', 'kontol', 'sperma', 'orgasme',
        'hardcore', 'anal', 'oral', 'lesbian', 'gay',
        'pelacur', 'pelacur', 'tempik', 'pantat', 'dada', 'dada',
        'njilat', 'onani', 'gangbang', 'tiga', 'orgi',
        'terangsang', 'terangsang', 'sexy', 'berahi',
        
        // ========== BALINESE / BALINESE ==========
        'porno', 'seks', 'telanjang', 'erotis', 'dewasa',
        'ngentot', 'tempik', 'kontol', 'sperma', 'orgasme',
        'hardcore', 'anal', 'oral', 'lesbian', 'gay',
        'pelacur', 'pelacur', 'tempik', 'pantat', 'dada', 'dada',
        'njilat', 'onani', 'gangbang', 'telu', 'orgi',
        'terangsang', 'terangsang', 'sexy', 'berahi',
        
        // ========== COMMON VARIATIONS AND MISSPELLINGS ==========
        'p0rn', 'pr0n', 's3x', 'xxx', 'xxnx', 'xnxx',
        'porn0', 'p0rno', 's3ks', 's3x', 'adult0',
        'p0rnhub', 'xv1deos', 'xnx', 'redtub3', 'youp0rn',
        'tub38', 'xhamst3r', 'p0rnmd', 'p0rnhd',
        'vidio', 'vedio', 'vedeo', 'vido', 'vdeo', // Common misspellings of "video"
        'sexvidio', 'sexvedio', 'sexvideo', 'pornvidio', 'pornvedio',
        
        // ========== DOMAIN PATTERNS ==========
        'pornhub', 'xvideos', 'xnxx', 'redtube', 'youporn',
        'tube8', 'xhamster', 'pornmd', 'pornhd', 'pornotube',
        'pornovideos', 'pornoxxx', 'pornstar', 'pornstash',
        'pornwapi', 'pornwatchers', 'beeg', 'tnaflix',
        'spankwire', 'keezmovies', '4tube', 'extremetube',
        'sunporno', 'pornoxo', 'drtuber', 'nuvid', 'porntube',
        'pornktube', 'porn300', 'porn555'
    ];
}

